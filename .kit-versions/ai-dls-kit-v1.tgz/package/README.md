# ai-dls-kit

A standalone Angular component library replicating the DBS Angular DLS,
for prototyping DBS UI on your own laptop with any AI tool.

## Install

```bash
npm install ai-dls-kit-0.1.0.tgz
```

Add to your app's `angular.json` `styles` array:

```json
"node_modules/ai-dls-kit/styles/tokens.css",
"node_modules/ai-dls-kit/styles/ui-tables.css"
```

In your own SCSS, for the type/layout mixins:

```scss
@use 'ai-dls-kit/tokens/type' as type;
```

## Use

```ts
import { UiButton, UiStatusTag } from 'ai-dls-kit';
```
