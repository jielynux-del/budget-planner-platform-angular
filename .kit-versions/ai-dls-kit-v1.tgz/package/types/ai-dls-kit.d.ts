import * as _angular_core from '@angular/core';
import { TemplateRef, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

type UiButtonVariant = 'primary' | 'secondary' | 'plain';
type UiButtonSize = 'small' | 'tiny';
type UiButtonTone = 'normal' | 'destructive' | 'positive' | 'on-dim' | 'on-bright';
/**
 * Neutral button — the DLS 3.1 `button` component (page 305:2699, set
 * 50546:240728), rebuilt onto its real axis grid. Applied as an attribute so
 * native semantics (type, disabled, form participation) stay intact:
 *
 *   <button ui-button variant="secondary" size="tiny">Cancel</button>
 *   <button ui-button tone="destructive" [loading]="saving()">Revoke</button>
 *   <button ui-button variant="plain" type="button">
 *     Next
 *     <svg uiButtonIconRight>…</svg>
 *   </button>
 *
 * DLS's six axes, and where each landed:
 *
 * **Variant** — `primary` (default) | `secondary` | `plain`. DLS calls the
 * third one Plain; the kit's old `ghost` is the same thing renamed (8
 * callers migrated). `danger` is GONE as a variant — it was always Primary
 * with a red fill, and DLS confirms that: destructive is a *Style*, not a
 * variant (2 callers migrated to `variant="primary" tone="destructive"`).
 *
 * **Size** — `small` (default, 32px, node 50546:240727) | `tiny` (24px,
 * Tiny Plain node 50647:239834). OWNER'S RULING (2 Sep 2026): "a compact
 * application" ships Tiny + Small only — DLS's Medium (40) and Large (48)
 * are recorded here and in REGISTER.md §7, not built. DLS's
 * own Primary has no Tiny at all; nothing stops a caller writing
 * `variant="primary" size="tiny"` here (CSS would render it), but there is
 * no DLS anatomy behind that combination and no call site should reach for
 * it — Tiny is Breadcrumb's (§6) and Alert's (§2) size, both Secondary/Plain
 * only. Both sizes type at the kit's `label(sm)` — 13px, the compactness
 * value the platform already stands on everywhere else `label(sm)` is used
 * (f16-typography). DLS's own printed spec says 14px for this role; the
 * owner ruled that a DLS-side inconsistency, not a platform gap, and this
 * component deliberately does NOT chase it.
 *
 * **Style → `tone`.** DLS names this axis Style: `normal` (default) |
 * `destructive` | `positive` | `on-dim` | `on-bright`. NAMING TRAP: it
 * cannot be called `style` here — `ui-button` is an attribute component on
 * a native `<button>`/`<a>`, and `style="destructive"` would try to write
 * literal inline CSS through the element's built-in `style` attribute
 * rather than reaching this component's input. `tone` is the kit's existing
 * word for exactly this shape of axis (see `ui-badge`'s `tone`), so it
 * carries over rather than inventing a third name for the same idea.
 *
 * `destructive` (Figma 141989:55608) and `positive` (141989:51643) are
 * SOLID FILLS and apply to `variant="primary"` — `--color-bg-danger-strong`
 * / `--color-bg-success-strong` with their own hover/pressed steps, text
 * `--color-text-inverse`. `on-dim` (secondary shown at 136059:193213) and
 * `on-bright` apply to `variant="secondary"` / `"plain"` — the pairing DLS
 * uses for a control sitting on a dark rail or a tinted card. The owner
 * ruled ALL FIVE tones ship now (2 Sep 2026), even though only on-dim has
 * a reference-app call site today (the Primary Nav is the one dark surface in the
 * app) — "so the platform can grow a dark mode later" without a second
 * button pass.
 *
 * DLS does not define every Variant×Tone cell (e.g. `secondary` +
 * `destructive`, `primary` + `on-dim`). Rather than throw or silently
 * ignore the caller's intent, an undefined combination falls back to that
 * variant's `normal` look — the CSS for destructive/positive is scoped to
 * `.ui-button--primary` and on-dim/on-bright to `.ui-button--secondary` /
 * `.ui-button--plain`, so a tone class that doesn't apply to a given
 * variant simply never matches a rule and the variant's own Normal styling
 * stands. See button.scss for exactly which cells are wired.
 *
 * **State** — Default/Hover/Pressed are the existing `:hover`/`:active`
 * rules per variant×tone. **Focus** (node 50647:240042) RESOLVES the open
 * question from the 1 Aug pass: DLS's focus is a 2px SOLID border in
 * `--color-focus` (Status/Access, `#458fff` — reused rather than adding a
 * second `--color-border-access-focus` token for the same DLS hue and the
 * same value), drawn INSET (`box-shadow: inset 0 0 0 2px`) so it adds no
 * layout shift and a Secondary's 1px border stays visible underneath it —
 * not the old 25%-alpha ring (`--focus-ring`, kept in tokens.css for
 * whatever still reads it, not read by this component any more).
 * **Disabled** collapses every variant/tone to `--color-bg-disabled` +
 * `--color-text-disabled`, no border — DLS's rule, except `on-dim`, which
 * keeps its own darker disabled pair (`--color-bg-on-dim-disabled` +
 * `--color-text-on-dim-disabled`) because the ordinary disabled fill is
 * invisible against a dark rail. **Loading** (node 50647:239659): the
 * button's own PRESSED fill as background, `aria-busy="true"`,
 * `pointer-events: none`, the projected label swapped for three 8px pill
 * dots at opacity 1/.6/.2 — see the `loading` input doc below for why the
 * label is hidden rather than removed.
 *
 * **Icons** — two named projection slots, `uiButtonIconLeft` /
 * `uiButtonIconRight`, both fixed to DLS's 16px at every size via
 * `::ng-deep` in button.scss (see that file for why: projected content
 * carries the CALLER's encapsulation attribute, not this component's, so a
 * plain scoped rule can never reach it — the kit's internal notes "projected content
 * cannot be styled from its host"). Icon-ONLY buttons are `ui-icon-button`
 * now (REGISTER.md §8) — DLS treats an icon-only control as
 * its own component, not a state of this one, and `ui-icon-button` gets
 * the icon-only anatomy right (grey glyph, square/circle, 24px at Small)
 * where this component's retired `iconOnly` flag did not. This component
 * keeps only the two labelled-icon slots above.
 *
 * RESKIN: delegate to `dbs-button [variant] [size]`, with `tone` mapped
 * onto DLS's `Style` input (`normal` needs no explicit Style prop — it's
 * the DLS default). Keep this selector and all four inputs; `ghost` and
 * `danger` are gone from the type union, so a leftover caller on either
 * fails the Angular template check at build time rather than drifting.
 */
declare class UiButton {
    /** DLS's Variant axis — see the class doc. */
    variant: _angular_core.InputSignal<UiButtonVariant>;
    /** DLS's Size axis, Tiny + Small only (owner's ruling) — see the class doc. */
    size: _angular_core.InputSignal<UiButtonSize>;
    /** DLS's Style axis, renamed `tone` — see the class doc for the naming trap. */
    tone: _angular_core.InputSignal<UiButtonTone>;
    /**
     * DLS's Loading state. Background becomes the variant/tone's own pressed
     * fill, `aria-busy` is set, and the control stops accepting pointer
     * input. The projected label is hidden with `visibility: hidden` rather
     * than removed from the DOM — that keeps its layout box (and so the
     * button's width) exactly as it was a moment before, which is what makes
     * a button safe to put into a loading state without its own width
     * jumping under the user's cursor. Three centred 8px dots take its place.
     */
    loading: _angular_core.InputSignal<boolean>;
    protected hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiButton, "button[ui-button], a[ui-button]", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; }, {}, never, ["[uiButtonIconLeft]", "*", "[uiButtonIconRight]"], true, never>;
}

type UiIconButtonShape = 'square' | 'circle';
type UiIconButtonSize = 'small' | 'tiny';
type UiIconButtonTone = 'normal' | 'on-dim' | 'on-bright';
/**
 * Icon button — the DLS 3.1 `icon-button` component (page 186153:6433, set
 * 50671:241589, REGISTER.md §8, audited 2 Sep 2026). Applied as
 * an attribute so native `<button>`/`<a>` semantics (type, disabled, form
 * participation, href) stay intact, same pattern as `ui-button`:
 *
 *   <button ui-icon-button aria-label="Close">
 *     <svg>…24px glyph…</svg>
 *   </button>
 *   <button ui-icon-button shape="circle" size="small" outline aria-label="Audit log">
 *     <svg>…</svg>
 *   </button>
 *   <button ui-icon-button size="tiny" tone="on-dim" aria-label="Previous step">
 *     <svg>…16px glyph…</svg>
 *   </button>
 *
 * DLS's five axes, and where each landed:
 *
 * **Type → `shape`.** `square` (default, node 50671:241580) | `circle`
 * (node 67700:328364) — radius `--radius-sm` (4, DLS's
 * `border_radius-action-alt`) or `--radius-pill`.
 *
 * **Size** — `small` (default, 32px) | `tiny` (24px, node 50671:241832).
 * OWNER'S RULING (2 Sep 2026, carried from the Button pass, §7): a compact
 * application ships Tiny + Small only — DLS's Medium (40) and Large (48)
 * are recorded in REGISTER.md §8, not built. The glyph is
 * fixed at 24px at Small (DLS runs 24 through Small/Medium/Large — only
 * Tiny drops to 16) and 16px at Tiny — see icon-button.scss for the
 * `::ng-deep` that enforces it regardless of the projected SVG's own
 * viewBox, the same projected-content trap `ui-button` documents.
 *
 * **Style → `tone`.** `normal` (default) | `on-dim` | `on-bright` — DLS's
 * five-tone Style axis minus `destructive`/`positive`, which have no
 * icon-button reading (there is no solid-fill icon-only control in the
 * set). Kept as `tone` rather than `style` for the same NAMING TRAP
 * `ui-button` calls out: this is an attribute component on a native
 * `<button>`/`<a>`, so `style="on-dim"` would try to write the element's
 * own inline-CSS attribute. `on-bright` reuses Normal's values in DLS (see
 * icon-button.scss — no override block needed, same shape as
 * `ui-button`'s on-bright resting/hover/pressed).
 *
 * **Outline** — boolean `outline` input. `NO` (default, no chrome at rest)
 * | `YES` (node 50671:241590): adds a 1px `--color-border` ring
 * (`--color-border-on-dim` when `tone="on-dim"`).
 *
 * **State** — Hover/Pressed are `:hover`/`:active` bg fills
 * (`--color-bg-hover` / `--color-bg-pressed`, on-dim's own darker pair).
 * **Focus** (node 50671:241630) is the same 2px solid inset border in
 * `--color-focus` `ui-button` draws — `box-shadow: inset 0 0 0 2px`, no
 * layout shift. **Disabled** is `--color-bg-disabled` +
 * `--color-icon-disabled`, no border (DLS's outline collapses too); on-dim
 * keeps its own darker pair (`--color-bg-on-dim-disabled` +
 * `--color-text-on-dim-disabled`), same exception `ui-button` documents
 * for the same reason — the ordinary disabled fill is invisible against a
 * dark rail.
 *
 * **Glyph colour** — the projected SVG is expected to paint with
 * `currentColor`; this component sets `color` on the host
 * (`--color-icon` #69737b Normal, `--color-text-on-dim` white on-dim) so
 * a `currentColor` glyph picks it up automatically, rather than reaching
 * into the projected SVG's own fill/stroke attributes (which, per the
 * projected-content trap, this host cannot touch anyway).
 *
 * Every colour/geometry token this component uses already existed after
 * the Button round (§7) — no new tokens were added for this component.
 *
 * RESKIN: delegate to the DLS Angular icon button (`shape`/`type` maps
 * onto its Type input, `size`/`tone`/`outline` onto their DLS
 * equivalents); keep this selector and all four inputs.
 */
declare class UiIconButton {
    /** DLS's Type axis, renamed `shape` (Angular doesn't reserve `type` for a
     *  component input the way it does for the button's own `type` attribute,
     *  but `shape` reads clearer next to `ui-button`'s `variant`). */
    shape: _angular_core.InputSignal<UiIconButtonShape>;
    /** DLS's Size axis, Tiny + Small only (owner's ruling) — see the class doc. */
    size: _angular_core.InputSignal<UiIconButtonSize>;
    /** DLS's Style axis, renamed `tone` — same naming trap as `ui-button`. */
    tone: _angular_core.InputSignal<UiIconButtonTone>;
    /**
     * DLS's Outline axis. `transform: booleanAttribute` so a bare `outline`
     * attribute (no `[outline]="true"` binding needed) reads as true, the
     * same ergonomics the native `disabled` attribute gets for free — every
     * other boolean input in this kit is Angular-only (`[loading]="true"` on
     * `ui-button`, no bare-attribute form), but `outline` sits right next to
     * `disabled` in most call sites and consumers reach for the HTML-boolean
     * spelling by habit.
     */
    outline: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiIconButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiIconButton, "button[ui-icon-button], a[ui-icon-button]", never, { "shape": { "alias": "shape"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "outline": { "alias": "outline"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type UiFabTone = 'light' | 'dark';
/**
 * Floating action button — the DLS 3.1 `floating-action-button` component
 * (page 305:2720, set 407:4, REGISTER.md §18, audited
 * 2 Sep 2026). Type Light | Dark × State Default | Hover | Pressed | Focus:
 * a 48px circle, `elevation-4` shadow, a 24px glyph centred. Applied as an
 * attribute so native `<button>`/`<a>` semantics stay intact, the same
 * pattern as `ui-button` / `ui-icon-button`:
 *
 *   <button ui-fab aria-label="Scroll to top">
 *     <svg>…24px glyph…</svg>
 *   </button>
 *   <button ui-fab tone="dark" aria-label="AI Assistant">
 *     <svg>…24px glyph…</svg>
 *   </button>
 *
 * **Size.** Fixed 48×48 — DLS's Type axis has no size variant, so unlike
 * `ui-button`/`ui-icon-button` there is no `size` input at all. DLS calls
 * this out as `size-base-lg` — the token was 44 with no consumer when this
 * component arrived and the lead corrected it to DLS's 48 (3 Sep 2026), so
 * the box reads `var(--size-base-lg)` like every other sized control.
 *
 * **Tone → DLS's Type axis.** `light` (default, node 407:4) — bg
 * `--color-bg-level1`, glyph `--color-icon`, hover `--color-bg-hover`,
 * pressed `--color-bg-pressed`. `dark` — bg `--color-bg-dim`, glyph
 * `--color-text-on-dim` (white), hover `--color-bg-on-dim-hover`, pressed
 * `--color-bg-on-dim-pressed`. Kept as `tone` rather than `type` for the
 * same reason `ui-icon-button` uses `shape`/`tone` instead of `type`/
 * `style` — Angular reserves neither word specially here, but it keeps the
 * vocabulary consistent across the three attribute-button components.
 *
 * **Glyph** — a projected SVG, sized 24px via `:host ::ng-deep > svg` in
 * fab.scss (the projected-content trap `ui-button`/`ui-icon-button`
 * document: a plain scoped `svg { … }` rule can never reach content
 * projected from the CALLER's template, since it carries the caller's own
 * encapsulation attribute, not this host's). Expected to paint with
 * `currentColor` so it picks up the tone's glyph colour automatically.
 *
 * **Shadow** — `--shadow-elevation-4` (0 0 1px .25 + 0 8px 8px .08), not
 * `--shadow-elevation-2` (buttons/cards use elevation-2; the FAB floats
 * higher above the page).
 *
 * **Press** — NO transform on `:active`. DLS shows no press-scale on this
 * component's node, and the platform has no press-state movement anywhere
 * (owner's ruling, 5 Sep 2026); press feedback is colour only.
 *
 * **Focus** — the same 2px solid inset `--color-focus` border every other
 * attribute-button component in this kit draws (`box-shadow: inset 0 0 0
 * 2px`), no layout shift.
 *
 * Host classes: `ui-fab ui-fab--{tone}`.
 *
 * RESKIN: delegate to the DLS Angular floating action button (`tone` maps
 * onto its Type input); keep this selector and the `tone` input.
 */
declare class UiFab {
    /** DLS's Type axis, renamed `tone` — see the class doc. */
    tone: _angular_core.InputSignal<UiFabTone>;
    protected hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiFab, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiFab, "button[ui-fab], a[ui-fab]", never, { "tone": { "alias": "tone"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * Canonical page title — the single definition of "the title of a page".
 * Applied as an attribute so the native heading (and its document outline
 * semantics) stays intact:
 *
 *   <h1 ui-page-title>Trade Monitoring</h1>
 *
 * Typography only: 16px/600, line-height 1.3, -0.08px tracking, text-strong,
 * `margin: 0`. Layout — truncation, header height, padding — belongs to the
 * host page, never here.
 *
 * RESKIN: delegate to the DLS heading/typography component; keep this
 * selector unchanged so app code stays untouched.
 */
declare class UiPageTitle {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiPageTitle, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiPageTitle, "h1[ui-page-title], h2[ui-page-title]", never, {}, {}, never, ["*"], true, never>;
}

interface UiSelectOption {
    value: string;
    label: string;
    /** DLS "Metadata" — a second line under the label (§36). */
    description?: string;
    /** 16px leading glyph: an SVG `<path d>` string, rendered through
     *  `ui-dropdown-item`'s `[uiDropdownIcon]` slot. Mutually exclusive with
     *  `avatar` — DLS's Icon and Avatar are alternate row variants, not
     *  additive; an option with both renders the icon. */
    icon?: string;
    /** Initials source (a name, e.g. "Aiko MORI") for a 24px `ui-avatar` in
     *  the row's `[uiDropdownAvatar]` slot. */
    avatar?: string;
    /** DLS right-slot: a 16px neutral count pill. */
    count?: number;
    /** Not selectable by click or keyboard; skipped by arrow/typeahead nav. */
    disabled?: boolean;
}
/**
 * DLS 3.1 Single select (REGISTER.md §21, audited 3 Sep 2026,
 * built per the owner's §21–§24 ruling "the Single-select Expanded MENU is
 * built NOW") — Small (76086:347480) / Expanded (76086:350551): a 32px
 * trigger (bg level_1, 1px border, radius 4, 0/12 padding, 8 gap, kit
 * body(sm) 13, chevron-down_16 in `--color-icon`) that opens a
 * `ui-dropdown-menu[role=listbox]` of `button[ui-dropdown-item]` rows 6px
 * below, min-width the trigger's own width or 200px, whichever is larger —
 * the same "max(200, 100%)" rule `ui-multi-select`'s panel already uses.
 * Open/focus draws the DLS 2px solid `--color-focus` inset ring and flips
 * the chevron to chevron-up; a value set adds a leading `clearable` (default
 * on) `clear-filled_16` glyph that resets to null without opening the menu.
 *
 *   <ui-select [options]="months" [(value)]="month" placeholder="All" />
 *   <ui-select [options]="months" [formControl]="ctrl" searchable="true" />
 *   <ui-select [options]="months" [(value)]="month" readonly="true" />
 *
 * NATIVE-SELECT MIRROR (why): 59 existing callers and their e2e specs drive
 * this control with Playwright's `locator.selectOption()` against a plain
 * `<select>` (the e2e helpers `selectFor()`), which a custom listbox cannot
 * satisfy — there is no native `<select>` for `selectOption()` to act on. So
 * a visually-hidden native `<select class="ui-select-native">` stays in the
 * DOM (collapsed to 1x1, `opacity: 0`, NOT `display:none` — the same trick
 * `ui-date-input`'s column-header face uses, select.scss), mirrored
 * bidirectionally to the `value` model: `selectOption()` still drives it and
 * its `change` event updates `value` the normal CVA way; picking a row in
 * the visible trigger/menu writes `value` too, which the native select's own
 * `[selected]` bindings pick straight back up. ONE model, two faces — same
 * pattern `ui-date-input` already established for its two faces.
 *
 * Per-instance styling sets WIDTH ONLY (size the host element).
 *
 * `invalid` + `errorMessage` — the canonical error-state contract shared by
 * every kit form control (see ui-text-input for the full docstring). The
 * two are independent on purpose: a field can be marked invalid without a
 * message of its own.
 *
 * TABLE FILTER FACE: inside a `ui-column-header` the trigger keeps that
 * component's 24px sizing convention — same `:host-context(ui-column-header)`
 * override `ui-date-input` uses (select.scss).
 *
 * TRAP (the kit's internal notes, 23 Jul): a `placeholder` AND a real first option
 * whose text equals it produces two same-text options and can bind
 * `value=""` on select. If the default option is already in the list (e.g.
 * "All"), do not also pass a placeholder — unchanged by this rebuild.
 *
 * FILLED vs default (owner's ruling, 3 Sep 2026, REGISTER.md
 * §21): the clear (×) belongs to the FILLED state only. Table-header and
 * page-level FILTER selects default to an "All …" sentinel — pass it as
 * `emptyValue` so the select reads as unfilled at rest, no clear button,
 * and clearing returns to that sentinel rather than to `null`. Every other
 * caller leaves `emptyValue` at its `null` default, so this is a no-op for
 * them.
 *
 * RESKIN: delegate to the DLS single-select Angular component; keep
 * selector + inputs unchanged (dbs-select).
 */
declare class UiSelect implements ControlValueAccessor {
    options: _angular_core.InputSignal<string[] | UiSelectOption[]>;
    placeholder: _angular_core.InputSignal<string | undefined>;
    disabled: _angular_core.InputSignal<boolean>;
    value: _angular_core.ModelSignal<string | null>;
    /** Error state — see ui-text-input's docstring for the shared contract. */
    invalid: _angular_core.InputSignal<boolean>;
    errorMessage: _angular_core.InputSignal<string>;
    /** DLS "Read-only": no box at all, just the value as text. */
    readonly: _angular_core.InputSignal<boolean>;
    /** Trailing clear-filled glyph when a value is set. On by default per DLS. */
    clearable: _angular_core.InputSignal<boolean>;
    /**
     * The "unfilled" value — the clear glyph hides and the trigger reads as
     * default whenever `value` equals this. `null` (default) for every
     * ordinary caller; a filter select whose default option is an "All …"
     * sentinel passes that string instead (class doc above).
     */
    emptyValue: _angular_core.InputSignal<string | null>;
    /** DLS search header inside the Expanded menu. */
    searchable: _angular_core.InputSignal<boolean>;
    protected readonly uid: string;
    private readonly host;
    protected cvaDisabled: _angular_core.WritableSignal<boolean>;
    protected isDisabled: _angular_core.Signal<boolean>;
    protected normalizedOptions: _angular_core.Signal<UiSelectOption[]>;
    protected readonly open: _angular_core.WritableSignal<boolean>;
    protected readonly search: _angular_core.WritableSignal<string>;
    protected readonly activeIndex: _angular_core.WritableSignal<number>;
    protected readonly filteredOptions: _angular_core.Signal<UiSelectOption[]>;
    protected readonly displayLabel: _angular_core.Signal<string | null>;
    protected readonly activeId: _angular_core.Signal<string | null>;
    private onChange;
    protected onTouched: () => void;
    protected optionId(i: number): string;
    protected toggle(): void;
    private openMenu;
    protected closeMenu(): void;
    protected pick(opt: UiSelectOption): void;
    protected onClear(event: Event): void;
    /** Filled state per the owner's §21 ruling — see the class doc's
     *  "FILLED vs default" note. */
    protected readonly isFilled: _angular_core.Signal<boolean>;
    /** Skips `disabled` options — DLS "skipped by keyboard" (§36). Tries at
     *  most `n` steps in `delta`'s direction before giving up (an all-disabled
     *  list leaves the active index wherever it was). */
    private moveActive;
    protected onTriggerKeydown(event: KeyboardEvent): void;
    protected onSearchInput(value: string): void;
    /** Native-select mirror (`selectOption()`-driven specs, see class doc). */
    protected onNativeSelect(event: Event): void;
    protected onDocumentDown(event: Event): void;
    protected onEscape(): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiSelect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiSelect, "ui-select", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "clearable": { "alias": "clearable"; "required": false; "isSignal": true; }; "emptyValue": { "alias": "emptyValue"; "required": false; "isSignal": true; }; "searchable": { "alias": "searchable"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

/**
 * `ui-select-group` — N kit controls joined inside ONE field frame.
 *
 *   <ui-select-group>
 *     <ui-select [options]="desks" [(value)]="desk" [emptyValue]="'All Desks'" />
 *     <ui-select [options]="subDesks" [(value)]="subDesk" [emptyValue]="'All Sub-desks'" />
 *   </ui-select-group>
 *
 *   <ui-select-group>
 *     <ui-select [options]="['Month', 'Date Range']" [(value)]="mode" />
 *     <ui-date-input type="month" [(value)]="month" [max]="maxMonth" />
 *   </ui-select-group>
 *
 * OWNER OVERRIDE OF THE DLS NODE (kit-fixes walk item 10, 6 Sep 2026):
 * Figma's Select node (305:2698) draws each inner select of a combo with
 * its OWN border. The owner ruled on the Trade Monitoring Desk / Sub-desk
 * pair: "the inner individual input borders must be hidden. Figma DLS is
 * also wrong here. It should be a borderless dropdown, a divider, then a
 * borderless dropdown, inside one border." So this component paints
 *   - ONE outer 1px `--color-border` frame, `--radius-sm`, level_1 fill,
 *     32px tall (`--size-base-sm`, the single select's own height axis —
 *     the 1px frame is INSIDE the 32, so the group's outer box equals a
 *     standalone `ui-select`'s outer box, and its members are 30px tall
 *     inside it);
 *   - hover: `--color-border-hover` on the frame (not while focused);
 *   - focus: the DLS 2px inset `--color-focus` ring on the FRAME whenever
 *     any member has focus or an open menu (`:focus-within`, plus `:has()`
 *     for a member whose menu is open by pointer without `:focus-visible`);
 *   - members rendered BARE: no border, no radius, transparent background,
 *     no ring of their own (their own hover/focus paint is suppressed —
 *     the frame carries it);
 *   - a 1px `--color-border-decorative` vertical divider between members.
 *
 * MEMBERS. Anything projected is a member; `ui-select` and `ui-date-input`
 * are the two the stylesheet knows how to strip (kit-fixes item 21 needs a
 * date member for the table date filter). Each member keeps its own API
 * — value, options, `emptyValue`, `searchable`, `placeholder`, `disabled`,
 * `type="month"`, `min`/`max` — untouched; the group is layout + chrome
 * only, it has no value of its own and no CVA. A disabled member keeps
 * its `--color-bg-disabled` fill and disabled text so it still reads as
 * disabled (and stays legible) inside the live frame.
 *
 * HOW THE STRIPPING WORKS (documented hook, select-group.scss): the group
 * reaches its projected members with `:host ::ng-deep > ui-select …` /
 * `> ui-date-input …` — projected content carries the CALLER's
 * encapsulation attribute, not this component's, so `::ng-deep` is the
 * only way to reach a child component's internals from here (same escape
 * `ui-table` and `ui-dropdown-menu` use for projected content). The
 * selectors are ANCHORED to `:host >` direct children, so the piercing
 * cannot escape the group. `ui-select` needed no `bare` input as a result.
 *
 * NO `overflow: hidden` on the frame — the members' menus (`ui-select`'s
 * listbox, `ui-date-input`'s `ui-date-picker`) are absolutely positioned
 * popovers hanging BELOW the field and would be clipped. The old
 * hand-rolled `.dual-sel-wrap` did clip, which is why its focus ring had
 * to be redrawn inside each half.
 *
 * WIDTHS. `layout="auto"` (default): each member is content-sized — a
 * `ui-select` measures its longest label, a `ui-date-input` its native
 * editor — and a caller who wants a wider member sizes THAT member's host
 * (the same "width only" rule every kit control follows). `layout="equal"`
 * shares the group's width equally between members instead.
 *
 * RESKIN: DLS has no borderless-inner combo (see the override above), so
 * this stays a kit composition around the DLS single-select / date-picker
 * delegates; keep the selector and `layout`.
 */
declare class UiSelectGroup {
    /** How members share the frame's width — see the class doc. */
    layout: _angular_core.InputSignal<"auto" | "equal">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiSelectGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiSelectGroup, "ui-select-group", never, { "layout": { "alias": "layout"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type UiDatePickerType = 'day' | 'month' | 'year';
interface UiDateRange {
    start: string | null;
    end: string | null;
}
interface DayCell {
    iso: string;
    day: number;
    inMonth: boolean;
    disabled: boolean;
}
interface MonthCell {
    index: number;
    label: string;
    disabled: boolean;
}
interface YearCell {
    year: number;
    inDecade: boolean;
    disabled: boolean;
}
/**
 * `ui-date-picker` — the DLS 3.1 `date-picker` component (page 305:2703,
 * set 160311:24981, range variant 160311:24968, REGISTER.md
 * §14, audited/round-built 2 Sep 2026). An element component: the panel
 * ONLY — the caller/host positions it (popover placement lives in
 * `ui-date-input`, the two callers of this component).
 *
 * Header cell set 6257:45570 (each state — default/inactive/today/selected/
 * hover/disabled/range-start/range-middle/range-end — is a documented node
 * in that set); header chrome 6260:37880 uses this kit's already-built
 * §7/§8 primitives: `«`/`‹`/`›`/`»` are `button[ui-icon-button] size="tiny"`
 * (24px, 16px chevron glyphs), the centre "Jul"/"2024" pair are
 * `button[ui-button] variant="secondary" size="tiny"` — DLS's header
 * buttons are OUTLINED tiny, which in this kit's vocabulary IS
 * `variant="secondary"` (register §7).
 *
 * Selected/today/range fills sit on `--color-primary` — the white-label
 * seam standing in for DLS's `product_alt` red (owner ruling carried from
 * §7-§20: "`--color-primary` as the seam for every product_alt use (date-
 * picker selection, tabs)"). Range-middle uses the lead-added
 * `--color-primary-subtle` / `--color-primary-subtle-hover` pair.
 *
 * Text is kit `label(sm)` 13px throughout (the DLS "label/sm 14" DLS-side
 * quirk this kit does not inherit — same standing ruling as Breadcrumb §6
 * and Button §7).
 *
 * TYPES — `type` is a model: the header's month/year buttons switch it (to
 * `month` / `year`) and picking a cell in either of those switches it back
 * to `day`, matching a normal calendar's drill-down/drill-up motion. Range
 * mode ignores `type` — a range is always two DAY grids side by side (DLS
 * 160311:24968 has no Range=Yes × Type=Month/Year cell).
 *
 * RANGE — two month grids (this month + next), 640 wide. First real click
 * on a day starts a new range (`start` = that day, `end` = null); the next
 * click closes it as `end` (earlier of the two becomes `start`). Apply
 * commits `rangeValue` and emits `applied`; Cancel discards the in-progress
 * pick and restores the last-applied range, emitting `cancelled`.
 *
 * TODAY (non-range footer) jumps `viewMonth` to the current month and picks
 * today in one action — DLS's single "Today" shortcut.
 *
 * KEYBOARD — roving tabindex over the visible grid: arrow keys move focus
 * (day grid: left/right ±1 day, up/down ±1 week; month/year grids: ±1 / ±3
 * across their 3-column layout), Home/End jump to the day grid's week
 * edges, Enter/Space picks the focused cell.
 *
 * RESKIN: delegate to the DLS Angular date-picker; keep this selector and
 * every input/output name above unchanged (`ui-date-input`, the two
 * callers, depend on the exact contract).
 */
declare class UiDatePicker {
    type: _angular_core.ModelSignal<UiDatePickerType>;
    /**
     * MONTH-TERMINAL MODE (kit-fixes item 21, 6 Sep 2026 — the table date
     * filter's "Month" segment is a `ui-date-input type="month"` whose
     * popover PICKS a month rather than drilling into a day grid). With
     * `monthOnly`, `type="month"` is the resting grid: picking a month cell
     * commits `value` as `YYYY-MM`, emits `picked` and stays on the month
     * grid; the year grid drills back to MONTH, not day; the selected month
     * paints `.dp-cell--selected`; and "Today" picks the current month.
     * Callers pass `type="month"` alongside it. Off by default — every
     * existing caller keeps the day-terminal drill-down.
     */
    monthOnly: _angular_core.InputSignal<boolean>;
    range: _angular_core.InputSignal<boolean>;
    value: _angular_core.ModelSignal<string | null>;
    rangeValue: _angular_core.ModelSignal<UiDateRange>;
    min: _angular_core.InputSignal<string | null>;
    max: _angular_core.InputSignal<string | null>;
    viewMonth: _angular_core.ModelSignal<string>;
    applied: _angular_core.OutputEmitterRef<UiDateRange>;
    cancelled: _angular_core.OutputEmitterRef<void>;
    picked: _angular_core.OutputEmitterRef<string>;
    protected readonly weekdayNames: string[];
    protected readonly today: string;
    /** Pending (unapplied) range selection — seeded from `rangeValue` and
     *  reset to it on Cancel; committed to it on Apply. */
    private pendingStart;
    private pendingEnd;
    protected hostClass: _angular_core.Signal<string>;
    protected monthLabel: _angular_core.Signal<string>;
    protected yearLabel: _angular_core.Signal<string>;
    protected nextMonthKey: _angular_core.Signal<string>;
    protected nextMonthLabel: _angular_core.Signal<string>;
    protected nextYearLabel: _angular_core.Signal<string>;
    protected decadeLabel: _angular_core.Signal<string>;
    private outOfRange;
    private buildDayCells;
    protected dayCells: _angular_core.Signal<DayCell[]>;
    protected nextDayCells: _angular_core.Signal<DayCell[]>;
    protected monthCells: _angular_core.Signal<MonthCell[]>;
    protected yearCells: _angular_core.Signal<YearCell[]>;
    protected focusedDay: _angular_core.Signal<string>;
    protected focusedMonthIndex: _angular_core.Signal<number>;
    /** The month cell `value` names, when it is a `YYYY-MM` in the viewed year (monthOnly). */
    protected selectedMonthIndex: _angular_core.Signal<number>;
    protected focusedYearIndex: _angular_core.Signal<number>;
    protected jumpMonth(delta: number): void;
    protected jumpYear(delta: number): void;
    protected pickDay(iso: string): void;
    protected pickMonth(index: number): void;
    protected pickYear(year: number): void;
    protected pickToday(): void;
    /** Range cell class list — computed per-cell rather than memoised (the
     *  pending selection lives outside the reactive graph, see the field
     *  comment above), matching the simple imperative style of the rest of
     *  this component's range logic. */
    protected rangeCellClass(cell: DayCell): string;
    protected pickRangeDay(iso: string): void;
    protected apply(): void;
    protected cancel(): void;
    private syncPendingFromModel;
    protected onDayKeydown(event: KeyboardEvent, iso: string): void;
    protected onGridKeydown(event: KeyboardEvent, index: number, total: number, cols: number, kind: 'month' | 'year'): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiDatePicker, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiDatePicker, "ui-date-picker", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "monthOnly": { "alias": "monthOnly"; "required": false; "isSignal": true; }; "range": { "alias": "range"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "rangeValue": { "alias": "rangeValue"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "viewMonth": { "alias": "viewMonth"; "required": false; "isSignal": true; }; }, { "type": "typeChange"; "value": "valueChange"; "rangeValue": "rangeValueChange"; "viewMonth": "viewMonthChange"; "applied": "applied"; "cancelled": "cancelled"; "picked": "picked"; }, never, never, true, never>;
}

/**
 * Neutral date input — same 32px shell as ui-select with a 16px calendar
 * icon (DLS column-header date filter, calendar_16).
 *
 * TWO FACES, ONE COMPONENT
 *
 * Outside a table this is exactly what it always was for TEXT/CVA purposes:
 * a native `<input type="date">` stays the field forms and modals bind to
 * — typing, `formControl`, keyboard entry are all untouched. What changed
 * (register §14, owner decision "both faces stop calling `showPicker()`"):
 * the 16px calendar glyph is now a REAL `button[ui-icon-button]` layered
 * over the native picker indicator (which is made inert with
 * `pointer-events: none` — see date-input.scss), and clicking it opens a
 * `ui-date-picker` popover instead of the UA's own calendar. Picking a day
 * there writes through the same `value` model the typed path uses.
 *
 * OPEN ON THE CLICK, NOT ON THE FOCUS (kit-fixes walk item 5, 6 Sep 2026;
 * corrected by the D4 regression audit the same day). The owner: "clicking
 * the date itself should also open the calendar picker, not only the icon;
 * the user can keep typing, but the picker should already be open." So the
 * native input's `mousedown`/`click` open the SAME `ui-date-picker` popover
 * the icon opens, and `Alt+ArrowDown` is the keyboard opener; focus stays in
 * the input (the popover is a sibling, nothing steals it), so typing
 * continues, and the native `input` event commits live so a typed valid date
 * moves the picker's month (`viewMonth` is derived from `value`) and its
 * selected cell. Opening is idempotent — a keystroke never re-opens or
 * re-seeds it. Escape closes (host listener, see below), a click outside the
 * component closes (document listener), and a `blur` whose `relatedTarget`
 * is outside the component closes (Tab away); a blur with NO relatedTarget
 * is left to the document click so a pointer landing on the popover's own
 * padding does not shut it. The UA `showPicker()` stays retired
 * (register §14 ruling).
 *
 * A BARE `focus` MUST NOT OPEN IT, and that is the correction. Item 5 as
 * first built also bound `(focus)="openStandalone()"`. `focus` is not a
 * user's decision to open a calendar — it is reached by Tab-ing through a
 * form, by any script that calls `.focus()`, and by an app focusing the
 * first invalid field after a failed submit. Each of those then dropped a
 * ~394px panel at `z-index: 1100` over whatever followed the field, and the
 * panel takes the pointer: in the FXGC Large Order form the "Tentative date
 * of trade" popover covers the whole Special Request Details card beneath
 * it, so the next real click lands on the calendar's header instead of on
 * the Sales Dealer select or the Pooling radios. Measured, 6 Sep: popover
 * 140→534, "Pooling of limits required" radio 168→188, entirely inside it.
 * It broke six e2e flows outright (`f11` b/c/d/e, `f10:80`, `f6d:199` — all
 * of them a real-pointer `check()` that Chromium's hit test correctly
 * refused) and forced two more specs to work around a popover no user had
 * asked for (`f24`'s `pickMonth` and its sign-off helper). Every route the
 * owner actually named — clicking the field, clicking the icon — is a
 * pointer event and is unaffected; the keyboard keeps `Alt+ArrowDown` and
 * the icon button, which is in the tab order. Do not re-add `(focus)`.
 *
 * ONE PICKER, NEVER TWO (owner bug, 6 Sep 2026 — D1 audit). The owner, on
 * the FXGC Large Order form in the Special Requests focus overlay: "the
 * date picker opens both the old browser date picker along with the new
 * one." Item 5 made the FIELD open the kit popover, but the field is still
 * a native `<input type="date">` and Chromium opens its OWN calendar from
 * that element's default mouse handling — so a single click summoned both.
 * Hiding `::-webkit-calendar-picker-indicator` (3 Sep) removes the glyph,
 * not the behaviour: the UA picker no longer has a visible trigger, yet the
 * input's own default action still opens it.
 *
 * The suppression is therefore on the EVENTS, not the glyph. Blink runs an
 * element's default handler only when the event was not `preventDefault()`ed,
 * so cancelling the default on the input's `mousedown` AND its `click` kills
 * every mouse path into the UA picker, in whichever of the two a given
 * Chromium version hangs it (the two are cancelled together deliberately:
 * this component cannot feature-detect which one, and cancelling both is
 * free). `Alt+ArrowDown`, Chromium's keyboard shortcut for the same picker,
 * is cancelled the same way and re-pointed at the kit popover, so the
 * keyboard has an opener too. `showPicker()` is never called (§14).
 *
 * The COST of cancelling `mousedown` is that the UA no longer focuses the
 * input for us, and no longer places the caret in the datetime segment the
 * pointer landed on: `onNativeMouseDown` focuses the input itself, and
 * Chromium then starts on the FIRST segment (day) wherever the click landed.
 * Typing is untouched — every segment is still reachable with arrow keys and
 * digits still overtype and advance (measured in a real Chromium, 6 Sep
 * 2026) — and `value` stays the same `YYYY-MM-DD` contract.
 *
 * ESCAPE STOPS AT THIS COMPONENT. `ui-modal-shell` (and `ui-modal`) listen
 * for Escape on `document`, so an Escape meant for this popover used to
 * close the whole focus overlay with it — with item 5 making the field an
 * opener, that turned "dismiss the calendar" into "throw the half-filled
 * form away". The host-level handler below closes the popover and
 * `stopPropagation()`s, so the shell never sees that keystroke; the
 * document-level listener stays as the fallback for an Escape pressed while
 * focus is outside the component, where nothing of ours is open to protect.
 *
 * PLACEMENT. The popover is host-relative `absolute`, so an ancestor that
 * scrolls (`ui-modal-shell`'s `.panel-content`, a table's scroller) clips it
 * at that box's edge. `measurePlacement` runs on every open: it finds the
 * nearest clipping ancestor, and if the panel does not fit below the field
 * but has more room above, the popover flips onto the field's top edge
 * (`.ui-date-popover--above`). A field low in a long overlay form — Date
 * Executed in the FXGC Large Order form is the real one — then opens a
 * whole calendar instead of a clipped strip.
 *
 * `type="month"` (kit-fixes item 21): the native field becomes
 * `<input type="month">`, `value` is `YYYY-MM`, and the popover opens as a
 * month-terminal `ui-date-picker type="month" monthOnly` — picking a month
 * commits it (see date-picker.ts). `min`/`max` (ISO date, or ISO month for
 * `type="month"`) pass through to both the native input and the picker;
 * a month bound is widened to its first/last day for the picker, which
 * compares ISO DATES.
 *
 * `min`/`max` ARE A RULE, NOT A HINT (D3, 6 Sep 2026 — owner bug). The Desk
 * Head's Trade Monitoring filter is `type="month"` with `max` at the signoff
 * month, and the field ended up DISPLAYING `2026-08` while its own `max` said
 * `2026-07` and the page filtered on July. The bound is a permission there —
 * the Desk Head must not be able to reach August at all — so the component
 * that owns `min`/`max` is the component that has to enforce them:
 *
 *   1. Every value the FIELD produces goes through `commit`, which clamps it
 *      into `[min, max]`. CLAMP, not reject-to-the-last-valid-value: the
 *      bound is the furthest the user may legally go, so snapping to it
 *      answers "how far can I actually get?" and keeps whatever else about
 *      the edit was legal; a revert answers nothing, throws away the legal
 *      half of a two-segment edit, and has no defined answer at all on first
 *      entry, when there is no last valid value to revert to. `type="date"`
 *      and `type="month"` take the identical path — only the grammar the
 *      bounds are normalised into differs (`boundMin`/`boundMax`).
 *   2. A refused value is written back onto the ELEMENT (`syncNative`).
 *      This is the half that the bug turned on and the half a consumer-side
 *      clamp structurally cannot do: `value.set(clamped)` does nothing when
 *      the clamp lands on the value the model already held, so the signal
 *      does not change, `nativeValue()` does not change, and Angular's
 *      `[value]` binding — which only writes when its own expression changes
 *      — never touches the input. Two sources of truth, and the visible one
 *      was the wrong one. The imperative write closes that.
 *
 * Because the refusal happens here and repairs the element itself, EVERY
 * consumer is covered, including the six that bind `[value]` + `(valueChange)`
 * one-way rather than `[(value)]` and so can never be written back into.
 *
 * The bound constrains what the FIELD and the PICKER can produce. A value
 * pushed in by the parent (the `[value]` binding, or `writeValue` from a
 * form) is the parent asserting its own state and is displayed as given —
 * exactly as a native `min`/`max` constrains the UI and validity without
 * policing assignment. An empty value is "unset", never "out of range".
 *
 * Inside a `ui-column-header` the control is a FILTER, and DLS specifies a
 * filter that a native date input provably cannot render:
 *
 *   unset        "All"                   native renders `dd/mm/yyyy`, and no
 *                                        placeholder attribute applies to
 *                                        `type="date"`
 *   single       "22/05/26"              native renders the UA locale form
 *   range        "22/05/26 - 30/05/26"   native holds ONE date, full stop
 *
 * So in that context a real trigger element paints the text, and clicking
 * it opens the SAME `ui-date-picker` popover — `range=true`, seeded from
 * the two ISO dates the trigger is already displaying, when the current
 * value parses as a range; `range=false` otherwise. This is what makes
 * range SELECTION real (previously the trigger could only DISPLAY a range;
 * `showPicker()` opened the UA's single-date picker). The native input
 * stays in the DOM, invisible, out of the tab order, purely so the two
 * faces keep one shared value/CVA path — it does no picking of its own in
 * this mode.
 *
 * The switch is CSS-only (`:host-context(ui-column-header)` in the
 * stylesheet), so no consumer passes a mode in and the standalone path keeps
 * its exact previous markup and metrics.
 *
 * Value is the native `YYYY-MM-DD` string (`YYYY-MM` for `type="month"`),
 * a `START/END` pair for a range, or null when unset. Anything else is
 * rendered verbatim, so a consumer can hand this a pre-formatted display
 * string without the component parsing it.
 *
 * `invalid` + `errorMessage` — the canonical error-state contract shared by
 * every kit form control (see ui-text-input for the full docstring). The
 * two are independent on purpose: a field can be marked invalid without a
 * message of its own.
 *
 * RESKIN: delegate to the DLS date picker; keep selector + inputs unchanged.
 *
 * OWNER REVIEW, 3 Sep 2026 — standalone face double-glyph fix, diagnosed
 * against DLS "Input field / Type=Date picker / Size=Small"
 * (76086:347425 default, 76086:347416 error, anatomy 76086:347429):
 *   1. The UA's own `::-webkit-calendar-picker-indicator` is now hidden
 *      outright (`display: none` in date-input.scss) instead of masked —
 *      the mask approach still left a second, inert glyph in the box. The
 *      native datetime EDITOR (the typed DD/MM/YYYY fields) stays; only the
 *      indicator affordance goes.
 *   2. The standalone input reserves the icon-button's room —
 *      `padding-right: 44px` (12 text-gap + 24 button + 8 clearance) — and
 *      the button itself sits at `right: 12px`, matching the DLS shell's
 *      12px edge inset instead of the old 8px that let long values run
 *      under it.
 *   3. Empty vs filled text colour now keys off a real `.is-empty` class
 *      (bound below from `!value()`) rather than relying on the UA's own
 *      placeholder styling, which `type="date"` doesn't expose consistently
 *      — see date-input.scss for the `::-webkit-datetime-edit` rules.
 */
declare class UiDateInput implements ControlValueAccessor {
    disabled: _angular_core.InputSignal<boolean>;
    value: _angular_core.ModelSignal<string | null>;
    /**
     * What the filter trigger shows when there is no value. 'All' is the DLS
     * default AND the sentinel every the reference app table already uses for "no filter",
     * so the eight existing consumers get the right text without passing it.
     * Only the trigger reads this — a native date input has no placeholder.
     */
    placeholder: _angular_core.InputSignal<string>;
    /** Error state — see ui-text-input's docstring for the shared contract. */
    invalid: _angular_core.InputSignal<boolean>;
    errorMessage: _angular_core.InputSignal<string>;
    /** `date` (default): `YYYY-MM-DD`. `month`: `YYYY-MM`, month-terminal picker. */
    type: _angular_core.InputSignal<"month" | "date">;
    /** Bounds — ISO date, or ISO month for `type="month"`; null = unbounded. */
    min: _angular_core.InputSignal<string | null>;
    max: _angular_core.InputSignal<string | null>;
    protected cvaDisabled: _angular_core.WritableSignal<boolean>;
    protected isDisabled: _angular_core.Signal<boolean>;
    protected isMonth: _angular_core.Signal<boolean>;
    private host;
    /** Which edge of the field the popover hangs off — see measurePlacement. */
    protected popoverAbove: _angular_core.WritableSignal<boolean>;
    /** Standalone-face popover state. */
    protected standaloneOpen: _angular_core.WritableSignal<boolean>;
    protected standaloneViewMonth: _angular_core.Signal<string>;
    /** What the standalone picker highlights: the value when it is a clean
     *  ISO date / month; nothing for a range or a verbatim string. */
    protected standaloneSeed: _angular_core.Signal<string | null>;
    /** A month bound widened to a date bound — the picker compares ISO dates. */
    protected pickerMin: _angular_core.Signal<string | null>;
    protected pickerMax: _angular_core.Signal<string | null>;
    /**
     * The same two bounds in the VALUE's grammar rather than the picker's.
     * `pickerMin`/`pickerMax` above always resolve to ISO dates because
     * `ui-date-picker` compares days; the clamp below compares against `value`
     * itself, which is `YYYY-MM` under `type="month"`. Two readings of one
     * pair of inputs, for two consumers — not a duplicate.
     *
     * Both are zero-padded ISO, so `<` / `>` on the strings IS the chronological
     * comparison and no Date parsing is needed. A bound written in the other
     * grammar is normalised the permissive way, matching the widening above: a
     * `YYYY-MM-DD` bound on a month field reduces to its month (the month is
     * reachable, it just is not reachable on every day), and a `YYYY-MM` bound
     * on a date field widens to that month's first/last day.
     */
    private boundMin;
    private boundMax;
    private isBounded;
    private inValueGrammar;
    /** The native `<input>` — the element `syncNative` repairs. Always
     *  rendered (both faces share it), so the query always resolves. */
    private nativeRef;
    /** Column-header-face popover state. */
    protected triggerOpen: _angular_core.WritableSignal<boolean>;
    /** Snapshot of range-ness taken when the popover OPENS — the picker's own
     *  in-progress edits should not flip the layout under the user. */
    private triggerRangeSnapshot;
    protected triggerIsRange: _angular_core.Signal<boolean>;
    protected triggerSingleSeed: _angular_core.Signal<string | null>;
    protected triggerRangeSeed: _angular_core.Signal<UiDateRange>;
    protected triggerViewMonth: _angular_core.Signal<string>;
    /**
     * What the trigger paints — placeholder, single date, month, range, or a
     * verbatim string. The native input below never sees the last two.
     */
    protected displayText: _angular_core.Signal<string>;
    /**
     * What the native input can actually accept. A range seeds the picker with
     * its START date; anything else unparseable clears the native input rather
     * than letting the UA silently blank a value we are still displaying.
     */
    protected nativeValue: _angular_core.Signal<string>;
    private onChange;
    protected onTouched: () => void;
    /** Both `input` (live, while typing) and `change` land here; the model
     *  only moves when the native value actually differs, so the two events
     *  for one edit commit once. */
    protected onInput(event: Event): void;
    /** Standalone face — a pointer press on the input (or `Alt+ArrowDown`)
     *  OPENS the popover, never toggles: a second click on an open field
     *  keeps it open; the icon button below is the toggle. Focus stays in
     *  the input. NOT called from a bare `focus` — see the class docstring's
     *  "OPEN ON THE CLICK, NOT ON THE FOCUS". */
    protected openStandalone(): void;
    /**
     * Mousedown on the native field. `preventDefault()` is what stops the UA's
     * own calendar (see the class docstring) — it also stops the UA focusing
     * the input, so that is done here instead. Both are unconditional, before
     * the disabled check: a disabled input dispatches no mouse events at all,
     * and if a future state ever let one through the UA picker must still not
     * open on it.
     */
    protected onNativeMouseDown(event: MouseEvent): void;
    /**
     * The other half of the UA-picker suppression: some Chromium versions open
     * the picker from the input's `click` default handler rather than its
     * `mousedown` one. Cancelling the click's default costs nothing here (an
     * `<input type="date">` has no other click default worth keeping — focus
     * has already happened at mousedown).
     *
     * It ALSO opens the popover, so that "clicking the field opens the picker"
     * survives the one click route that has no `mousedown` of its own: label
     * activation. Clicking a `<label for>` runs the synthetic click activation
     * steps on the labelled control — a `click` and nothing else — so without
     * this a labelled date field would focus but not open. Idempotent, so on
     * the ordinary pointer route (mousedown → click) this is a no-op.
     */
    protected onNativeClick(event: MouseEvent): void;
    /**
     * `Alt+ArrowDown` is Chromium's keyboard shortcut for the UA picker, so it
     * is cancelled like the mouse paths and re-pointed at the kit popover —
     * the keyboard keeps an opener, and it is ours. `Alt+ArrowUp` closes,
     * matching the combobox convention. Every other key falls through
     * untouched, so typing a date is exactly what it was.
     */
    protected onNativeKeydown(event: KeyboardEvent): void;
    /** Standalone face — the icon button opens/closes the popover. */
    protected toggleStandalone(event: Event): void;
    /** Tab away closes; a blur with no relatedTarget is left to the document
     *  click (a pointer on the popover's own padding must not shut it). */
    protected onNativeBlur(event: FocusEvent): void;
    protected onStandalonePicked(iso: string): void;
    /** Column-header face — the trigger opens/closes the (possibly ranged) popover. */
    protected toggleTrigger(event: Event): void;
    protected onTriggerPicked(iso: string): void;
    protected onTriggerApplied(range: UiDateRange): void;
    protected closeTrigger(): void;
    protected onDocumentClick(event: Event): void;
    /**
     * Escape while this component holds focus. Closes OUR popover and stops
     * there: `ui-modal-shell` / `ui-modal` / `ui-drawer` all listen for Escape
     * on `document`, and without the `stopPropagation()` below the same
     * keystroke that dismisses the calendar also closes the focus overlay the
     * field is sitting in — with a half-filled form inside it. Only swallowed
     * when something of ours is actually open, so Escape keeps its normal
     * "close the overlay" meaning everywhere else.
     */
    protected onHostEscape(event: Event): void;
    /** Fallback for an Escape pressed while focus is OUTSIDE the component
     *  (a popover left open by a pointer that never landed in the field). */
    protected onEscape(): void;
    /**
     * Decide, at open time, whether the popover hangs below the field or above
     * it. The panel is host-relative `absolute`, so the box that clips it is
     * the nearest scrolling/clipping ancestor (a focus overlay's
     * `.panel-content`, a table's scroller) or the viewport when there is
     * none. If the panel does not fit below but has more room above, it flips.
     */
    private measurePlacement;
    /**
     * Backspace / Delete on the trigger resets the filter to unset. The native
     * date input has no clear affordance of its own, so without this there is no
     * way back to "All" once a date is picked.
     */
    protected clear(event: Event): void;
    /**
     * The single funnel every value the field or the picker produces goes
     * through — typing, a picked day, a picked month, an applied range, a
     * clear. `min`/`max` are enforced HERE, so there is exactly one place the
     * rule lives and no consumer has to restate it.
     */
    private commit;
    /**
     * `v` pulled into `[min, max]`. Nulls and empties pass through untouched —
     * an unset field is "no date", not "a date out of range", which is also
     * how a native input reads it (`required` is the input that would object).
     * A value in neither ISO grammar is a verbatim display string with nothing
     * to compare against, and passes through as well.
     */
    private clampToBounds;
    /**
     * Force the native input back onto what the model holds. The `[value]`
     * binding cannot be relied on for this — see `commit` — so the repair is
     * imperative and guarded so it is a no-op whenever the two already agree.
     */
    private syncNative;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiDateInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiDateInput, "ui-date-input", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

type UiTagVariant = 'neutral' | 'green' | 'red' | 'amber' | 'purple';
declare const statusVariant: (status: string | null | undefined) => UiTagVariant;
/**
 * Neutral status tag — the single pill for every status on the platform
 * (Figma 14421:204390). Pass `status` and the variant is inferred; pass
 * `variant` to override, `label` to display different text.
 *
 * DLS `tag-status` (§42, Figma 407:19) has five types — Default, Success,
 * Warning, Critical, Information — pill radius, 8px h-padding, label/sm
 * `text-strong`. This kit's fourth-to-fifth mapping is neutral/green/red/
 * amber/purple: same geometry (2px off-grid vertical padding, see
 * status-tag.scss), the fifth (`variant="purple"`, `--color-tag-purple`
 * #e2d6ff) added Round 41 agent B with no status string routed to it yet
 * — see the doc comment above `statusVariant`.
 *
 * RESKIN: delegate to the DLS badge; keep selector + inputs unchanged.
 */
declare class UiStatusTag {
    status: _angular_core.InputSignal<string | undefined>;
    label: _angular_core.InputSignal<string | undefined>;
    variant: _angular_core.InputSignal<UiTagVariant | undefined>;
    protected resolvedVariant: _angular_core.Signal<UiTagVariant>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiStatusTag, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiStatusTag, "ui-status-tag", never, { "status": { "alias": "status"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** DLS `tag-info`'s two types (§42) — see the class doc for the anatomy. */
type UiTagInfoType = 'category' | 'product';
/**
 * Both DLS colour axes share one input: Category picks a solid fill,
 * Product picks an outline. `'grey'` is legal for BOTH (a different
 * treatment each time — see tag-info.scss) so the union is not split by
 * type; passing a colour DLS has no cell for on the current `type` (e.g.
 * `type="product" colour="ginger"`) renders no fill/border at all rather
 * than silently falling back, the same "loud gap, not silent drift" rule
 * `statusVariant` follows.
 */
type UiTagInfoColour = 'grey' | 'ginger' | 'lemon' | 'melon' | 'mint' | 'lavender' | 'acai' | 'red' | 'purple' | 'blue';
/**
 * `tag-info` — DLS's two-type recency/categorisation marker (§42, Figma
 * 5322:36053). 20px tall, 4px h-padding, radius `indicator` (4), label/2xs
 * (10px) — always, regardless of type.
 *
 *   <ui-tag-info />                                     // "NEW", category/grey
 *   <ui-tag-info label="BETA" />
 *   <ui-tag-info type="category" colour="mint" label="TRIAL" />
 *   <ui-tag-info type="product" colour="blue" label="Live" />
 *
 * **Category** — a SOLID primitive fill with `--color-text-on-bright-strong`:
 * grey/ginger/lemon/melon/mint/lavender/acai, 7 flats DLS reaches past its
 * own semantic layer for ("widely used, low visual hierarchy, for
 * categorisation" — DLS's own words). **Product/Services** — OUTLINED, 1px
 * border + matching text, no fill: red (this white-label's `--color-primary`
 * seam for DLS `product_alt` #ff3e3e), grey (`--color-icon` border /
 * `--color-text-subtle` text), purple (purple-40/purple-90), blue
 * (blue-20/sky-70). See tokens.css's "DLS Tag family" block for every hex.
 *
 * `label` keeps its `'NEW'` default from before this axis existed — the
 * Special Requests call site (`<ui-tag-info />`, no type/colour bound)
 * still compiles and renders unchanged in TYPE/RADIUS/geometry; its FILL
 * changes from the old placeholder `--color-tag-new` (a value with no DLS
 * role behind it, per this file's prior doc comment) to the real harvested
 * Category/Grey (`--color-tag-info-grey` #dde3e7), now that `type`
 * defaults to `'category'` and `colour` to `'grey'` — the DLS-accurate
 * reading of a bare "NEW" chip.
 *
 * NOT a `ui-status-tag` variant, deliberately — different question
 * (positional "which is newest / what kind is this?" vs "what state is
 * this thing in?"), different geometry (radius 4 not pill, label/2xs not
 * label/sm), different type ramp, DLS names it separately and so does
 * this kit. See the original doc comment history for the full argument.
 *
 * RESKIN: check the Angular DLS Storybook for `tag-info` and wrap it,
 * keeping the `ui-tag-info` selector and the `label`/`type`/`colour`
 * inputs. If there is none, token-reskin this implementation — every
 * colour is already a named token in tokens.css, so re-pointing those is
 * the whole job.
 */
declare class UiTagInfo {
    /** Chip text. Uppercase is the content's job, not a text-transform. */
    label: _angular_core.InputSignal<string>;
    /** DLS Category (solid fill) or Product/Services (outlined). */
    type: _angular_core.InputSignal<UiTagInfoType>;
    /** Which of the type's colours to paint — see `UiTagInfoColour`. */
    colour: _angular_core.InputSignal<UiTagInfoColour>;
    protected hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTagInfo, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTagInfo, "ui-tag-info", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "colour": { "alias": "colour"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type UiEmptyStateIllustration = 'dog' | 'cactus' | 'slot';
/**
 * Empty state — the DLS 3.1 `empty-state` component (page 467:1104, set
 * 274552:3254, REGISTER.md §17, audited + rebuilt 2 Sep 2026 —
 * the §13–§20 round). Type Default | Slot: 400 wide, centred column, 16px
 * gap between illustration / text block / action; text block is a 4px-gap
 * stack of title + description.
 *
 *   <ui-empty-state title="Inbox is empty" text="Nothing needs your attention right now." />
 *
 * **Illustration** — OWNER'S RULING (2 Sep 2026): the archived DLS
 * `object-dog-empty-bowl` SVG (the kit's asset archive,
 * harvested before the DBS library access lapsed) is the DEFAULT now, at
 * DLS's own 151px (node 11690:95830) — the kit's own cactus illustration
 * (kept behind `illustration="cactus"` so a caller can opt back rather
 * than losing it outright) is RETIRED as the default; all 33 existing
 * callers re-render with the dog at 151, unchanged markup. `size` still
 * overrides the pixel dimensions of whichever illustration is active.
 *
 *   <ui-empty-state illustration="cactus" title="No matches" text="Try a different filter." />
 *
 * **Slot** (274552:3559) — `illustration="slot"` swaps in a caller-projected
 * illustration via `[uiEmptyStateIllustration]` instead of either built-in
 * SVG — DLS's own Type=Slot reading, for the rare illustration neither
 * built-in covers:
 *
 *   <ui-empty-state illustration="slot" title="No signal" text="Check back later.">
 *     <svg uiEmptyStateIllustration width="151" height="151">…</svg>
 *   </ui-empty-state>
 *
 * **Action** (below the text block, 16px gap) — an optional
 * `[ui-empty-state-action]` slot, DLS's own secondary SMALL button reading;
 * the caller supplies its own `ui-button`, this component only reserves
 * the slot and the gap:
 *
 *   <ui-empty-state title="No drafts" text="Start a new one to see it here.">
 *     <button ui-empty-state-action ui-button variant="secondary" size="small" (click)="create()">New draft</button>
 *   </ui-empty-state>
 *
 * Layout: title kit `heading(2xs)` 14/600 `--color-text-strong` — DLS
 * prints `heading/2xs` at 16px for this role; the platform's compactness
 * override (REGISTER.md, the accordion/badge/card titles)
 * keeps it at 14, carried here rather than chased back to 16. Description
 * `body(sm)` 13px `--color-text-subtle`.
 *
 * Existing class names (`.title`, `.text`) are kept unchanged — f49-dls-card's
 * `card-body ui-empty-state .title` assertion, and every other caller that
 * greps for them, still passes.
 *
 * Docblock node refs for the record: set 274552:3254; Default 11690:95830;
 * Slot 274552:3559.
 *
 * RESKIN: swap the illustration/typography per DLS empty-state pattern;
 * keep selector + inputs unchanged.
 */
declare class UiEmptyState {
    title: _angular_core.InputSignal<string | undefined>;
    text: _angular_core.InputSignal<string | undefined>;
    size: _angular_core.InputSignal<number>;
    /** DLS's illustration axis — `dog` (default, the archived DLS asset) | `cactus` (the kit's own, kept as an opt-in) | `slot` (a caller-projected illustration via `[uiEmptyStateIllustration]`). */
    illustration: _angular_core.InputSignal<UiEmptyStateIllustration>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiEmptyState, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiEmptyState, "ui-empty-state", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "illustration": { "alias": "illustration"; "required": false; "isSignal": true; }; }, {}, never, ["[uiEmptyStateIllustration]", "[ui-empty-state-action]"], true, never>;
}

/**
 * Canonical table column header — DBS DLS "column-header" (Figma 116:669,
 * grown to the full Table spec at 197362:* — see REGISTER.md
 * §40 "column-header").
 *
 * ANATOMY — two sizes, both 4px-stepped off the same content row:
 *
 *   size="xs" (default, 232px reference cell, 4px vertical inset):
 *   ┌─ column-header ─────────────── 232 x 64 ─┐
 *   │ content     y=4  h=24   label + indicator │  <- the 32px variant stops here
 *   │ ↕ gap 8 (--gap-block-v)                   │
 *   │ input-field y=36 h=24   the filter slot   │
 *   └───────────────────────────────────────────┘
 *
 *   size="sm" (8px vertical inset, 32px filter control):
 *   ┌─ column-header ─────────────── 232 x 80 ─┐
 *   │ content     y=8  h=24   label + indicator │  <- the 40px variant stops here
 *   │ ↕ gap 8 (--gap-block-v)                   │
 *   │ input-field y=40  h=32   the filter slot  │
 *   └───────────────────────────────────────────┘
 *
 * xs: 64px tall with a filter, 32px without. sm: 80px with a filter, 40px
 * without (the filter row collapses itself either way). Horizontal padding
 * is 24/8 first, 8/8 interior, 8/24 last — the blotter gutter rule, NOT an
 * equal 24 everywhere. `variant="merged"` is the one exception: always 8/8,
 * no sort, no filter — see below.
 *
 * USAGE
 *
 *   <ui-column-header label="Name" />
 *   <ui-column-header label="Name" [sortable]="true" sortDirection="asc" (sort)="..." />
 *   <ui-column-header label="Name" [sortable]="true" [filtered]="true">
 *     <ui-select ... />                          <!-- default slot: the filter control -->
 *   </ui-column-header>
 *   <ui-column-header label="Notional" align="end" [sortable]="true" />
 *   <ui-column-header label="Name"><svg header-info ... /></ui-column-header>
 *   <ui-column-header variant="checkbox">
 *     <ui-checkbox header-checkbox aria-label="Select all"
 *                  [checked]="..." [indeterminate]="..." (checkedChange)="..." />
 *   </ui-column-header>
 *   <ui-column-header variant="blank" />
 *   <ui-column-header variant="merged" label="Trade details" />  <!-- colspan via the consumer's <th> -->
 *   <ui-column-header size="sm" label="Name" [sortable]="true" />
 *
 * API
 *   label          string                                       ''        optional — `blank` has none
 *   sortable       boolean                                       false     renders the sort indicator + key/click affordance
 *   sortDirection  'none' | 'asc' | 'desc'                      'none'    picks which of the three glyphs paints
 *   align          'start' | 'end'                               'start'   `end` right-aligns and puts the glyph BEFORE the label
 *   filtered       boolean                                       false     a filter is applied — glyph goes active blue
 *   variant        'default' | 'checkbox' | 'blank' | 'merged'  'default' structural variant
 *   size           'xs' | 'sm'                                   'xs'      DLS Extra small (default) | Small
 *   first          boolean                                       false     24px left gutter
 *   last           boolean                                       false     24px right gutter
 *   borderLeft     boolean                                       false     DLS left-border, hidden by default
 *   borderRight    boolean                                       false     DLS right-border, hidden by default
 *   tone           'plain' | 'band'                               'plain'   `band` = grey header band (card-wrapped tables)
 *   (sort)         void                                                     emitted on click / Enter when sortable
 *
 * SLOTS
 *   (default)          the filter control — ui-select / ui-date-input. Collapses when empty.
 *                       Not rendered for variant="merged". Renders at 24 tall for size="xs",
 *                       32 tall for size="sm" (projected-content override lives in
 *                       styles/ui-tables.css, keyed off --ui-ch-filter-h).
 *   [header-info]      optional 16px info icon after the label. Consumer supplies the icon.
 *   [header-checkbox]  the select-all checkbox for variant="checkbox". THE SLOT TAKES THE KIT
 *                      CONTROL — `<ui-checkbox header-checkbox …>`, never a raw
 *                      `<input type="checkbox">`. This component is a frame that projects
 *                      whatever it is handed, so a caller passing a native input silently
 *                      ships an un-reskinnable browser checkbox into a DLS table header;
 *                      that is exactly how four sink demos drifted (owner finding,
 *                      7 Sep 2026 — see the kit's internal notes). The consumer
 *                      still owns the STATE: `[checked]` / `[indeterminate]` in,
 *                      `(checkedChange)` out — this component owns only the frame.
 *                      `ui-checkbox` has no `ariaLabel` input, so a label-less select-all
 *                      carries a plain `aria-label` attribute on the host element.
 *
 * ALIGNMENT is a DATA-TYPE decision in DLS: text columns `start`, numeric
 * columns `end`. No consumer uses `align` yet — rollout is a later phase.
 *
 * variant="merged" (DLS 197362:20905) is the grouped-column header: label +
 * optional [header-info] ONLY — no sort indicator, no filter, regardless of
 * what `sortable`/`filtered` are set to. Horizontal padding is a flat 8/8
 * even when `first`/`last` are set — it spans several columns via the
 * consumer's `colspan`, so the surface-edge gutter doesn't apply. Content
 * row stays 24px so it lines up with the ordinary headers below it.
 *
 * The host `<th>` sets width/sticky only, with `padding: 0`; this component IS
 * the cell.
 *
 * RESKIN: delegate to the DLS table header cell; keep the selector and every
 * input name above unchanged — nine tables bind them.
 */
declare class UiColumnHeader {
    /** Optional — `variant="blank"` has no label, so this is not required. */
    label: _angular_core.InputSignal<string>;
    sortable: _angular_core.InputSignal<boolean>;
    /** Which sort glyph paints. Purely presentational — the consumer owns the sort state. */
    sortDirection: _angular_core.InputSignal<"none" | "asc" | "desc">;
    /** DLS aligns by data type: text `start`, numeric `end` (glyph before the label). */
    align: _angular_core.InputSignal<"start" | "end">;
    /** A filter is applied on this column — the glyph goes active blue. */
    filtered: _angular_core.InputSignal<boolean>;
    variant: _angular_core.InputSignal<"default" | "checkbox" | "blank" | "merged">;
    /** DLS Extra small (default, 32/64) | Small (40/80). Medium is out of scope (owner decision). */
    size: _angular_core.InputSignal<"xs" | "sm">;
    first: _angular_core.InputSignal<boolean>;
    last: _angular_core.InputSignal<boolean>;
    /** DLS left/right cell borders — both hidden by default. */
    borderLeft: _angular_core.InputSignal<boolean>;
    borderRight: _angular_core.InputSignal<boolean>;
    tone: _angular_core.InputSignal<"plain" | "band">;
    sort: _angular_core.OutputEmitterRef<void>;
    /** Sorted OR filtered — either one paints the indicator in the product blue.
     *  variant="merged" never sorts or filters, DLS-spec, regardless of the inputs above. */
    protected readonly active: _angular_core.Signal<boolean>;
    /** merged never renders the sort affordance, even if a consumer passes sortable=true. */
    protected readonly showSort: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiColumnHeader, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiColumnHeader, "ui-column-header", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "sortable": { "alias": "sortable"; "required": false; "isSignal": true; }; "sortDirection": { "alias": "sortDirection"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; "filtered": { "alias": "filtered"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "first": { "alias": "first"; "required": false; "isSignal": true; }; "last": { "alias": "last"; "required": false; "isSignal": true; }; "borderLeft": { "alias": "borderLeft"; "required": false; "isSignal": true; }; "borderRight": { "alias": "borderRight"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; }, { "sort": "sort"; }, never, ["[header-info]", "[header-checkbox]", "*"], true, never>;
}

/**
 * Full-screen modal shell — the shared overlay/panel/header chassis of the
 * Trade Monitoring modals (ported from the React ModalBase + ClarifyModal
 * header), grown ADDITIVELY onto the DLS 3.1 `focus-overlay` component
 * (page 30431:265173, set 166757:29322, REGISTER.md §19,
 * audited 2 Sep 2026). Render it conditionally; content projects into the
 * scroll body:
 *
 *   @if (open()) {
 *     <ui-modal-shell title="Clarification Request" (closed)="open.set(false)">
 *       <ui-card>…</ui-card>
 *     </ui-modal-shell>
 *   }
 *
 * All 17 existing callers pass only `title`/`closed`/projected content and
 * keep rendering BYTE-IDENTICAL — every input below is opt-in and defaults
 * off.
 *
 * **Header** (166757:29336) — the title row gains three optional pieces,
 * all before/around the existing `panel-title`:
 * - `back` + `(backActivated)` — a leading `button[ui-icon-button]`
 *   (`size="small"`, 24px chevron-left), 12px before the title group.
 * - `[ui-modal-icon]` slot (`hasIcon` gates the disc) — a 32px circular
 *   disc rendered before the title group. DLS's crimson-00 fill (#fff2f2)
 *   has no token in this kit yet; `--color-bg-danger-subtlest` (#fff0f0)
 *   is the nearest existing step (1 value off, the kit's own danger-tint
 *   role) and is used here rather than adding a new token for a 1-unit
 *   delta. Glyph is projected at 16px, coloured `--color-danger`.
 * - `subtitle` — kit `body(sm)` 13px, `--color-text-subtle`, 4px under the
 *   title, max-width 800. `title-group` gets a 32px min-height so a
 *   subtitle-less title still centres against a 32px back/icon/actions row.
 *
 * `[ui-modal-actions]` slot renders BEFORE the close button in the actions
 * group (8px gap, -4px optical right margin to match the close button's
 * own optical trim) — e.g. a projected more-vertical icon-button. The
 * close button itself is now a real `button[ui-icon-button]` size="small"
 * (same precedent `ui-drawer`'s close/back buttons set, §15) — class name
 * `.close-btn` and `aria-label="Close"` are kept for existing spec
 * locators, but the glyph now follows icon-button's own 24px-at-Small
 * sizing rather than its old hand-rolled 16px.
 *
 * `[ui-modal-stepper]` / `[ui-modal-tabs]` header slots render under the
 * title row (16px gap) inside the header container. The tabs slot zeroes
 * the header's own bottom padding and takes `--shadow-sticky-top` (DLS's
 * tab-group-under-header reading, 166757:29354) — the Stepper (walk item
 * 38) and Tabs (walk item 41) rounds own the real anatomy; for now the
 * sink projects a placeholder `ui-tabs` / static step row into them.
 *
 * **Body** (166757:29415) — `loading` swaps the projected content for two
 * `ui-skeleton type="text"` cards (REGISTER.md §27, kit
 * `loader`/`skeleton` round, 3 Sep 2026 — unified off this component's own
 * former hand-rolled `.ms-skeleton-card`/`.ms-skeleton-bar` markup, which
 * duplicated the same DLS `loader-skeleton` anatomy `ui-skeleton` now
 * owns), 16px gap between the two cards via `.ms-skeleton`.
 * `aria-busy="true"` on the body while loading.
 *
 * **Footer** (`[ui-modal-footer]`, 5 Sep 2026) — an optional action bar
 * pinned to the panel's bottom edge, gated by `hasFooterSlot` exactly the
 * way `hasTabsSlot` gates the tabs slot (the caller says it projects the
 * slot; the shell renders the `<footer>` chrome only then, so a
 * footer-less shell stays byte-identical):
 *
 *   <ui-modal-shell title="…" [hasFooterSlot]="true" (closed)="…">
 *     <ui-card>…</ui-card>
 *     <button ui-modal-footer ui-button variant="secondary" (click)="cancel()">Cancel</button>
 *     <button ui-modal-footer ui-button variant="primary" (click)="submit()">Submit</button>
 *   </ui-modal-shell>
 *
 * Right-aligned, 8px gap, 16px vertical / 40px horizontal padding (the
 * same 40px gutter the header uses), `--color-border-decorative` top rule,
 * `--color-bg-level1` ground. It is a flex sibling of the scroll body, not
 * inside it, so it stays put while the body scrolls behind it — the
 * "sticky" reading with no `position: sticky` needed. Directive 6 still
 * applies to a footer-less shell (action buttons OUTSIDE the cards, below
 * the last one, inside the body); the footer is for the flows the owner
 * has ruled want the actions always on screen.
 *
 * Kit-fixes walk item 3 (6 Sep 2026): the footer's content sits in the
 * SAME 1200px-capped centred inner column the header uses
 * (`.ms-footer-inner`), so at any viewport width the last right action's
 * right edge lines up with the close X (the column's right edge = the X
 * glyph's right edge). A second slot, `[ui-modal-footer-start]`, renders
 * a left-side group flush with the header's left edge — the same
 * start/end split `[ui-actions-row]`'s `align="between"` gives a body
 * row:
 *
 *   <button ui-modal-footer-start ui-button variant="plain" (click)="back()">Back</button>
 *   <button ui-modal-footer ui-button variant="secondary" (click)="cancel()">Cancel</button>
 *   <button ui-modal-footer ui-button variant="primary" (click)="submit()">Submit</button>
 *
 * Both slots share the one `hasFooterSlot` gate; the start group collapses
 * (`:empty`) when nothing projects into it, so a right-only footer is
 * unchanged apart from the column cap.
 *
 * Items 6 and 20 of the same walk: the header and footer are lifted above
 * the scroll body in stacking order (`position: relative; z-index: 1`) so
 * the header's elevation-2 shadow stays visible over scrolled cards, and
 * the panel now fills the viewport edge to edge with SQUARE corners — no
 * 24px top inset, no `--radius-md` on the panel/header (DLS's focus
 * overlay is full-viewport; the sheet-like inset and radii were this
 * shell's own).
 *
 * The panel ground under the header was already `--color-bg-app`
 * (#f5f7f9), the same hex DLS's level_0 token resolves to — switched to
 * `--color-bg-level0` (added this round, tokens.css) so the name matches
 * the DLS role; no visual change.
 *
 * Padding stays the OWNER'S gutter rule (directive 7: 24px top/bottom,
 * 40px left/right on the grey body — NOT DLS's 24/16 header split), same
 * as before this round. Content in the body follows directive 6 (focus
 * overlays): `ui-card`s 16px apart via the panel's own stack gap, action
 * buttons live OUTSIDE the cards, below the last one — a caller concern,
 * unchanged by this round.
 *
 * RESKIN: delegate to the DLS focus-overlay component (`dbs-focus-
 * overlay` — DLS naming; nothing to do with the retired React `angular/`
 * prototype's `ModalBase`); keep this selector and every input.
 */
declare class UiModalShell {
    title: _angular_core.InputSignal<string>;
    closed: _angular_core.OutputEmitterRef<void>;
    /** Same pattern `ui-drawer` uses — a document-level listener since the panel itself does not (and should not) hold focus for keyboard dismissal to work. */
    protected onEscape(): void;
    /** DLS gap (b) — kit `body(sm)`, `--color-text-subtle`, 4px under the title, max-width 800. */
    subtitle: _angular_core.InputSignal<string | undefined>;
    /** Gates the 32px circular `[ui-modal-icon]` disc — projecting the slot alone does not render the disc chrome. */
    hasIcon: _angular_core.InputSignal<boolean>;
    /** Leading 32px `back` icon-button before the title group. */
    back: _angular_core.InputSignal<boolean>;
    backActivated: _angular_core.OutputEmitterRef<void>;
    /** DLS's Loading body state — two skeleton cards replace projected content; `aria-busy` on the body. */
    loading: _angular_core.InputSignal<boolean>;
    /** Whether the caller projects `[ui-modal-tabs]` — set by callers that use the slot, so the header can zero its own bottom padding and take the sticky-top shadow without a content query (Angular content queries cannot see inside an attribute-selector slot from the outside). */
    hasTabsSlot: _angular_core.InputSignal<boolean>;
    /** Whether the caller projects `[ui-modal-footer]` — same contract as `hasTabsSlot`: set it and the shell renders the pinned footer bar around the slot. */
    hasFooterSlot: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiModalShell, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiModalShell, "ui-modal-shell", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "hasIcon": { "alias": "hasIcon"; "required": false; "isSignal": true; }; "back": { "alias": "back"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "hasTabsSlot": { "alias": "hasTabsSlot"; "required": false; "isSignal": true; }; "hasFooterSlot": { "alias": "hasFooterSlot"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "backActivated": "backActivated"; }, never, ["[ui-modal-icon]", "[modal-title]", "[ui-modal-actions]", "[ui-modal-stepper]", "[ui-modal-tabs]", "*", "[ui-modal-footer-start]", "[ui-modal-footer]"], true, never>;
}

interface UiTab {
    key: string;
    label: string;
    count?: number | string;
    /**
     * Optional leading 24×24 icon, as an SVG `<path d>` string rendered
     * inside a fixed `viewBox="0 0 24 24"`.
     *
     * NOT an icon-registry name — this kit has no icon registry (every other
     * icon consumer inlines its own `<svg>`), so a name would resolve
     * nowhere. NOT a projected `TemplateRef<{$implicit: UiTab}>` either: that
     * would force every one of the eight existing callers (inbox, mandates,
     * npa-dashboard, murex-v2 ×2, external-platforms, org-profile-drawer) to
     * either add a template they don't need or fight Angular's lack of a
     * clean per-array-item outlet, just so the ONE new icon demo can have
     * one. A raw path string keeps `ui-tabs` self-contained — one
     * `<svg><path/></svg>` per tab, nothing to register, nothing to wire at
     * call sites that never touch it (`iconPath` stays `undefined`).
     */
    iconPath?: string;
}
/**
 * Canonical tab bar — DLS `tab` / `tab-group` (REGISTER.md
 * §41, Figma 305:2714 page, `tab` node 421:23, `tab-group` node
 * 76086:350921, audited 4 Sep 2026). Grown from the original 40px/label(md)
 * bar to the full DLS anatomy while keeping the `tabs`/`active` API frozen
 * — eight app templates bind it today (inbox, mandates, npa-dashboard,
 * murex-v2 ×2, external-platforms, org-profile-drawer) and none of them
 * changes shape from this round.
 *
 *   <ui-tabs [tabs]="tabs" [(active)]="activeTab" />                          <!-- unchanged, "plain" -->
 *   <ui-tabs [tabs]="tabs" [(active)]="activeTab" size="md" variant="panel" />
 *
 * ── `size` — DLS Small (40, default) | Medium (48) ──────────────────────
 * Height only; label stays `label(md)` at both sizes (DLS doesn't resize
 * the type between them, only the row).
 *
 * ── `variant` — geometry opt-in, NOT a states opt-in ─────────────────────
 * `plain` (default) = today's look: no host padding, the pre-existing 1px
 * `--color-border-decorative` rule under the WHOLE bar (a reference-app addition,
 * not part of the DLS `tab-group` node), `--color-bg-level1`. Exists so the
 * eight callers — several of which apply their OWN `padding-left` directly
 * to the `ui-tabs` host (mandates' `.tab-bar`, npa-dashboard's `.tab-bar`,
 * murex-v2's `.tab-bar-host`, (formerly external-platforms' `.tab-bar-host`, now in the page header's tabs slot)) — stay
 * pixel-stable with zero changes at the call site.
 * `panel` = the full DLS `tab-group` chrome: `--color-bg-level2`, 24px
 * horizontal padding (`--padding-panel-h-lg`), `--shadow-sticky-top`
 * (matches the harvested "elevation-sticky-top" — 0 1px 0 rgba(23,24,26,.05)
 * + 0 2px 0 rgba(23,24,26,.03) — EXACTLY; the token already existed in
 * `styles/tokens.css`, no gap here), no bottom rule (the shadow
 * IS the DLS separator).
 * Per-TAB states (hover rule, selected underline, focus ring, badge) are
 * NOT gated by `variant` — the brief scopes the opt-in to "padding/
 * elevation" only, so a `plain` bar still gets the real DLS states; only
 * the outer bar's paint/padding stays legacy.
 * The 24px gap BETWEEN tabs is unconditional in both variants — the
 * pre-existing code already ran it at 24 (see the `.strip` rule for why it
 * is raw, unchanged reasoning carried forward from the pre-growth file).
 *
 * ── Badge ─────────────────────────────────────────────────────────────
 * 16 tall, min-width 16, 4px h-padding (`--padding-indicator-h-md`), pill
 * radius, bg `--color-bg-neutral` (#dde3e7, matches DLS
 * `background-neutral` exactly). Text: DLS names this role plain
 * `color/text` (unqualified) — this token set has only
 * `-strong`/`-body`/`-subtle`/`-disabled`, no bare `--color-text`.
 * `--color-text-body` (#455057) is used as the nearest existing "default,
 * unqualified" role. TOKEN GAP — report to the lead; `--color-text` may be
 * worth harvesting as its own primitive if DLS uses the bare role again.
 *
 * ── Overflow scroll affordance ───────────────────────────────────────────
 * `.strip` is the real scroll container (`overflow-x: auto`, native
 * scrollbar hidden). Two signals — `canScrollLeft` / `canScrollRight` —
 * drive two 40×40 gradient chevron tiles, absolutely pinned to the host's
 * padding edges, present ONLY while their direction has more to reveal. A
 * `ResizeObserver` on the strip catches container-size changes (sidebar
 * collapse, window resize); a `tabs()`-keyed effect re-measures after the
 * tab list itself changes shape (adding/removing tabs changes
 * `scrollWidth`, which `ResizeObserver` does NOT report since the
 * container's own box is unchanged). Chevron clicks scroll by a plain
 * synchronous `scrollBy` (not `behavior: 'smooth'`) so `scrollLeft` is
 * already updated by the time a caller — or an e2e spec — reads it back.
 *
 * ── Keyboard ──────────────────────────────────────────────────────────
 * `role="tablist"` on the host, `role="tab"` + `aria-selected` per button
 * (neither existed before this round). One roving tab stop on the active
 * tab; ArrowLeft/ArrowRight/Home/End both MOVE focus and ACTIVATE the tab
 * (DLS's tab bar switches the page view, so — same contract as
 * `ui-segmented`'s radiogroup — there is no "browse without committing"
 * state to preserve).
 *
 * RESKIN: delegate to the DLS tab bar; `tabs`/`active` stay the contract.
 */
declare class UiTabs {
    tabs: _angular_core.InputSignal<UiTab[]>;
    active: _angular_core.ModelSignal<string | undefined>;
    size: _angular_core.InputSignal<"sm" | "md">;
    variant: _angular_core.InputSignal<"plain" | "panel">;
    protected readonly scrollStep = 200;
    protected readonly canScrollLeft: _angular_core.WritableSignal<boolean>;
    protected readonly canScrollRight: _angular_core.WritableSignal<boolean>;
    private readonly strip;
    private readonly tabEls;
    protected readonly stopIndex: _angular_core.Signal<number>;
    constructor();
    protected onWindowResize(): void;
    protected onScroll(): void;
    protected select(tab: UiTab): void;
    protected scrollBy(delta: number): void;
    protected onKeydown(event: KeyboardEvent, index: number): void;
    private updateOverflow;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTabs, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTabs, "ui-tabs", never, { "tabs": { "alias": "tabs"; "required": true; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, { "active": "activeChange"; }, never, never, true, never>;
}

type UiFilterTabSize = 'sm' | 'md';
interface UiFilterTab {
    key: string;
    label: string;
    /**
     * Trailing count chip, rendered PARENTHESISED — `External Deal (6)`, per
     * the Figma node. The brackets belong to the chip rather than to the caller's
     * label, so no call site can spell them differently.
     *
     * OMITTED (or `null`) renders no chip at all, which is a distinct state from
     * `0` — the Trade Monitoring V2 tab strip shows a count only where that tab
     * has data, so "no data" must be expressible as an absent chip rather than
     * as a zero the reader has to interpret.
     */
    count?: number | null;
    /** Inert: no pointer, no keyboard path, no selection. */
    disabled?: boolean;
}
/**
 * Filter-tab group — DLS `filter-tab` / `filter-tab-group`
 * (REGISTER.md §41, Figma 6364:41027, 76086:352366, also
 * 1157:292759): a row of pills, the selected one filled with the inverse
 * surface, the rest outlined, and a disabled state for a choice that exists
 * but has nothing behind it.
 *
 * DLS runs a Size axis, Medium (40) | Small (32); the `size` input carries
 * it — `sm` (default) is the kit's original, pixel-stable geometry (the five
 * pre-existing callers pass no `size` and are unaffected by this round), `md`
 * is the 40-tall cell.
 *
 *   <ui-filter-tabs [tabs]="tabs" [(active)]="activeTab" />
 *   <ui-filter-tabs [tabs]="tabs" [(active)]="activeTab" size="md" />
 *
 * ── Why this is NOT a variant of `ui-tabs` ──────────────────────────────
 * `ui-tabs` is DLS's *tab bar*: 40px tall, transparent, and identified by a
 * 2px underline on the active tab — the control that switches a PAGE between
 * views. This is DLS's *filter tab group*: a bordered pill that fills when
 * chosen — the control that narrows the content already on the page. They
 * are two components in the library, not one component with a skin: the two
 * share no fill, no border, no radius and no selected treatment (the sizes
 * now coincide at `md`/40, which is DLS's own overlap, not a merge), so a
 * `variant` input on `ui-tabs` would fork its template and every one of its
 * style rules while pretending to be one thing. It would also drag a
 * disabled state into a component whose call sites never have one. Separate
 * here keeps the reskin a one-to-one mapping onto DLS.
 *
 * RESKIN: delegate to the DLS filter-tab-group; keep the selector, the
 * `tabs`/`active`/`size` API and the absent-count rule unchanged.
 */
declare class UiFilterTabs {
    tabs: _angular_core.InputSignal<UiFilterTab[]>;
    active: _angular_core.ModelSignal<string | undefined>;
    /** DLS's Size axis — Small (32, default, pixel-stable) | Medium (40). */
    size: _angular_core.InputSignal<UiFilterTabSize>;
    protected hostClass: _angular_core.Signal<"" | "ui-filter-tabs--md">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiFilterTabs, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiFilterTabs, "ui-filter-tabs", never, { "tabs": { "alias": "tabs"; "required": true; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "active": "activeChange"; }, never, never, true, never>;
}

type UiPillColor = 'grey' | 'green' | 'yellow' | 'red';
type UiPillVariant = 'filled' | 'plain';
/**
 * Use-case pill — small dot + label chip used in trade tables and modals
 * (grey = default, green = acknowledged, yellow = sent for clarification,
 * red = the critical/adverse outcome).
 *
 *   <ui-pill label="ED" color="green" />
 *
 * `variant="plain"` drops the tinted chip background and renders just the
 * coloured dot beside body-sized text — the access-level treatment used by
 * the System Access lists (Special Requests detail + My Profile platforms).
 *
 *   <ui-pill label="Read-Write" color="green" variant="plain" />
 *
 * RESKIN: delegate to the DLS chip/tag; keep selector + inputs unchanged.
 */
declare class UiPill {
    label: _angular_core.InputSignal<string>;
    color: _angular_core.InputSignal<UiPillColor>;
    variant: _angular_core.InputSignal<UiPillVariant>;
    /**
     * Status dot. Off for count/category tags, where a coloured dot implies a
     * status the number doesn't have (DLS tag-info, e.g. "10 User Access").
     */
    dot: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiPill, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiPill, "ui-pill", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "dot": { "alias": "dot"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Canonical checkbox — 20px box, 4px radius, 2px --color-icon border when
 * unchecked, --color-icon-selected (#00ab61) fill when checked (Z3, Figma
 * 1428:65766 unchecked / 1428:65757 checked — was 16px / 1.5px /
 * accent-green, a pre-spec approximation). Label projects in:
 *
 *   <ui-checkbox [(checked)]="agreed">Remote Working</ui-checkbox>
 *
 * THREE visual states, not two. `indeterminate` is the "some, but not all"
 * state a select-all header takes over a partly-selected list — a real DLS
 * checkbox state, and the reason it is here rather than in the one feature
 * that needed it first (the Trade Monitoring V2 blotter's select-all): a
 * two-state checkbox forces every such header to either lie (unchecked over
 * a partial selection) or drop out of the kit into a raw <input>, and the
 * second of those puts a control DLS owns outside the layer that reskins it.
 *
 * It is a PRESENTATION state, not a third value: `checked` stays a boolean,
 * `indeterminate` only overrides how an UNCHECKED box draws, and clicking
 * still reports a plain boolean. The native input carries the DOM property
 * too, so assistive tech announces `mixed` rather than the dash being
 * decoration only.
 *
 * ── DLS REPLICA (REGISTER.md §10, audited 2 Sep 2026) ────────
 *
 * Extended onto the full `checkbox-input` set (Figma 405:15, states
 * Default | Hover | Focus | Focus hover | Disabled | Read-only | Error ×
 * Unchecked/Checked/Indeterminate) and `checkbox` (406:2358, input + label +
 * optional description). Four new states beyond the Z3 baseline:
 *
 * - **Hover** (12776:112018) — a 4px INNER ring of
 *   `--color-bg-success-subtlest` inside the 20px box (box-shadow, so it
 *   never shifts layout) — on an UNCHECKED box only. **OWNER OVERRIDE OF
 *   THE DLS NODE (kit-fixes walk item 14, 6 Sep 2026):** DLS's "Checked
 *   hover" frame layers the same ring over the checked fill; the owner
 *   ruled that an already-checked (or indeterminate) box shows NO hover
 *   ring — its computed `box-shadow` stays `none` under the pointer. The
 *   focus ring is unchanged for every state (checkbox.scss).
 * - **Focus** (405:22) — a 2px INNER ring of `--color-focus`, replacing the
 *   old outer 25%-alpha `--focus-ring`. When a box is both hovered and
 *   keyboard-focused, the focus ring wins (checkbox.scss orders the combo
 *   selector after the hover rule so the two-class tie resolves that way).
 * - **`readonly`** (70211:340550) — not interactive: the native input stays
 *   in the tab order (DLS lists a "Read-only focus" state) but `onToggle`
 *   intercepts `change` and snaps the DOM checkbox back to the model's
 *   value, since HTML's `readonly` attribute is a no-op on
 *   `type="checkbox"`. Checked fill is the paler
 *   `--color-icon-selected-disabled`; unchecked is a plain white box with
 *   an `--color-icon-disabled` border. `aria-readonly` is set either way.
 * - **`invalid`** (405:24 / 70211:340714) — the kit's shared error contract
 *   (see `ui-text-input`'s `invalid`/`errorMessage`, though this component
 *   only takes the boolean half; a wrapping `ui-checkbox-group` carries the
 *   message). Unchecked: `--color-bg-danger-subtlest` fill,
 *   `--color-danger` border (= DLS `icon-danger`, not duplicated as a
 *   second token — see tokens.css). Checked: `--color-danger` fill, white
 *   glyph. `aria-invalid` follows.
 * - **`description`** — a second line under the label, kit `body(sm)` in
 *   `--color-text-subtle`, 4px below. Its presence flips the wrap from
 *   `align-items: center` to `align-items: flex-start` (the label block no
 *   longer centres against a single line), and the label itself keeps a
 *   `min-height: 20px` with its own internal centring so the label TEXT
 *   still lines up with the box's vertical centre exactly as it does today
 *   with no description.
 *
 * DLS keeps a 2px border in the same `icon-selected` green on a CHECKED
 * box; this kit's checked box has always painted checked as fill-with-no-
 * border, which is identical paint (the border and fill are the same
 * colour) — left as-is rather than added as a no-op border, but called out
 * here so it isn't mistaken for an unaudited gap.
 *
 * Label stays kit `label(sm)` (13px) — the owner's compactness ruling
 * carried over from the Z3 build, not DLS's own `label/md` (16px).
 *
 * RESKIN: delegate to the DLS checkbox; keep selector + inputs unchanged,
 * map `indeterminate` onto its own indeterminate/mixed state, and `invalid`
 * / `errorMessage` onto whatever the DLS component's own error contract
 * turns out to be (today it mirrors `ui-text-input`'s).
 */
declare class UiCheckbox implements ControlValueAccessor {
    checked: _angular_core.ModelSignal<boolean>;
    disabled: _angular_core.InputSignal<boolean>;
    /** "Some, but not all" — see the class comment. Ignored while `checked`
     *  is true, since a box cannot be both fully and partly selected. */
    indeterminate: _angular_core.InputSignal<boolean>;
    /** DLS `read-only` (70211:340550) — not interactive; see the class
     *  comment for why this is done by intercepting `change` rather than a
     *  native `readonly` attribute. */
    readonly: _angular_core.InputSignal<boolean>;
    /** The kit's shared error contract's boolean half — see the class
     *  comment and `ui-text-input`'s `invalid`. A wrapping `ui-checkbox-group`
     *  carries the accompanying message. */
    invalid: _angular_core.InputSignal<boolean>;
    /** Second line under the label, `body(sm)` / `--color-text-subtle`. */
    description: _angular_core.InputSignal<string | undefined>;
    /** Resolved once so the template, the native property and the fill rule
     *  cannot disagree about which of the three states is showing. */
    protected showMixed: _angular_core.Signal<boolean>;
    protected cvaDisabled: _angular_core.WritableSignal<boolean>;
    protected isDisabled: _angular_core.Signal<boolean>;
    private onChange;
    protected onTouched: () => void;
    private readonly native;
    constructor();
    protected onToggle(event: Event): void;
    writeValue(value: boolean): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiCheckbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiCheckbox, "ui-checkbox", never, { "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; }, never, ["*"], true, never>;
}

/**
 * Structured content for `[uiTooltip]` — a title line, zero or more body
 * lines, and an optional footer line separated from the body by a blank-line
 * gap (Figma `215:1705`). Deliberately three named slots rather than a bare
 * string or a single `lines: string[]`: the design draws the title bold and
 * the footer as a distinct, visually separated block ("Status: Pending" /
 * per-line detail / a gap / "Last updated: …"), and collapsing that into one
 * array would push every caller into re-inventing which line is which by
 * convention (a leading `''` for the gap, a magic last index for the
 * footer) instead of naming it.
 */
interface UiTooltipContent {
    /** Rendered bold, first line — e.g. "Status: Pending". */
    readonly title: string;
    /** Rendered one per line beneath the title, regular weight. */
    readonly lines: readonly string[];
    /** Rendered after a blank-line gap, in the subtle on-dim colour. Omitted
     *  entirely (no gap, no line) when there is nothing to say. */
    readonly footer?: string;
}
/**
 * **Tooltip — the kit's first, DLS `tooltip`.**
 *
 * Attribute directive rather than a wrapping component, because the thing it
 * decorates is never one fixed element — it has sat on a `ui-status-tag`
 * (Data rectification), and the next call site is whatever needs one next.
 * A wrapper (`<ui-tooltip>…</ui-tooltip>`) would force every anchor into an
 * extra DOM layer just to carry a positioning host; the directive attaches
 * to the element that is already there:
 *
 *   <span [uiTooltip]="{ title, lines, footer }">
 *     <ui-status-tag status="Pending" />
 *   </span>
 *
 * (the input shares the directive's own selector name, so one binding does
 * both jobs — the same idiom `ui-status-tag`'s `[status]` and every other
 * single-input kit piece already uses.)
 *
 * `null`/`undefined` content means "no tooltip" — the caller's way of saying
 * a particular row has nothing to show (an empty tooltip is worse than none;
 * see the Data rectification call site, which has rows with zero detection
 * codes).
 *
 * ── SHOWS ON HOVER *AND* FOCUS, HIDES ON ESCAPE ───────────────────────────
 *
 * A hover-only tooltip is invisible to keyboard and screen-reader users who
 * can reach the anchor but never "hover" it — an accessibility hole the DLS
 * component does not have, so this doesn't either. `focusin`/`focusout`
 * mirror `mouseenter`/`mouseleave` exactly (same open/close paths), and
 * `keydown.escape` closes unconditionally, matching the platform convention
 * every native title-attribute tooltip and every DLS overlay already follows
 * here (`ui-modal-shell`, `ui-select`'s panel).
 *
 * The host needs to be a KEYBOARD TARGET for `focusin` to ever fire, so the
 * directive gives it `tabindex="0"` unless the element already declares one
 * (a real button, link or form control does, and must not be second-guessed
 * here).
 *
 * ── POSITIONING: A FIXED PANEL, PLACED ON OPEN, NOT TRACKED ───────────────
 *
 * The panel is a plain DOM node built and torn down on each open/close — no
 * Angular component, no change-detection question, because its content is a
 * handful of static strings decided by the caller before the tooltip ever
 * shows. It is appended to `document.body` and positioned `fixed` from the
 * anchor's `getBoundingClientRect()` at open time, on the side the
 * `placement` input names — `'auto'` (default) prefers above the anchor,
 * flipped below when there isn't 8px of headroom (today's original, and
 * only, behaviour — both existing callers bind nothing, so they get exactly
 * this); `'top'` / `'bottom'` / `'left'` / `'right'` force that side but
 * still flip to the opposite one when the forced side has no room, because
 * a tooltip rendered off-screen is worse than one on the other side. The
 * panel is clamped to the viewport on its cross axis too — horizontally for
 * a vertical placement, vertically for a horizontal one. That is "sensible
 * viewport flipping", not a popper engine — it does not re-run on scroll or
 * resize, which is fine for a tooltip that closes the moment the pointer or
 * focus leaves the anchor.
 *
 * RESKIN: the DLS Angular Storybook lists `tooltip` — swap this directive's
 * panel markup/styles for that component's, keeping the `[uiTooltip]`
 * selector and the `UiTooltipContent` shape so every call site is untouched.
 */
declare class UiTooltipDirective {
    /** The content to show, or `null`/`undefined` to show nothing at all. */
    readonly uiTooltip: _angular_core.InputSignal<UiTooltipContent | null | undefined>;
    /**
     * Which side of the anchor the panel opens on. `'auto'` (default)
     * reproduces the directive's original vertical-only flip exactly — every
     * call site written before this input existed keeps its current
     * behaviour untouched. The four forced sides still flip to their
     * opposite when the requested side has no room in the viewport (DLS's
     * own arrow-position axis: Top | Top Left | Top Right | Bottom | Bottom
     * Left | Bottom Right | Left | Right — the kit does not build the
     * left/right *offset* variants, only the four base sides, matching every
     * other axis this directive exposes).
     */
    readonly placement: _angular_core.InputSignal<"auto" | "left" | "top" | "bottom" | "right">;
    private readonly hostRef;
    private readonly renderer;
    private panel;
    constructor();
    protected open(): void;
    protected close(): void;
    private destroyPanel;
    private buildPanel;
    /**
     * Applies one side's border-triangle geometry + edge offset to the
     * pointer — 8px thick along the pointing axis, 10px across it (Figma
     * `215:1705`'s `.tooltip-pointer` bounds), same fill as the panel.
     *
     * `side` is the RESOLVED placement — which side of the ANCHOR the panel
     * itself sits on, post-flip — not the panel edge; the pointer always sits
     * on the panel edge that FACES the anchor, i.e. the opposite edge (panel
     * above the anchor ⇒ pointer on the panel's bottom edge, pointing down at
     * it, and so on for the other three). One `case` per side: each sets the
     * edge offset, the fill border that carries the panel's colour, and
     * blanks the two cross-axis borders that taper the triangle to a point
     * (CSS's border-triangle trick — a solid border on one side + transparent
     * borders on its two neighbours points the shape away from the solid
     * side).
     */
    private setPointerSide;
    /**
     * Resolves the `placement` input to an actual side, post-flip.
     *
     * `'auto'` reproduces the directive's ORIGINAL formula byte-for-byte
     * (prefer above the anchor, flip below when `anchor.top - box.height -
     * gap < 0`) — this is the one path every pre-`placement` call site
     * exercises, so it cannot change shape. The four forced sides reuse the
     * exact same "does the preferred side fit" test on their own axis, and
     * fall back to the opposite side when it doesn't — a tooltip rendered
     * off-screen is worse than one on the other side of the anchor.
     */
    private resolveSide;
    private place;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTooltipDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<UiTooltipDirective, "[uiTooltip]", never, { "uiTooltip": { "alias": "uiTooltip"; "required": false; "isSignal": true; }; "placement": { "alias": "placement"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * DLS `checkbox-group` (REGISTER.md §10, Figma 132957:3943,
 * audited 2 Sep 2026) — the field wrapper around a vertical stack of
 * `ui-checkbox`es: a label row (optional "(optional)" suffix + an optional
 * 16px info glyph), an optional error message, then the list.
 *
 *   <ui-checkbox-group label="Notification channels" info="Choose at least one">
 *     <ui-checkbox [(checked)]="email">Email</ui-checkbox>
 *     <ui-checkbox [(checked)]="sms">SMS</ui-checkbox>
 *   </ui-checkbox-group>
 *
 *   <ui-checkbox-group label="Approvers" [optional]="true" />
 *
 *   <ui-checkbox-group label="Approvers" [invalid]="true" errorMessage="Pick at least one">
 *     <ui-checkbox [(checked)]="a" [invalid]="true">Haruto SATO</ui-checkbox>
 *     <ui-checkbox [(checked)]="b" [invalid]="true">Mei KOBAYASHI</ui-checkbox>
 *   </ui-checkbox-group>
 *
 * `invalid` + `errorMessage` mirror the kit's shared error contract
 * (`ui-text-input`'s), scaled up to a GROUP: the message renders once,
 * under the label, rather than once per child (DLS's own "Error - for one
 * option" variant — a message under a single option instead — is a
 * per-`ui-checkbox` concern and isn't modelled here). Marking the group
 * `invalid` does NOT cascade an `invalid` state onto the projected
 * children — Angular content projection has no channel to reach into a
 * `<ng-content>` child's own `input()` from the parent's TypeScript, so a
 * caller who also wants each option to paint invalid passes `[invalid]`
 * to those `ui-checkbox`es directly (see the second example above). This
 * mirrors DLS's own decoupling: the frame shows the group error text and
 * individually-invalid options as separate, independently-set things.
 *
 * `readonly` follows the same pattern for the same reason: DLS's
 * Read-only variant renders a checked option's LABEL as plain text with no
 * box: `ui-checkbox-group`'s `readonly` input exists for documentation and
 * host-level presentation (`aria-readonly` on the list, a `cbg-list--
 * readonly` hook for a caller's own CSS) — a caller wanting the DLS
 * read-only look passes `[readonly]="true"` to the projected `ui-checkbox`
 * children themselves, which already implements the "not interactive,
 * paler checked fill" half of it (checkbox.ts). Rendering the checked
 * label as bare text instead of a checkbox glyph is a further, opt-in step
 * left to the caller's own template today — no the reference app call site needs it
 * yet.
 *
 * `info`, when set, renders a 16px info-circle glyph after the label,
 * carrying the text as a `[uiTooltip]` (hover/focus, matching the tooltip
 * directive's own contract) — built as `{ title: info(), lines: [] }`
 * since the group only ever has one short line to say, not the tooltip's
 * full title/lines/footer anatomy.
 *
 * RESKIN: delegate to the DLS checkbox-group; keep the selector and every
 * input name, and keep projecting plain `ui-checkbox` children rather than
 * an internal item model — the group never owns the checked state, only
 * the chrome around it.
 */
declare class UiCheckboxGroup {
    label: _angular_core.InputSignal<string>;
    optional: _angular_core.InputSignal<boolean>;
    /** See the class comment — does not cascade onto projected children. */
    invalid: _angular_core.InputSignal<boolean>;
    errorMessage: _angular_core.InputSignal<string>;
    /** Tooltip text shown by the 16px info glyph next to the label. Omit to
     *  skip the glyph entirely. */
    info: _angular_core.InputSignal<string | undefined>;
    /** See the class comment — a documentation + host-presentation input;
     *  the DLS "not interactive, paler fill" behaviour lives on each
     *  projected `ui-checkbox` via its own `readonly`. */
    readonly: _angular_core.InputSignal<boolean>;
    protected infoTooltip: _angular_core.Signal<UiTooltipContent | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiCheckboxGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiCheckboxGroup, "ui-checkbox-group", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "optional": { "alias": "optional"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "info": { "alias": "info"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/** DLS `input-search` Size axis — `small` (32, the platform's compact default) | `regular` (DLS Medium, 40). */
type UiSearchInputSize = 'regular' | 'small';
/**
 * DLS 3.1 "Input search" (REGISTER.md §23, Figma set
 * 38951:273380 — default 196904, focus 196910, filled 196925, disabled
 * 196915), aligned onto the DLS chrome in the archive round §21–§24 (owner
 * decision, 3 Sep 2026). Same shared field shell as `ui-phone-input`/
 * `ui-number-input`/`ui-amount-input`: bg level_1, 1px border, radius 4,
 * padding 0/12 (this control's own kit had 4/12) with an 8px gap.
 *
 *   <ui-search-input [(value)]="query" placeholder="Search" />
 *   <ui-search-input [(value)]="query" [disabled]="true" />
 *   <ui-search-input [(value)]="query" size="regular" />
 *
 * ── `size` (kit-fixes walk item 26, 6 Sep 2026) ────────────────────────
 * `small` (DEFAULT) = the 32px face every filter bar and the searchable
 * `ui-select`'s in-menu row already use: `--size-base-sm`, 16px
 * `magnifying-glass_16` glyph, `body(sm)` text. Defaulting here keeps all
 * 16 existing callers byte-identical. `regular` = DLS's own Medium
 * (register §23 "input-search 40 → our 32" — the 40 is now available):
 * `--size-base-md` 40px, a 24px `magnifying-glass_24` glyph, `body(md)`
 * text, host class `ui-search-input--regular`. Horizontal padding (12)
 * and the 8px gap are the same at both sizes; the clear affordance stays
 * the 24px tiny icon-button at both.
 *
 * Leading glyph (hand-authored, `--color-icon`, dims to
 * `--color-icon-disabled` while `disabled`). **Filled** state (value
 * non-empty, not disabled): a trailing `ui-icon-button size="tiny"` with a
 * 16px `circle-x-filled` glyph (register §8) clears the value on a real
 * click and re-emits — same clear affordance `ui-text-input`'s own
 * clear-on-focus button draws, but gated on the value being non-empty
 * rather than focus (DLS's Filled state, not a focus-only convenience).
 * Focus: 2px solid `--color-focus` inset border, no alpha ring. Disabled:
 * `--color-bg-disabled`, no border (`border-width: 0`, not just a
 * transparent colour — box-sizing: border-box keeps the box the same size).
 *
 * RESKIN: delegate to the DLS search field; keep selector + inputs unchanged
 * (`size` maps onto DLS's Size axis: small → Small, regular → Medium).
 */
declare class UiSearchInput {
    placeholder: _angular_core.InputSignal<string>;
    value: _angular_core.ModelSignal<string>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** DLS Size axis — `small` (32, default) | `regular` (DLS Medium, 40). See the class doc. */
    size: _angular_core.InputSignal<UiSearchInputSize>;
    protected showClear: _angular_core.Signal<boolean>;
    protected onInput(event: Event): void;
    protected clear(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiSearchInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiSearchInput, "ui-search-input", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

type UiCardFooterAction = 'show-all' | 'show-more' | 'show-less';
/**
 * Canonical content card, grown ADDITIVELY onto the DLS 3.1 `card`
 * component (page 305:2702, set 166757:3384, REGISTER.md §9,
 * audited + built 2 Sep 2026 — the §8–§12 batch). White, radius-md 8,
 * elevation-2, all 36 existing callers keep rendering BYTE-IDENTICAL:
 *
 *   <ui-card title="Deviation Details">…</ui-card>
 *
 * The DLS set crosses Breakpoint × Content(Default|Empty) × Dividers —
 * this component answers Dividers only (Breakpoint is desktop-only here;
 * Content=Empty is composition with the existing `ui-empty-state`, not new
 * anatomy — see the Empty-content note below). Everything new is opt-in:
 *
 *   <ui-card title="Trades" subtitle="12 flagged" [count]="12" dividers>
 *     <button ui-button variant="plain" size="small" ui-card-action>
 *       Label<svg uiButtonIconRight>…chevron…</svg>
 *     </button>
 *     …body…
 *     <div ui-card-footer>…arbitrary footer content…</div>
 *   </ui-card>
 *
 *   <ui-card title="Desk Details" collapsible [(expanded)]="open">…</ui-card>
 *
 *   <ui-card title="Trades" dividers footerAction="show-all"
 *     (footerActivated)="onShowAll()">…</ui-card>
 *
 * **Layout model — the ONE thing that keeps 36 callers unchanged.** A card
 * is "flat" (the legacy shape: host owns a single 24px padding + 16px gap,
 * `.card-header`/`.card-body`/`.card-footer` own NO padding of their own —
 * exactly what the pre-existing markup produced) unless it needs to be
 * "sectioned" — header/body/footer as independent boxes with DLS's split
 * paddings (header `--padding-panel-h-lg`/`--padding-panel-v-md` 24/16,
 * body `--padding-panel-v-lg`/`--padding-panel-h-lg` 24/24, footer
 * `--padding-panel-h-lg`/`--padding-panel-v-sm` 24/12, min-height 48 — no
 * DLS step for 48, stays raw). `sectioned` (card.scss) is true when
 * `dividers()` OR `collapsible()` OR a footer is showing — i.e. whenever a
 * section needs its own visual box (a divider RULE to sit against, a
 * hover fill that must reach the card's edges, or a footer strip). None of
 * the 36 existing callers trip any of those three, so they stay on the flat
 * path untouched. `dividers` itself controls ONLY the 1px
 * `--color-border-decorative` rule lines (header bottom / footer top) —
 * it is a car separate axis from "sectioned", not a synonym for it; a
 * `collapsible` or footer-bearing card sections its padding even with
 * `dividers` left `false` (no lines drawn, still edge-to-edge boxes) since
 * a collapsible header's hover fill and a footer strip need to reach the
 * card's edges however the two are combined.
 *
 * `.card-header` and `.card-body`/`.card-footer`'s LAST piece both carry
 * the full `--radius-md` (not just the touching corners) in sectioned mode
 * — same trick `ui-accordion` uses (accordion.scss's `:host` comment):
 * every section shares the SAME background as the host, so a redundant
 * radius on an interior corner is invisible, and the outer corner (top on
 * the header, bottom on whichever section is last) never squares off past
 * the host's own rounded silhouette during a hover fill.
 *
 * **Header** (166757:3513) — `title` (kept, `heading(xs)` 16px — the
 * owner's compactness ruling carried from the accordion/badge rounds; DLS
 * prints 20px/heading-md for this role and is deliberately not chased),
 * optional `count` (a `ui-badge`, Low emphasis, `--gap-unit-h` after the
 * title — 166757:3522's "Accordion=Yes" count reading, reused as a plain
 * header count here too), optional `subtitle` (`body(sm)` 13px,
 * `--color-text-subtle`, 4px under the title row). Right side is ONE of:
 * a caller's own `[ui-card-action]` button (a plain-small "Label ›", the
 * caller's job, not this component's) — HIDDEN when `collapsible`, since
 * the two are mutually exclusive DLS states on the same slot — or, when
 * `collapsible`, a purely decorative 32px chevron cell (`.card-toggle`,
 * DLS's Accordion=Yes 166757:3522/166757:3530 reading: down collapsed, up
 * expanded/"Active"). It is `aria-hidden` and carries no click handler of
 * its own — the header ITSELF is the toggle (`role="button"`,
 * `aria-expanded`, `tabindex="0"`, Enter/Space), same pattern
 * `ui-accordion`'s header already uses, so there is no nested-interactive
 * control to stopPropagation against. Header Hover (`--color-bg-hover`,
 * 166757:3530) applies only when `collapsible` — a header that cannot
 * open has nothing to hint at, same rule `ui-accordion`'s
 * `header-not-expandable` follows.
 *
 * **Body** (178051:26789) — `bodyPadding` toggles DLS's "Default" (24/24,
 * the default) vs "No padding" (a table living inside a card) slot types.
 * "Without dividers" is not a third body mode here — it is simply what the
 * flat layout already does when `dividers` is `false`.
 *
 * **Footer** (166757:3546) — min-height 48, split padding when sectioned,
 * a top rule when `dividers`. `footerAction` renders DLS's Show all / Show
 * more (+ chevron-down) / Show less (+ chevron-up), centred, emitting
 * `footerActivated`; `footerValue` renders the "With right content"
 * reading (166757:3571) — a right-aligned "value ›" button emitting
 * `footerValueActivated`, sharing the row with `footerAction` via a
 * left/right split (space-between) rather than the single centred button
 * `footerAction` alone gets. `footerLoading` (166757:3574) renders DLS's
 * three 8px dots at 1/.6/.2 opacity in `--color-icon` — the same glyph
 * `ui-button`'s own loading state draws, standalone here since a footer
 * has no button of its own to swap a label out of. A bare
 * `[ui-card-footer]` slot carries arbitrary footer content the three
 * helpers don't cover. The footer only APPEARS when one of the three
 * helper inputs is set — an `[ui-card-footer]`-only caller with none of
 * them set gets no footer box (Angular content queries cannot see inside
 * an attribute selector from a consumer's own template without that
 * consumer importing a marker directive too, which would have meant every
 * `ui-card` caller needing a second import for a slot most never touch;
 * pair `[ui-card-footer]` with at least one helper input until a real use
 * case asks for the bare-slot-only reading). DLS's whole-footer Hover
 * (`--color-bg-hover`) applies whenever `footerAction` or `footerValue` is
 * set — the row has something clickable in it; `footerLoading` alone is
 * not interactive and draws no hover.
 *
 * **Empty content** (166757:3389) is composition, not new anatomy: put a
 * `ui-empty-state` in the default slot (see kitchen-sink's `#ui-card`
 * card-empty-row demo) — the illustration/title/body/action shape DLS
 * draws there is exactly what `ui-empty-state` already is.
 *
 * `collapsible` + `expanded` (a `model()`, default `true` — matches every
 * pre-existing card, which has no way to be anything but "shown") is the
 * `ui-accordion`/`ui-nav-panel` two-way pattern: `[(expanded)]="open"`.
 * The body+footer collapse together via the SAME grid-rows track
 * animation `ui-accordion` uses (`.card-collapse`/`.card-collapse-inner`),
 * wrapped in `display: contents` when NOT collapsible so the wrapper adds
 * no box and no gap/geometry change for the 36 legacy callers that never
 * touch this input.
 *
 * Docblock node refs for the record: set 166757:3384; header 166757:3513
 * (Accordion=Yes 166757:3522, Hover 166757:3530); body 178051:26789;
 * footer 166757:3546 (With right content 166757:3571, Loading 166757:3574);
 * Empty content 166757:3389.
 *
 * RESKIN: delegate to the DLS card/panel; keep selector + all inputs.
 */
declare class UiCard {
    title: _angular_core.InputSignal<string | undefined>;
    /** DLS gap (b) — `body(sm)` 13px, `--color-text-subtle`, 4px under the title row. */
    subtitle: _angular_core.InputSignal<string | undefined>;
    /** Header count badge (Low emphasis), 8px right of the title. `undefined` renders none. */
    count: _angular_core.InputSignal<string | number | undefined>;
    /** DLS's Dividers axis — 1px rule lines only. See the class doc's Layout model note for why this is NOT the same switch as the split-padding "sectioned" layout. */
    dividers: _angular_core.InputSignal<boolean>;
    /** DLS body slot type: "Default" (24/24) or "No padding" (a table living inside a card). */
    bodyPadding: _angular_core.InputSignal<"none" | "default">;
    /** DLS "Accordion=Yes" reading — the whole header becomes a disclosure toggle for the body + footer. */
    collapsible: _angular_core.InputSignal<boolean>;
    /** Two-way, default `true` — every pre-existing (non-collapsible) card has no way to be anything but shown. */
    expanded: _angular_core.ModelSignal<boolean>;
    /** DLS footer Types: Show all / Show more (+ chevron-down) / Show less (+ chevron-up). `undefined` renders none. */
    footerAction: _angular_core.InputSignal<UiCardFooterAction | undefined>;
    /** DLS footer "Loading" — three 8px dots, `--color-icon`, 1/.6/.2 opacity. */
    footerLoading: _angular_core.InputSignal<boolean>;
    /** DLS footer "With right content" — right-aligned "value ›" button, paired with `footerAction` (left) or alone. */
    footerValue: _angular_core.InputSignal<string | undefined>;
    footerActivated: _angular_core.OutputEmitterRef<void>;
    footerValueActivated: _angular_core.OutputEmitterRef<void>;
    protected showHeader: _angular_core.Signal<boolean>;
    protected showFooter: _angular_core.Signal<boolean>;
    /** Sections become independent, edge-to-edge boxes whenever one needs its own visual identity — see the class doc's Layout model note. */
    protected sectioned: _angular_core.Signal<boolean>;
    protected footerActionLabel: _angular_core.Signal<"" | "Show all" | "Show more" | "Show less">;
    protected onHeaderClick(): void;
    protected onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiCard, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiCard, "ui-card", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "count": { "alias": "count"; "required": false; "isSignal": true; }; "dividers": { "alias": "dividers"; "required": false; "isSignal": true; }; "bodyPadding": { "alias": "bodyPadding"; "required": false; "isSignal": true; }; "collapsible": { "alias": "collapsible"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "footerAction": { "alias": "footerAction"; "required": false; "isSignal": true; }; "footerLoading": { "alias": "footerLoading"; "required": false; "isSignal": true; }; "footerValue": { "alias": "footerValue"; "required": false; "isSignal": true; }; }, { "expanded": "expandedChange"; "footerActivated": "footerActivated"; "footerValueActivated": "footerValueActivated"; }, never, ["[ui-card-action]", "*", "[ui-card-footer]"], true, never>;
}

/**
 * Card button — the DLS 3.1 `card-button` component (page 305:2702, node
 * 239963:31383, "Standard, desktop", REGISTER.md §9, built
 * 2 Sep 2026). A tappable card: an icon + a label/description pair,
 * applied as an attribute so native `<button>` semantics (type, disabled,
 * form participation) stay intact — same pattern as `ui-button` /
 * `ui-icon-button`:
 *
 *   <button ui-card-button label="Wire Transfer" description="Move funds between accounts">
 *     <svg ui-card-button-icon>…24px glyph…</svg>
 *   </button>
 *
 * 280px is the Figma FRAME width, not a component width — this component
 * does not fix its own width; the caller sizes it (a grid cell, a fixed
 * column, whatever the layout calls for), same reasoning `ui-card` itself
 * uses (`width: 100%`, `flex-shrink: 0`).
 *
 * Padding 12/12 — `--padding-panel-h-sm` / `--padding-panel-v-sm`, both
 * already on-token, no raw value needed. Radius `--radius-md` (8),
 * `--shadow-elevation-3` (one step up from `ui-card`'s own elevation-2 —
 * DLS draws a tappable card slightly more "lifted" than a static one).
 * Row layout, 8px gap: a 24px icon slot, then a label/description column.
 *
 * **Icon slot** — `[ui-card-button-icon]`, fixed to 24px via `::ng-deep`
 * in card-button.scss (the kit's internal notes "projected content cannot be styled
 * from its host" — the same trap `ui-button`'s icon slots document),
 * coloured `--color-icon` so a `currentColor` glyph picks it up.
 *
 * **Text column** — `label` (required; `label(md)` 14px/500,
 * `--color-text-strong`) and optional `description` (`label(sm)` 13px,
 * `--color-text-subtle`), 4px apart, left-aligned.
 *
 * **States** — Hover `--color-bg-hover`, Active/Pressed `--color-bg-pressed`,
 * Focus a 2px INSET solid `--color-focus` ring (no layout shift, same
 * recipe `ui-button`/`ui-icon-button` use), Disabled collapses to
 * `--color-bg-disabled` + `--color-text-disabled` (label and description
 * both) + `--color-icon-disabled` (icon slot).
 *
 * RESKIN: delegate to the DLS Angular card-button; keep this selector and
 * the `label`/`description` inputs.
 */
declare class UiCardButton {
    label: _angular_core.InputSignal<string>;
    description: _angular_core.InputSignal<string | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiCardButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiCardButton, "button[ui-card-button]", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, never, ["[ui-card-button-icon]"], true, never>;
}

/** Same initials rule as the React `initialsOf` helper. */
declare const initialsOf: (name: string) => string;
/** DLS 3.1 avatar `Type` axis. */
type UiAvatarType = 'initials' | 'icon' | 'placeholder' | 'image';
/** DLS 3.1 avatar `Size` axis — Figma's variant names say "64px" for `xl`,
 *  but the harvested frame measures 56px; trust the measurement. */
type UiAvatarSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
/**
 * The 16 DLS avatar colours — 8 flats plus their 8 adjacent-pair gradients
 * (each `linear-gradient(135deg, A, B)`, harvested top-left -> bottom-right
 * off the exported swatch SVG). Exported so callers and the kitchen sink can
 * enumerate the full set without duplicating the list.
 */
declare const AVATAR_COLOURS: readonly ["goji", "ginger", "lemon", "lime", "melon", "mint", "lavender", "acai", "goji-ginger", "ginger-lemon", "lemon-lime", "lime-melon", "melon-mint", "mint-lavender", "lavender-acai", "acai-goji"];
type UiAvatarColour = (typeof AVATAR_COLOURS)[number];
/**
 * DLS 3.1 avatar (register §3) — replaces the old free-px hex-background
 * circle wholesale. Four types share one 5-size box:
 *
 *   <ui-avatar name="Aiko MORI" colour="goji" />                 initials
 *   <ui-avatar type="icon" />                                     white + glyph
 *   <ui-avatar type="placeholder" />                               neutral + glyph
 *   <ui-avatar type="image" img="/avatar.jpg" />                   clipped circle
 *   <ui-avatar type="image" img="/logo.png" [circle]="false" />    unclipped (DLS "Card")
 *
 * Owner ruling: `bg` (hex) and the old free-px `size` are GONE — no more hex
 * moving forward. `colour` is one of the 16 named DLS swatches (`AVATAR_COLOURS`),
 * `size` is one of the 5 DLS steps, default `sm` (32px — the closest DLS step
 * to the old 28px default; sm/md tied on distance, the owner broke the tie
 * toward sm).
 *
 * LETTER RULE (DLS 3.1): two initials at md/lg/xl, a single initial at sm/xs
 * — smaller boxes drop to one letter rather than crowding two.
 */
declare class UiAvatar {
    /** Required in practice for `type="initials"`; the other three types don't
     *  read it, so it stays optional rather than forcing every non-initials
     *  caller to pass a name it would never use. */
    name: _angular_core.InputSignal<string>;
    type: _angular_core.InputSignal<UiAvatarType>;
    colour: _angular_core.InputSignal<"goji" | "ginger" | "lemon" | "lime" | "melon" | "mint" | "lavender" | "acai" | "goji-ginger" | "ginger-lemon" | "lemon-lime" | "lime-melon" | "melon-mint" | "mint-lavender" | "lavender-acai" | "acai-goji">;
    size: _angular_core.InputSignal<UiAvatarSize>;
    /** `type="image"` only. */
    img: _angular_core.InputSignal<string>;
    /** `type="image"` only — DLS "Profile Image"/"Logo" (clipped, default) vs
     *  "Card" (unclipped — card faces carry their own corners). */
    circle: _angular_core.InputSignal<boolean>;
    protected readonly initials: _angular_core.Signal<string>;
    protected readonly boxPx: _angular_core.Signal<number>;
    protected readonly background: _angular_core.Signal<string>;
    protected readonly hostClass: _angular_core.Signal<string>;
    /** 42% of the box, width-driven — the source glyph is 23.3333 x 24.6667
     *  (slightly taller than wide), so height follows the same aspect rather
     *  than getting its own 42% (which would distort it). */
    protected readonly glyphWidthPx: _angular_core.Signal<number>;
    protected readonly glyphHeightPx: _angular_core.Signal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiAvatar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiAvatar, "ui-avatar", never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "colour": { "alias": "colour"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "img": { "alias": "img"; "required": false; "isSignal": true; }; "circle": { "alias": "circle"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * The four `ui-pill` status colours, plus the one hue that is not a status.
 *
 * Deliberately a SUPERSET of `UiPillColor` rather than a fresh union: a bar's
 * job is to say "everything under me is in this state", so it must be the same
 * colour as the status dots on the rows inside it, and the cheapest way to
 * guarantee that is to make the two share a vocabulary. A call site can hand
 * `DETECTION_REVIEW_STATUS_META[status].dot` straight to `barColor` and the
 * bar cannot drift from its rows — there is no second mapping table to keep
 * in step. `'purple'` is the exception the design has: Data Rectification is
 * not a `DetectionReviewStatus`, so it has no dot to borrow and names its own.
 */
type UiAccordionBarColor = UiPillColor | 'purple';
/**
 * Marker for `ui-accordion`'s projected header slot — put `accordion-header`
 * on the element that should REPLACE the built-in title/subtitle/count:
 *
 *   <ui-accordion title="Murex">
 *     <div accordion-header class="my-header">…icon, name, meta, tag…</div>
 *     …
 *   </ui-accordion>
 *
 * A directive rather than a bare attribute so the accordion can SEE the
 * projection (`contentChild(UiAccordionHeader)`) and switch off its own
 * title rendering — a bare `<ng-content select>` cannot report whether
 * anything matched it. Same query-on-a-marker idiom `ui-radio-chiclet-group`
 * uses on its chiclets. Consumers import it alongside `UiAccordion`.
 */
declare class UiAccordionHeader {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiAccordionHeader, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<UiAccordionHeader, "[accordion-header]", never, {}, {}, never, never, true, never>;
}
/**
 * Marker for `ui-accordion`'s right-hand actions slot (5 Sep 2026) — put
 * `accordion-actions` on any control that should sit left of the chevron:
 *
 *   <ui-accordion title="Platforms">
 *     <ui-search-input accordion-actions [(value)]="query" />
 *     …
 *   </ui-accordion>
 *
 * The attribute alone has always projected into the slot; what the
 * DIRECTIVE adds is that the accordion can SEE the projection
 * (`contentChild(UiAccordionActions)`, same idiom as `UiAccordionHeader`)
 * and, when it does, moves the toggle off the whole header row and onto
 * its title area — see the "Title-area toggle" note on `UiAccordion`. A
 * consumer that forgets to import it still gets the slot, but with the
 * pre-existing whole-row toggle (and its click-only `stopPropagation`
 * guard), so import it alongside `UiAccordion` whenever the slot holds
 * anything keyboard-operable.
 */
declare class UiAccordionActions {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiAccordionActions, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<UiAccordionActions, "[accordion-actions]", never, {}, {}, never, never, true, never>;
}
/**
 * Marker for `ui-accordion`'s DEFERRABLE body (5 Sep 2026) — an
 * `<ng-template accordion-body>` the accordion stamps into its body itself:
 *
 *   <ui-accordion title="Trades" lazyBody [defaultOpen]="false">
 *     <ng-template accordion-body>
 *       <app-trade-table [rows]="rows()" />
 *     </ng-template>
 *   </ui-accordion>
 *
 * A template, not a plain projected element, because Angular INSTANTIATES
 * projected content eagerly — an `@if` around an `<ng-content>` only
 * decides where the already-built nodes land, it never stops them being
 * built (the consumer owns them). A `TemplateRef` is the one thing the
 * accordion can choose NOT to create. Without `lazyBody` the template is
 * stamped immediately, so a consumer can adopt the template shape first and
 * flip the flag later without a second change.
 */
declare class UiAccordionBody {
    readonly template: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiAccordionBody, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<UiAccordionBody, "ng-template[accordion-body]", never, {}, {}, never, never, true, never>;
}
/**
 * Canonical accordion — DLS accordion-box replica (REGISTER.md
 * §1, "DLS 3.1 replica" round, 2 Sep 2026): 4px radius, elevation-1 shadow,
 * 48px-minimum header with content-driven height, spring-rotating 24px
 * chevron, grid-rows open/close animation (animates to actual content
 * height, no max-height hacks). Optional actions slot sits left of the
 * chevron:
 *
 *   <ui-accordion title="Desk Details">
 *     <button ui-button variant="secondary" accordion-actions>Edit</button>
 *     …body…
 *   </ui-accordion>
 *
 * `barColor` and `count` are the Trade Monitoring V2 header variant (Figma
 * 1159:185471 / 1159:185472) — a 4x32 rounded bar inset 8px on the left, and
 * a count badge after the title:
 *
 *   <ui-accordion title="Not started" barColor="grey" [count]="12">…
 *
 * ONE COMPONENT, TWO OPTIONAL INPUTS, not a sibling. Everything the variant
 * does NOT change is everything this component is: the 48px header, the
 * chevron's spring, the grid-rows animation, the actions slot, the open/close
 * state. A `ui-accordion-bar` sibling would have had to copy all of it to add
 * a 4px rectangle and a chip, and the two would then drift on the parts that
 * were never meant to differ. Both inputs default to "absent", so every call
 * site that predates the variant renders byte-identically.
 *
 * `count` is `number | null`, not `number` — `0` is a real count worth
 * showing ("this bucket is empty" is information), so absence needs its own
 * value rather than borrowing a falsy one.
 *
 * **Projected header** (`[accordion-header]`, 5 Sep 2026) — for the three
 * header anatomies the app hand-rolls today (System Access's platform row:
 * name + count + edit/revoke icon-buttons; Profile's desk-group row: name +
 * pipe-separated meta; Inbox's raised-clarification row: name + inline
 * status tag) the built-in `title`/`subtitle`/`count` are not enough. Mark
 * an element with the `UiAccordionHeader` directive and it renders in the
 * LEFT of the header in place of the built-in title/subtitle/count:
 *
 *   <ui-accordion title="Murex" [defaultOpen]="false">
 *     <div accordion-header class="pf-header-text">…</div>
 *     <button accordion-actions ui-icon-button size="tiny" …>…</button>
 *     …body…
 *   </ui-accordion>
 *
 * Everything else stays the kit's: the bar (and its 16/16 offset), the
 * right-side `[accordion-actions]` slot, the chevron, open/close, hover,
 * focus ring, keyboard. The header keeps DLS geometry regardless of what is
 * projected — 12px vertical / 16px horizontal padding, 48px minimum — the
 * slot wrapper carries a 24px min-height (48 − 2 × 12) so a one-line
 * projection sits at exactly the built-in height, and taller content grows
 * it the same way `subtitle` does. `title` stays required even when the
 * slot is used: it is still the accessible name the toggle is announced
 * with (`aria-label` on the header), since projected markup cannot serve
 * as one. Consumers still pass `count`/`subtitle` at their own risk — they
 * are simply not drawn while the slot is present.
 *
 * The badge is `ui-badge`, the kit's existing answer to "how many things are
 * in there?". NOTE one deviation from the harvested Figma values
 * (the kit's internal notes): the node draws the count at `label/xs` (12px)
 * and `ui-badge`'s count emphasis is `label/2xs` (10px). Fill, height, padding
 * and radius all match exactly. Forking the badge or giving it a size axis
 * over 2px would undo the reasoning in badge.ts — which argued from the two
 * DLS instances that existed at the time — so the kit component wins here and
 * the delta is Sid's call at QC.
 *
 * **Title-area toggle when actions are present** (`UiAccordionActions`,
 * 5 Sep 2026) — with nothing in `[accordion-actions]` the whole `.header`
 * row is the toggle (`role="button"`, `tabindex="0"`, Enter/Space), exactly
 * as before. The moment the slot holds a marked element the toggle moves
 * onto `.header-main` — the bar + title (or `[accordion-header]` slot)
 * column — which carries the role, tabindex, `aria-expanded`, the
 * `aria-label` and the keyboard handlers instead, and `.header` carries
 * none of them. Why: a search input or an icon-button inside a
 * `role="button"` is invalid nesting, its Enter/Space bubbled up and
 * toggled the panel, and it could not be a tab stop of its own. Now the
 * actions are ordinary tab stops in DOM order (title toggle -> actions ->
 * body), and clicking them never toggles. The chevron stays where it is
 * (right of the actions, geometry untouched) and still toggles on click —
 * it forwards to the same `toggle()` — but it is `aria-hidden`, so the
 * title area is the ONE accessible toggle. Nothing visible changes: the
 * hover wash stays on the full row (`.header:hover`), the focus ring still
 * wraps the full header (`.header:has(> .header-main:focus-visible)`), and
 * `.header-main` extends under the header's own left and vertical padding
 * so the clickable band is the same as it was. This is the kit answer to
 * the app's two "partial-toggle" headers (Profile's Platforms card with a
 * search input, Trade Monitoring's ongoing-clarification card with a Take
 * Action button — the kit's internal notes A11, A13).
 *
 * **`lazyBody`** (5 Sep 2026) — `false` by default. For panels whose
 * content is expensive (a table): with `lazyBody` the `[accordion-body]`
 * template is not stamped until the FIRST open, so a group that starts and
 * stays collapsed never builds it. `hasOpened` latches on that first open
 * and never resets — re-collapsing keeps the panel built, so the close
 * animation has real content to animate over and re-opening is instant.
 * The grid-rows animation still plays on the first open: the template is
 * stamped in the same change-detection pass that flips `.body-open`, so
 * the `1fr` row measures the freshly-built content. Nine app sites guard
 * their bodies with `@if` today for exactly this reason (inventory §A
 * cross-cutting note 3); this is the kit form of that guard. Only the
 * template is deferred — the default `<ng-content>` slot still projects,
 * eagerly, as it always has (see `UiAccordionBody` for why it cannot be
 * anything else).
 *
 * **Controlled open state** (`expanded`, 6 Sep 2026) — a
 * `model<boolean | null>`, `null` by default. `null` is the uncontrolled
 * accordion every existing call site is: `defaultOpen` seeds a private
 * signal and the header toggles it. Any non-null value is CONTROLLED: the
 * header reflects `expanded()` and every user toggle writes the model —
 * which is also what emits `expandedChange` — so a parent that OWNS the
 * state binds both directions and a parent that only wants to KNOW listens
 * to the output alone:
 *
 *   <!-- the parent's Set<string> survives a tab switch that destroys the list -->
 *   <ui-accordion title="Murex" [expanded]="isOpen(id)" (expandedChange)="toggle(id)">…
 *
 *   <!-- fires on every expand, so a "seen" marker can clear a badge each time -->
 *   <ui-accordion title="Riku ⇄ Nao" [defaultOpen]="false" (expandedChange)="$event && markSeen()">…
 *
 * One rule, not two modes, in `toggle()`: it always writes `!open()` to the
 * model. An uncontrolled accordion's first toggle therefore moves it onto
 * the model at exactly the value the private signal would have taken, and
 * from then on the model carries — indistinguishable from before to the
 * accordion itself, but the output now fires for every toggle whichever way
 * the parent bound it. The model never emits for a value the PARENT pushes
 * in (`[expanded]="true"` from outside is not a user toggle), which is the
 * `markSeen` contract above. `expandable` still gates everything: a
 * non-expandable accordion reports closed and ignores toggles whatever the
 * model says. `lazyBody`'s `hasOpened` latches from the EFFECTIVE open
 * state (an `effect`), so a parent that opens a controlled accordion
 * programmatically stamps the template the same as a click would. Note
 * `expandedChange`'s payload is typed `boolean | null` (a model emits its
 * own type) but only `toggle()` ever writes it, so it is a boolean every
 * time it fires — `$event === true` is the safe "did it just open" test.
 *
 * RESKIN: delegate to the DLS accordion/expander; keep selector + inputs
 * unchanged. The DLS accordion is unlikely to ship a coloured left bar, so
 * expect the bar to survive as a wrapper element around the DLS component
 * (it is pure decoration in the header's padding — it neither participates in
 * the layout nor is clickable). The badge is already the DLS badge.
 */
declare class UiAccordion {
    title: _angular_core.InputSignal<string>;
    /**
     * DLS accordion-box optional second line (label/sm, `--color-text-subtle`,
     * 4px under the title) — REGISTER.md §1 gap (b). `null` (the
     * default) renders nothing, so every pre-existing call site is unchanged.
     * The header has no fixed height any more (min-height only) specifically
     * so this can grow it without clipping.
     */
    subtitle: _angular_core.InputSignal<string | null>;
    /** Seeds the UNCONTROLLED open state (`expanded` null) once, on init. */
    defaultOpen: _angular_core.InputSignal<boolean>;
    /**
     * Controlled open state — see the class doc. `null` (the default) means
     * uncontrolled (`defaultOpen` seeds, the header toggles); a boolean is the
     * open state the parent owns. Written on every user toggle, which is what
     * emits `expandedChange`, in both modes.
     */
    expanded: _angular_core.ModelSignal<boolean | null>;
    /** Left status bar. `null` (the default) draws no bar at all. */
    barColor: _angular_core.InputSignal<UiAccordionBarColor | null>;
    /** Count badge after the title. `null` (the default) draws no badge. */
    count: _angular_core.InputSignal<number | null>;
    /**
     * Can this accordion open at all? `true` by default — every call site that
     * predates this input renders byte-identically.
     *
     * `false` for a header whose count is 0 (a bucket/section with nothing in
     * it — org-profile-drawer.ts's Trades tab and murex-v2.ts's outcome
     * accordions both pass `[expandable]="count > 0"`, batch 31 Aug 2026):
     * the chevron is not drawn, the header does not respond to a click (no
     * pointer cursor either — see the header-not-expandable rule in
     * accordion.scss), and the body is never rendered — there is nothing
     * behind it to show, so nothing is built rather than built-and-hidden.
     */
    expandable: _angular_core.InputSignal<boolean>;
    /**
     * Defer the `[accordion-body]` template until the first open. `false`
     * (the default) stamps it immediately. See the class doc — and note it
     * governs the TEMPLATE only; the default slot always projects.
     */
    lazyBody: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** The `[accordion-header]` projection, if any — see `UiAccordionHeader`. */
    private readonly headerSlot;
    protected readonly hasHeaderSlot: _angular_core.Signal<boolean>;
    /** The `[accordion-actions]` projection, if any — see `UiAccordionActions`. */
    private readonly actionsSlot;
    protected readonly hasActions: _angular_core.Signal<boolean>;
    /** The `<ng-template accordion-body>`, if any — see `UiAccordionBody`. */
    private readonly bodySlot;
    protected readonly bodyTemplate: _angular_core.Signal<TemplateRef<any> | null>;
    /** Which element is the toggle: the full row (no actions) or the title column (actions). */
    protected readonly rowIsToggle: _angular_core.Signal<boolean>;
    protected readonly mainIsToggle: _angular_core.Signal<boolean>;
    /** The uncontrolled path's own state — seeded from `defaultOpen` on init,
     *  read only while `expanded()` is null (see the class doc). */
    private readonly uncontrolledOpen;
    /** The EFFECTIVE open state the header and body render from: the model
     *  when controlled, the private signal otherwise, and never open while
     *  `expandable` is false. */
    protected readonly open: _angular_core.Signal<boolean>;
    /** Latches on the first open and never resets — `lazyBody`'s gate. */
    protected readonly hasOpened: _angular_core.WritableSignal<boolean>;
    constructor();
    ngOnInit(): void;
    /** Always writes the model — the one path that emits `expandedChange`. */
    protected toggle(): void;
    protected onRowClick(): void;
    protected onRowKeydown(event: KeyboardEvent): void;
    protected onMainClick(): void;
    protected onMainKeydown(event: KeyboardEvent): void;
    protected onChevronClick(): void;
    /**
     * Keyboard-operable header (DLS Focus variants, gap (b)): Enter/Space
     * toggle, same as a click. `expandable()` is checked again here even
     * though a non-expandable header carries no `tabindex` and so cannot
     * receive keyboard focus in the first place — belt-and-suspenders against
     * a bubbled keydown from a focused descendant (e.g. the actions slot).
     */
    protected onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiAccordion, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiAccordion, "ui-accordion", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "defaultOpen": { "alias": "defaultOpen"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "barColor": { "alias": "barColor"; "required": false; "isSignal": true; }; "count": { "alias": "count"; "required": false; "isSignal": true; }; "expandable": { "alias": "expandable"; "required": false; "isSignal": true; }; "lazyBody": { "alias": "lazyBody"; "required": false; "isSignal": true; }; }, { "expanded": "expandedChange"; }, ["headerSlot", "actionsSlot", "bodySlot"], ["[accordion-header]", "[accordion-actions]", "*"], true, never>;
}

/**
 * The focus-overlay ACTION ROW (owner's directive 6, 5 Sep 2026) — "content
 * in `ui-card`s 16px apart, action buttons OUTSIDE the cards, below the last
 * one". A host-class directive on whatever wraps the buttons:
 *
 *   <ui-modal-shell title="Clarification Request" (closed)="close()">
 *     <ui-card title="Selected Issues">…</ui-card>
 *     <ui-card title="Details">…</ui-card>
 *     <div ui-actions-row>
 *       <button ui-button variant="secondary" (click)="close()">Cancel</button>
 *       <button ui-button variant="primary" (click)="submit()">Submit</button>
 *     </div>
 *   </ui-modal-shell>
 *
 * Flex row, buttons flush RIGHT at the 8px unit gap (`--gap-unit-h`), 16px
 * above. `align="between"` parks the first child on the LEFT — a `ui-switch`
 * with its label, or a note — and the buttons stay right:
 *
 *   <div ui-actions-row align="between">
 *     <label class="…"><ui-switch [(checked)]="notify" /> Notify the desk</label>
 *     <button ui-button variant="secondary">Cancel</button>
 *     <button ui-button variant="primary">Submit</button>
 *   </div>
 *
 * Styled by `styles/ui-actions-row.css` — a kit-level GLOBAL
 * class, the same shape as `ui-tables.css`, because a directive has no
 * stylesheet of its own and the row is a layout contract, not a component.
 * It is NOT the `[ui-modal-footer]` bar: that one is pinned to the panel's
 * bottom edge behind a rule and scrolls nothing; this row scrolls WITH the
 * cards and is the default for the app's overlays.
 *
 * RESKIN: keep the selector, the `align` input and the two class names;
 * restyle the CSS file against the DLS focus-overlay footer spec.
 */
declare class UiActionsRow {
    /** `end` (default): everything right-aligned. `between`: first child left, the rest right. */
    align: _angular_core.InputSignal<"end" | "between">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiActionsRow, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<UiActionsRow, "[ui-actions-row]", never, { "align": { "alias": "align"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** One entry in the `anchors` list — a jump target rendered as an underlined link. */
interface UiAlertAnchor {
    label: string;
    id: string;
}
/**
 * RESKIN: DLS `alert` (Figma set 11895:97216, "Small (for internal tools)"
 * size, REGISTER.md §2, audited 2 Sep 2026) — the danger-only
 * validation alert. The DLS set carries an info/success/warning tone axis
 * too, but every one of those tones belongs to Information banner (walk item
 * 20, not yet built) — this component is deliberately DANGER-ONLY, no `tone`
 * input. Standard vs Small showed no measurable difference in the harvest;
 * Small's "(for internal tools)" naming makes it ours regardless, and the
 * compactness override (REGISTER.md decision log) pulls the
 * title down to the reference app's 14px while keeping the DLS semibold weight.
 *
 * Chrome is shared across every variant: bg level_2, 1px danger border,
 * 4px radius, elevation-2 shadow, 16/12 padding, 12px icon-to-content gap.
 * The four DLS variations fall out of which inputs are set, not separate
 * component modes:
 *
 *   <ui-alert>Something needs your attention.</ui-alert>
 *
 *   <ui-alert title="Invalid trade count">
 *     3 trades could not be matched to a portfolio.
 *   </ui-alert>
 *
 *   <ui-alert title="Could not submit">
 *     Fix the errors below and try again.
 *     <button ui-alert-actions ui-button variant="secondary">Retry</button>
 *     <button ui-alert-actions ui-button variant="plain">Dismiss</button>
 *   </ui-alert>
 *
 *   <ui-alert
 *     title="Some fields need correction"
 *     [anchors]="[{ label: 'SG mobile numbers have 8 digits', id: 'mobile' }]"
 *     (anchorActivated)="scrollToField($event)"
 *   >
 *     Review the highlighted fields and resubmit.
 *   </ui-alert>
 *
 * `message` is the default-slot projected body (body/sm, --color-text-body)
 * — kept as plain content rather than a string input because callers already
 * reach for rich inline markup here (the DLS validation copy mixes plain
 * text and emphasis), matching ui-info-banner's own default-slot precedent.
 */
declare class UiAlert {
    /** Optional — omit for the single-line "no title" variant. */
    title: _angular_core.InputSignal<string | undefined>;
    /** Validation-summary jump links (DLS "With anchor" variation). */
    anchors: _angular_core.InputSignal<readonly UiAlertAnchor[]>;
    anchorActivated: _angular_core.OutputEmitterRef<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiAlert, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiAlert, "ui-alert", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "anchors": { "alias": "anchors"; "required": false; "isSignal": true; }; }, { "anchorActivated": "anchorActivated"; }, never, ["*", "[ui-alert-actions]"], true, never>;
}

/**
 * DLS `accordion-separator` ("ContentSeparator", Figma node 1959:7) —
 * REGISTER.md §1 gap (a). A disclosure with NO box chrome: a
 * background-alt header BAR (no border, 4px radius) sitting directly above
 * free content, versus `ui-accordion`'s bordered card. The two are siblings,
 * not one component with a variant — a box vs no-box axis on `ui-accordion`
 * would mean every consumer re-checking a `boxed` input to know whether a
 * border/shadow/background is about to appear around their content, and the
 * DLS file itself ships these as two separate component sets for the same
 * reason.
 *
 *   <ui-content-separator title="Trade History">
 *     …free content, no wrapper chrome…
 *   </ui-content-separator>
 *
 *   <ui-content-separator
 *     title="Amendments"
 *     subtitle="Last edited 2 Sep"
 *     actionLabel="Edit"
 *     (actionActivated)="onEdit()"
 *   >…</ui-content-separator>
 *
 * `actionLabel` renders a plain 24px-tall text action (label/sm) left of the
 * chevron — clicking it emits `actionActivated` and does NOT toggle the
 * disclosure (its own click handler stops propagation before the bar's
 * click handler ever sees it).
 *
 * The open/close mechanics (grid-rows track animation, `expandable`
 * dead-header rule, keyboard Enter/Space, focus-visible ring) are the SAME
 * recipe as `ui-accordion` (accordion.ts / accordion.scss) — copied rather
 * than shared by import, since the two components' DOM shapes differ (a
 * box with a bordered header vs a bare bar over free content) and importing
 * across them would couple two DLS component sets that are independent in
 * the source library.
 *
 * RESKIN: delegate to the DLS `accordion-separator` / ContentSeparator
 * (Figma 1959:7); keep selector + inputs unchanged.
 */
declare class UiContentSeparator {
    title: _angular_core.InputSignal<string>;
    /** Second line under the title — label/sm, `--color-text-subtle`. */
    subtitle: _angular_core.InputSignal<string | null>;
    /** Plain 24px text action left of the chevron. `null` renders none. */
    actionLabel: _angular_core.InputSignal<string | null>;
    defaultOpen: _angular_core.InputSignal<boolean>;
    /** Symmetry with `ui-accordion`'s dead-header rule — see its doc comment. */
    expandable: _angular_core.InputSignal<boolean>;
    /** Fired when the action label is clicked. Never toggles the disclosure. */
    actionActivated: _angular_core.OutputEmitterRef<void>;
    protected open: _angular_core.WritableSignal<boolean>;
    ngOnInit(): void;
    protected toggle(): void;
    protected onKeydown(event: KeyboardEvent): void;
    protected onActionClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiContentSeparator, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiContentSeparator, "ui-content-separator", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; "defaultOpen": { "alias": "defaultOpen"; "required": false; "isSignal": true; }; "expandable": { "alias": "expandable"; "required": false; "isSignal": true; }; }, { "actionActivated": "actionActivated"; }, never, ["*"], true, never>;
}

interface UiMenuItem {
    key: string;
    label: string;
    danger?: boolean;
}
/**
 * Kebab (⋮) row-action menu — right-aligned dropdown (ported from the NPA
 * dashboard row menu). The trigger is a `ui-icon-button` (register item 8,
 * REGISTER.md §8) at `size="small"` — DLS has no 28px icon-
 * button cell, so the old hand-measured 28px trigger rounds up to the
 * nearest DLS size, 32.
 *
 *   <ui-kebab-menu [items]="rowActions" (selected)="onAction($event)" />
 *
 * RESKIN: delegate to the DLS overflow/context menu; keep selector + inputs unchanged.
 *
 * ── DLS REPLICA (REGISTER.md §16, audited 2 Sep 2026) ────────
 * The popover is now `ui-dropdown-menu` (bg level_1, radius-md, elevation-3,
 * 4px inset) and each row a `button[ui-dropdown-item]` (min-h 40, 8/12
 * padding, label(sm) 13/500) — the hand-rolled menu chrome this file used
 * to paint itself is gone; only positioning (`.menu`'s absolute placement)
 * and the pop-in animation stay local. `class="item"`/`item-danger` are
 * kept on the new elements and the danger colour is boosted past
 * ui-dropdown-item's own internal specificity (kebab-menu.scss).
 */
declare class UiKebabMenu {
    items: _angular_core.InputSignal<UiMenuItem[]>;
    selected: _angular_core.OutputEmitterRef<string>;
    protected open: _angular_core.WritableSignal<boolean>;
    private host;
    protected toggle(event: Event): void;
    protected pick(key: string): void;
    protected onDocumentClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiKebabMenu, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiKebabMenu, "ui-kebab-menu", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; }, { "selected": "selected"; }, never, never, true, never>;
}

type UiDropdownMenuRole = 'menu' | 'listbox';
/**
 * DLS 3.1 `dropdown-menu` (set 53775:283622, REGISTER.md §16,
 * audited 2 Sep 2026) — the shared popover surface `ui-kebab-menu`, the
 * `ui-breadcrumb` overflow popover and `ui-multi-select`'s panel all
 * delegate to (register item 16, built 2 Sep 2026). 200px min-width, bg
 * `--color-bg-level1`, radius `--radius-md` (8, DLS panel-lg),
 * `--shadow-elevation-3`, 4px vertical inset padding around the item list.
 *
 *   <ui-dropdown-menu>
 *     <button ui-dropdown-item>View details</button>
 *     <button ui-dropdown-item>Edit</button>
 *   </ui-dropdown-menu>
 *
 * **`role`** — `menu` (default) | `listbox`, set on the item-list wrapper;
 * callers building a single/multi-select listbox pass `role="listbox"`.
 *
 * **`width`** — overrides the 200px default (e.g. a wider account menu, or
 * `ui-multi-select`'s `max(320px, 100%)` "320 or the trigger's width,
 * whichever is larger" rule) via a direct `[style.width]` binding, so it
 * always wins over the class-level `min-width: 200px` regardless of
 * stylesheet load order.
 *
 * **`[uiDropdownMenuHeader]`** — the DLS "With header" variation: an
 * optional slot above the item list (16px h / 12px v-top padding, no
 * bottom padding/border, 8px gap to the list below) a caller projects a
 * search box and/or a Select all/Reset row into — see `ui-multi-select`'s
 * migration.
 *
 * CORRECTION (owner review, 3 Sep 2026): the header drew a border-bottom
 * DLS doesn't have (dropped, replaced by the list's 8px top gap); an
 * ungrouped item list now gets the same 4px inset a grouped one gets from
 * its own group padding.
 *
 * **Grouped Items variation** — wrap sibling items in
 * `<div ui-dropdown-group>`; dropdown-menu.scss adds each group's 4px
 * inset padding and, between consecutive groups, a 1px
 * `--color-border-decorative` top rule. Groups are content the CALLER's
 * own template projects in (their own Angular encapsulation, not this
 * component's), so reaching the sibling-group rule needs `::ng-deep` —
 * the same projected-content technique `ui-button`'s icon slots and
 * `ui-breadcrumb`'s popover already document.
 *
 * RESKIN: delegate to the DLS dropdown-menu Angular component; keep this
 * selector, the `role`/`width` inputs and the named header slot.
 */
declare class UiDropdownMenu {
    role: _angular_core.InputSignal<UiDropdownMenuRole>;
    width: _angular_core.InputSignal<string | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiDropdownMenu, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiDropdownMenu, "ui-dropdown-menu", never, { "role": { "alias": "role"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; }, {}, never, ["[uiDropdownMenuHeader]", "*"], true, never>;
}

/**
 * DLS 3.1 `dropdown-item` (53775:283454, REGISTER.md §16,
 * audited 2 Sep 2026) — attribute component on a native `<button>` so
 * type/disabled/form semantics stay intact, same pattern as
 * `ui-icon-button`/`ui-chip`:
 *
 *   <button ui-dropdown-item>Plain row</button>
 *   <button ui-dropdown-item><svg uiDropdownIcon>…</svg> With icon</button>
 *   <button ui-dropdown-item><ui-avatar uiDropdownAvatar size="xs" .../> Name</button>
 *   <button ui-dropdown-item><ui-toggle uiDropdownTrailing .../> Autosave</button>
 *   <button ui-dropdown-item [loading]="true">Loading</button>
 *   <button ui-dropdown-item [selected]="true">Selected</button>
 *   <button ui-dropdown-item disabled>Disabled</button>
 *   <button ui-dropdown-item>
 *     Name
 *     <span uiDropdownDescription>Metadata line</span>
 *   </button>
 *
 * min-h 40, 8px v / 12px h padding, radius 4, kit `label(sm)` 13/500
 * `--color-text-strong`, 8px gap. Named projection slots —
 * `[uiDropdownIcon]` (16px leading glyph, `--color-icon`),
 * `[uiDropdownAvatar]` (a 24px `ui-avatar size="xs"`), `[uiDropdownTrailing]`
 * (e.g. a `ui-toggle`, pinned right) — sized/positioned via `::ng-deep` in
 * dropdown-item.scss, the same projected-content escape `ui-button`'s icon
 * slots and `ui-icon-button`'s glyph sizing use (a plain scoped rule can
 * never reach content the CALLER's own template projects in).
 *
 * GROWTH (REGISTER.md §36, "Select — remainder audit", 3 Sep
 * 2026) added two more, both additive: `[uiDropdownAvatarSecondary]` — a
 * SECOND 24px leading slot, for the one row shape (`multi-select-option`,
 * DLS 273655:2345) where the FIRST leading slot is already spoken for by a
 * selection control (`ui-multi-select`'s checkbox projects into
 * `[uiDropdownAvatar]`), so an option's own avatar needs a slot after it
 * rather than instead of it. `[uiDropdownDescription]` — the DLS
 * "Metadata" second line: projected alongside the default-slot label
 * inside a new `.ui-dropdown-item-text` column wrapper (kit `label(sm)`
 * 13px `--color-text-subtle`, 2px gap under the label), which is why plain
 * single-line callers are unaffected — the wrapper is just one more flex
 * layer around the same label span, `flex:1`/ellipsis unchanged.
 *
 * States: Hover `--color-bg-hover`, `:active` `--color-bg-pressed`,
 * `:focus-visible` 2px inset `--color-focus`, `:disabled`
 * `--color-text-disabled` (+ `[uiDropdownIcon]` dropping to
 * `--color-icon-disabled`). `loading` swaps the label for three 8px dots
 * (`ui-button`'s own loading-dot family, button.scss). `selected`
 * (`aria-selected`) is the DLS single-select account-row treatment reused
 * here per the register ("belongs with any item"): `--color-bg-selected`
 * fill, a 4px `--color-success-strong` left bar (8px top/bottom inset,
 * spanning the row's content height), and a trailing 16px check glyph.
 *
 * CORRECTION (owner review, 3 Sep 2026): the loading dots now centre in
 * the item (`flex:1; justify-content:center`) and paint `--color-icon`,
 * not currentColor; the selected bar insets 8px top/bottom instead of
 * spanning the full row.
 *
 * RESKIN: delegate to the DLS dropdown-item Angular component; keep this
 * selector, the three named slots and the `selected`/`loading` inputs.
 */
declare class UiDropdownItem {
    selected: _angular_core.InputSignalWithTransform<boolean, unknown>;
    loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiDropdownItem, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiDropdownItem, "button[ui-dropdown-item]", never, { "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; }, {}, never, ["[uiDropdownIcon]", "[uiDropdownAvatar]", "[uiDropdownAvatarSecondary]", "*", "[uiDropdownDescription]", "[uiDropdownTrailing]"], true, never>;
}

/**
 * DLS 3.1 `dropdown-heading` (53775:283784, REGISTER.md §16,
 * audited 2 Sep 2026) — a 40px group label row, 12px h-padding, kit
 * `label(sm)` `--color-text-subtle`:
 *
 *   <ui-dropdown-heading>Recent</ui-dropdown-heading>
 *   <ui-dropdown-heading back (backActivated)="onBack()">Team Management</ui-dropdown-heading>
 *
 * **`back`** renders a leading 16px chevron-left glyph and turns the whole
 * row into a `<button>` emitting `backActivated` — the sub-menu return
 * affordance. Without it the heading is inert text.
 *
 * CORRECTION (owner review, 3 Sep 2026): DLS's heading has no hover
 * state — the `back` variant's hover→text-strong rule was removed.
 *
 * RESKIN: delegate to the DLS dropdown-heading Angular component; keep
 * this selector, the `back` input and the `backActivated` output.
 *
 * TRAP (lead, 3 Sep 2026): the label is projected through ONE `<ng-template>`
 * rendered by both branches — two bare `<ng-content>`s inside an @if/@else
 * silently send the content to only one of them, and the `back` variant
 * rendered an empty label.
 */
declare class UiDropdownHeading {
    back: _angular_core.InputSignalWithTransform<boolean, unknown>;
    backActivated: _angular_core.OutputEmitterRef<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiDropdownHeading, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiDropdownHeading, "ui-dropdown-heading", never, { "back": { "alias": "back"; "required": false; "isSignal": true; }; }, { "backActivated": "backActivated"; }, never, ["*"], true, never>;
}

/**
 * DLS 3.1 `dropdown-item-account` (55071:286576, REGISTER.md
 * §16, audited 2 Sep 2026) — the account/name row `ui-dropdown-menu-account`
 * (below) is built from: 12px v-pad, a 40px `ui-avatar` (initials or
 * `avatarColour`) + kit `label(md)` (14) `--color-text-strong` `name` +
 * optional kit `body(sm)` `--color-text-subtle` `meta`, 8px gap.
 *
 *   <button ui-dropdown-account-item name="Aiko MORI" meta="****4821" />
 *   <button ui-dropdown-account-item name="Haruto SATO" [selected]="true" />
 *   <button ui-dropdown-account-item name="Mei KOBAYASHI" multiselect [selected]="checked" />
 *   <button ui-dropdown-account-item name="Riku TANAKA" expandable [expanded]="open" />
 *
 * **Single select** (`selected`, no `multiselect`) — DLS's own selected
 * treatment: `--color-bg-selected` fill, a 4px `--color-success-strong`
 * left bar (12px top/bottom inset, spanning the 40px avatar+text content
 * block rather than the full 64px row), a trailing 16px check glyph
 * (same paint `ui-dropdown-item`'s own `selected` input draws, register
 * §16's "belongs with any item" ruling).
 *
 * CORRECTION (owner review, 3 Sep 2026): the selected bar now insets 12px
 * top/bottom to span the content block instead of the full row.
 *
 * **Multiselect** (`multiselect`) — a leading, readonly `ui-checkbox`
 * mirrors `selected` instead: the ROW is the control (a real click
 * anywhere in the row toggles it, same contract `ui-multi-select`'s rows
 * use), so the checkbox never needs its own interaction path — hence
 * `readonly`, per `ui-checkbox`'s own §10 contract.
 *
 * **Expandable** (`expandable`) — a trailing chevron-down_16 that rotates
 * 180° when `expanded` (a sub-menu discloser, e.g. "show more accounts
 * under this entity").
 *
 * RESKIN: delegate to the DLS dropdown-item-account Angular component;
 * keep this selector and every input.
 */
declare class UiDropdownAccountItem {
    name: _angular_core.InputSignal<string>;
    meta: _angular_core.InputSignal<string | undefined>;
    avatarColour: _angular_core.InputSignal<"goji" | "ginger" | "lemon" | "lime" | "melon" | "mint" | "lavender" | "acai" | "goji-ginger" | "ginger-lemon" | "lemon-lime" | "lime-melon" | "melon-mint" | "mint-lavender" | "lavender-acai" | "acai-goji">;
    selected: _angular_core.InputSignalWithTransform<boolean, unknown>;
    multiselect: _angular_core.InputSignalWithTransform<boolean, unknown>;
    expandable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    expanded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiDropdownAccountItem, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiDropdownAccountItem, "button[ui-dropdown-account-item]", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "meta": { "alias": "meta"; "required": false; "isSignal": true; }; "avatarColour": { "alias": "avatarColour"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "multiselect": { "alias": "multiselect"; "required": false; "isSignal": true; }; "expandable": { "alias": "expandable"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * DLS `dropdown-menu` "Grouped Items" variation marker (register §16) —
 * wrap sibling items in `<div ui-dropdown-group>…</div>`;
 * `dropdown-menu.scss` adds the 4px inset padding and, between
 * consecutive groups, the 1px `--color-border-decorative` top rule. No
 * behaviour lives here; it exists purely so the attribute is a typed,
 * documented part of the kit rather than a bare string callers have to
 * remember.
 */
declare class UiDropdownGroup {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiDropdownGroup, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<UiDropdownGroup, "[ui-dropdown-group]", never, {}, {}, never, never, true, never>;
}

type UiSnackbarTone = 'neutral' | 'success' | 'warning' | 'danger' | 'info';
/**
 * Snackbar toast — the DLS 3.1 `snackbar` component (page 305:2717, set
 * 486:2468, REGISTER.md §37, audited + grown 3 Sep 2026).
 * Anchored bottom-centre of its positioned ancestor (ported from the NPA
 * Pre-NPA document snackbar), now with an optional status icon, an
 * optional action button and a kit close control:
 *
 *   <ui-snackbar message="Document saved" (dismissed)="saved.set(false)" />
 *
 *   <ui-snackbar tone="warning" message="3 fields could not be validated."
 *     actionLabel="Review" (action)="review()" (dismissed)="warn.set(false)" />
 *
 * **`tone`** — `neutral` (default, no icon, byte-identical to the old
 * message-only face) | `success` | `warning` | `danger` | `info`. Each
 * non-neutral tone renders a 24px FILLED status glyph in a 32px-min wrap:
 * warning = triangle-exclamation-filled `--color-warning-strong`, success =
 * circle-checkmark-filled `--color-success-strong`, danger =
 * circle-exclamation-filled `--color-danger`, info = info-circle
 * `--color-info-bar`. TOKEN NOTE: DLS's spec calls for "on-dim" status
 * tones against the dark panel, but the kit has no dedicated on-dim status
 * ladder (checked tokens.css — only the plain `--color-*-strong` /
 * `--color-danger` / `--color-info-bar` tones exist, the same ones
 * `ui-info-banner` §20 already draws on a LIGHT panel). Reused as-is: all
 * four are saturated fills that read fine against `--color-bg-dim`, and
 * this round may not touch tokens.css to mint on-dim variants.
 *
 * **`actionLabel`** — optional. Renders a Small `ui-button variant="primary"`
 * (DLS's product_alt action button; `--color-primary` is the kit's
 * standing white-label seam for that role) 12px after the message; a click
 * emits `action`. Omit it and no button renders.
 *
 * **`dismissible`** — default `true`. Renders a close control: a tiny
 * `ui-icon-button` (`tone="on-dim"`) carrying a 16px `close_16` glyph, in
 * its own 32px-min wrap so it lines up with the icon/message row rhythm
 * even though the icon-button's own Tiny box is 24px. Set `false` to hide
 * it entirely (a snackbar with no `action` and no close is decorative —
 * the host is responsible for timing its own dismissal via `dismissed`
 * never firing from the UI in that case).
 *
 * **Auto-dismiss** — none exists today (checked snackbar.ts before this
 * round: no timer, no `duration` input) and none is added here; every
 * caller dismisses explicitly (a revoke/save confirmation, a manual close
 * click). Not part of this round's brief beyond "keep what exists."
 *
 * `role="status"` + implicit `aria-live="polite"` (a `status` role's
 * default) is kept from the pre-round component, unchanged.
 *
 * RESKIN: delegate to the DLS toast/snackbar; keep selector + `message` /
 * `dismissed` unchanged for the four existing callers (inbox, NPA
 * dashboard, Murex v2 sign-off, external-platforms revoke toast).
 */
declare class UiSnackbar {
    message: _angular_core.InputSignal<string>;
    /** DLS's status-icon axis — see the class doc. Default `neutral` renders no icon. */
    tone: _angular_core.InputSignal<UiSnackbarTone>;
    /** Optional action button label; omit for no action button. */
    actionLabel: _angular_core.InputSignal<string | undefined>;
    action: _angular_core.OutputEmitterRef<void>;
    /** Default `true` — set `false` to hide the close control. */
    dismissible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    dismissed: _angular_core.OutputEmitterRef<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiSnackbar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiSnackbar, "ui-snackbar", never, { "message": { "alias": "message"; "required": true; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; }, { "action": "action"; "dismissed": "dismissed"; }, never, never, true, never>;
}

type UiPaginationType = 'basic' | 'complex' | 'lazy';
/**
 * Pagination — the DLS 3.1 `pagination` set (page 467:1105, set 1466:3602,
 * REGISTER.md §30, audited/built 3 Sep 2026). A level_2 footer
 * strip, 24px h / 12px v padding, bottom radius 4 — the top rule the
 * previous version drew is GONE (grepped e2e for a `border-top` assertion
 * on `ui-pagination` first: none exists, the only spec touching this
 * selector, an e2e spec, only asserts visibility — so nothing relies on
 * it).
 *
 *   <ui-pagination [total]="rows.length" [(page)]="page" [(pageSize)]="pageSize" />
 *   <ui-pagination type="basic" [total]="rows.length" [(page)]="page" />
 *   <ui-pagination type="lazy" [loading]="isLoadingMore()" />
 *
 * **`type`** — DLS's Type axis: `basic` | `complex` (default — the two
 * existing callers, the NPA dashboard and the reference modal, keep their
 * current anatomy unchanged) | `lazy`.
 *
 * **`basic`**: left counter ("Showing 1-10 of 64 items", label/sm strong)
 * + right two Small secondary `ui-button`s "Previous" / "Next" (32px, 8
 * gap), disabled at the ends.
 *
 * **`complex`**: left counter + "Items per page" (label/sm subtle) + the
 * existing 72px `ui-select`; right a button group of four Small bordered
 * `ui-icon-button`s (32px, `outline`, 24px hand-authored chevron glyphs —
 * DLS names them chevron-left-last / chevron-left / chevron-right /
 * chevron-right-last, no glyph exists in this kit's icon set yet, reported
 * in the round notes) around a 64px page-jump INPUT (`ui-text-input`-
 * styled), then "Page 1 of 7" (label/sm subtle). The page input tracks the
 * caller's `page` while unfocused; typing a number and pressing Enter or
 * blurring jumps to that page, CLAMPED 1..pages — an out-of-range or
 * non-numeric value simply reverts to the current page rather than
 * committing (`commitPage()` below).
 *
 * **`lazy`**: a 16px partial loader + "Loading more..." (label/sm subtle),
 * shown only while `loading` is true. DLS's `loader-partial` (see
 * `ui-loader`) draws its three dots at a fixed 8px — it has no `size`
 * input to shrink to DLS's 16px lazy-pagination reading here, so this
 * state hand-draws its own three 4px dots locally rather than reaching for
 * `ui-loader` (reported: `ui-loader` needs a `size` axis in a future
 * round). A `loadMore` output is NOT wired — an intersection-observer
 * "scroll into view" trigger is not a trivial addition to a presentational
 * component with no host viewport awareness, so it is omitted per the
 * brief rather than half-built; the caller drives `loading` itself.
 *
 * RESKIN: delegate to the DLS Angular pagination component; keep the
 * selector and every input/output name.
 */
declare class UiPagination {
    type: _angular_core.InputSignal<UiPaginationType>;
    /** Required for `basic`/`complex`; ignored for `lazy`. */
    total: _angular_core.InputSignal<number>;
    page: _angular_core.ModelSignal<number>;
    pageSize: _angular_core.ModelSignal<number>;
    sizes: _angular_core.InputSignal<number[]>;
    /** `lazy` only — shows/hides the loader row. */
    loading: _angular_core.InputSignal<boolean>;
    protected String: StringConstructor;
    protected pageSizeOptions: _angular_core.Signal<string[]>;
    protected pages: _angular_core.Signal<number>;
    protected from: _angular_core.Signal<number>;
    protected to: _angular_core.Signal<number>;
    protected hostClass: _angular_core.Signal<string>;
    protected onPageSize(v: string | null): void;
    protected prev(): void;
    protected next(): void;
    private editing;
    private draft;
    protected pageDisplay: _angular_core.Signal<string>;
    protected onPageInputFocus(): void;
    protected onPageInputChange(v: string): void;
    protected commitPage(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiPagination, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiPagination, "ui-pagination", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "total": { "alias": "total"; "required": false; "isSignal": true; }; "page": { "alias": "page"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "sizes": { "alias": "sizes"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; }, { "page": "pageChange"; "pageSize": "pageSizeChange"; }, never, never, true, never>;
}

/**
 * Rich-text editor — bordered toolbar + textarea used by inbox replies,
 * remarks fields and the Ops Risk action modals. Toolbar buttons are
 * decorative in the prototype (parity with the React reference).
 *
 *   <ui-rich-text [(value)]="remarks" placeholder="Add your remarks here..." />
 *
 * `invalid` + `errorMessage` — the canonical error-state contract shared by
 * every kit form control (see ui-text-input for the full docstring). This
 * is a bordered composite (toolbar + textarea), so the border/fill lands
 * on the outer `.shell` wrapper rather than on the toolbar buttons — the
 * toolbar keeps its normal chrome. The two inputs stay independent, same
 * as everywhere else.
 *
 * ── The toolbar (KIT-FIXES B2, 7 Sep 2026) ──────────────────────────────
 * Fourteen tools, each a `button[ui-icon-button size="tiny"]` (24px box)
 * holding a 16px glyph — the owner's ruling of 7 Sep settled the scale at
 * 16 (the previous glyphs were hand-drawn at 14). Twelve of the fourteen
 * draw a real DLS mark through `ui-icon`: `arrow-undo`, `arrow-undo`
 * mirrored for Redo (ruling R9 — the DLS ships no redo symbol, and
 * mirroring the official mark is honest where drawing a second arrow is
 * not), `color-palette`, `align-left` / `-center` / `-right` / `-justify`,
 * `bold`, `italic`, `list`, `paperclip`, `image`.
 *
 * TWO remain inline `<svg>` in the template: the FONT/type control and
 * UNDERLINE. Neither symbol is in the catalogue — both are likely among the
 * 71 DLS symbols still unfetched — and the registry's `text-style` entry is
 * NOT the font mark: it is this component's own former drawing, harvested
 * out of this file, so naming it would launder a stand-in as DLS artwork.
 * Both stand-ins are redrawn on the 16 grid at stroke-width 1 to sit at the
 * same weight as the twelve real glyphs; each carries a template comment
 * naming what it waits for. Swapping them is a two-line template change.
 *
 * The buttons stay DECORATIVE — the editing surface is a plain `<textarea>`,
 * which cannot carry formatting — so the eight toggle-shaped tools (the
 * four aligns, bold, italic, underline, list) declare a STATIC
 * `aria-pressed="false"`. That announces them correctly as toggle buttons
 * and is true of the document as it stands; it is deliberately not bound to
 * a signal, because a Bold button that lights up while the text does not go
 * bold is a worse lie than a toolbar that plainly does nothing. The six
 * action-shaped tools (undo, redo, font, colour, attach, image) carry no
 * `aria-pressed`. Hover / pressed / focus / disabled visuals all come from
 * `ui-icon-button`; this component hand-rolls none of them.
 *
 * The old `title` attributes are gone in favour of real `aria-label`s. That
 * loses the native hover tooltip; `[uiTooltip]` was not substituted, since
 * the DLS tooltip is a titled multi-line panel, not a one-word hover label.
 *
 * RESKIN: token-reskin-only — the DLS is unlikely to ship a rich-text
 * editor; this component keeps its markup and inherits the DBS tokens.
 */
declare class UiRichText {
    value: _angular_core.ModelSignal<string>;
    placeholder: _angular_core.InputSignal<string>;
    minHeight: _angular_core.InputSignal<number>;
    /** Error state — see ui-text-input's docstring for the shared contract. */
    invalid: _angular_core.InputSignal<boolean>;
    errorMessage: _angular_core.InputSignal<string>;
    protected onInput(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiRichText, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiRichText, "ui-rich-text", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "minHeight": { "alias": "minHeight"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

interface UiMultiSelectItem {
    key: string;
    label: string;
    /** @deprecated use `description` — kept so existing callers still
     *  compile and render; `description` wins when both are set. */
    meta?: string;
    /** DLS "Metadata" second line (§36 `multi-select-option`, 273655:2294). */
    description?: string;
    /** 16px leading glyph: an SVG `<path d>` string, `[uiDropdownIcon]`.
     *  Mutually exclusive with `avatar`. */
    icon?: string;
    /** Initials source for a 24px `ui-avatar`, projected AFTER the row's own
     *  checkbox (DLS 273655:2345) — see `ui-dropdown-item`'s
     *  `[uiDropdownAvatarSecondary]` slot. */
    avatar?: string;
    /** Not selectable by click or keyboard. */
    disabled?: boolean;
}
type UiMultiSelectDisplay = 'count' | 'tags';
/**
 * Multi-select dropdown — 32px trigger + search / select-all / checkbox
 * options panel (ported from the shared modal use-case & CC pickers).
 *
 *   <ui-multi-select [items]="useCases" [(selected)]="keys" placeholder="Select use case" />
 *
 * RESKIN: delegate to the DLS multi-select/combobox; keep selector + inputs unchanged.
 *
 * ── DLS REPLICA (REGISTER.md §16, audited 2 Sep 2026) ────────
 * The panel is now the DLS menu-account chrome: `ui-dropdown-menu` at
 * `max(320px, 100%)` wide ("320, or the trigger's width, whichever is
 * larger"), a `[uiDropdownMenuHeader]` slot holding the existing search
 * input and the Select all/Reset row (now `ui-button variant="plain"
 * size="tiny"`), then rows as `button[ui-dropdown-item]` (40px, `.option`
 * kept as the class name for the pickMulti()/fillActionBlock() e2e
 * helpers) with a leading readonly `ui-checkbox` mirroring selection.
 * Behaviour — search filtering, select-all, the `selected` model,
 * `disabled` — is unchanged; only the chrome moved onto the shared
 * primitives.
 *
 * OPTION-MODEL GROWTH (§36, "Select — remainder audit", 3 Sep 2026):
 * `UiMultiSelectItem` grows `description` (DLS "Metadata", replaces the old
 * `meta` — kept as a deprecated alias so existing callers still compile),
 * `icon`, `avatar` and `disabled`. The row's own leading slot
 * (`[uiDropdownAvatar]`) is already the checkbox, so an item's `avatar`
 * projects into `ui-dropdown-item`'s new `[uiDropdownAvatarSecondary]`
 * slot — AFTER the checkbox, per DLS 273655:2345 — and `description`
 * projects into its new `[uiDropdownDescription]` slot. A `disabled` item
 * is a genuinely inert `[disabled]` row: not selectable by click or
 * keyboard, and skipped by `selectAll()`.
 *
 * TRIGGER (register §21, audited 3 Sep 2026, "Filled" 76086:347584):
 * aligned to the same shell `ui-select`'s new custom trigger uses — 32px,
 * 0/12 padding, 8 gap, hover border, 2px solid `--color-focus` inset ring
 * on open/focus, invalid bg + border, disabled paint, chevron-down_16
 * flipping to chevron-up_16 when open. `display` picks the DLS "# selected"
 * text (`count`, default — the existing `triggerLabel`, unchanged) or an
 * inline `tag-filter` chip group (`tags`) with a per-chip × that deselects
 * without opening the panel.
 */
declare class UiMultiSelect {
    items: _angular_core.InputSignal<string[] | UiMultiSelectItem[]>;
    placeholder: _angular_core.InputSignal<string>;
    selected: _angular_core.ModelSignal<string[]>;
    /**
     * Read-only mode — same contract as `ui-select`'s `disabled`: the trigger
     * is a genuinely inert native `[disabled]` button, so there is no keyboard
     * or pointer path to the panel and nothing can change `selected`. The
     * SELECTED VALUE IS UNAFFECTED: a disabled multi-select still shows its
     * chosen items and still reads back through `selected`, because callers
     * disable it to LOCK a value they have already set, not to clear it (see
     * app-clarify-modal's `useCaseLocked`).
     */
    disabled: _angular_core.InputSignal<boolean>;
    /** Error state — see ui-text-input's docstring for the shared contract. */
    invalid: _angular_core.InputSignal<boolean>;
    errorMessage: _angular_core.InputSignal<string>;
    /**
     * DLS Filled trigger (76086:347584): `count` (default) paints "N
     * selected" / the single label — `ui-multi-select`'s existing
     * `triggerLabel` behaviour, unchanged. `tags` paints an inline DLS
     * `tag-filter` chip per selection instead, each with its own × that
     * deselects without opening the panel.
     */
    display: _angular_core.InputSignal<UiMultiSelectDisplay>;
    protected readonly open: _angular_core.WritableSignal<boolean>;
    protected readonly search: _angular_core.WritableSignal<string>;
    private readonly host;
    protected readonly normalized: _angular_core.Signal<UiMultiSelectItem[]>;
    protected readonly filtered: _angular_core.Signal<UiMultiSelectItem[]>;
    protected readonly triggerLabel: _angular_core.Signal<string | null>;
    protected toggleOpen(): void;
    protected readonly selectedItems: _angular_core.Signal<UiMultiSelectItem[]>;
    protected toggle(key: string): void;
    protected isChecked(key: string): boolean;
    protected selectAll(): void;
    protected reset(): void;
    /** `tags` display's per-chip × — deselects without opening the panel. */
    protected removeTag(event: Event, key: string): void;
    protected onDocumentDown(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiMultiSelect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiMultiSelect, "ui-multi-select", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "display": { "alias": "display"; "required": false; "isSignal": true; }; }, { "selected": "selectedChange"; }, never, never, true, never>;
}

/**
 * DLS `input-field` / Text type chrome (REGISTER.md §21, Figma
 * set 12110:99059; Small nodes: default 347238, hover 90723:305648, focus
 * 347345, error 347231, disabled 347993, read-only 347780, success-with-tick
 * 347409) — same 32px shell as ui-select (Figma 1304:132287): 1px border,
 * 4px radius, DLS's 2px solid access-focus border.
 *
 *   <ui-text-input [(value)]="productName" placeholder="Enter product name" />
 *
 * Usually wrapped in `ui-form-field` for the label/help/error chrome (see
 * that component); this control owns only the field box itself.
 *
 * `bordered` (default true) drops the shell — border, background, height,
 * padding — for fields embedded inside an already-bordered composite (e.g.
 * the AI drawer composer row sitting next to a send button); everything
 * else about the control is unchanged.
 *
 * `grouped` (default false) — opt-in numeric-grouping mode: the field
 * strips non-digit/non-decimal characters as the user types and DISPLAYS
 * the value grouped with thousands separators (1,000,000), while the
 * `value` model stays a raw digit string so host validation/submission are
 * unaffected. Reuses the same grouping helper as ui-amount-input (one
 * implementation of the behaviour, not two) — use this for a plain amount
 * field that doesn't need ui-amount-input's bundled currency selector.
 *
 * `invalid` + `errorMessage` — THE CANONICAL ERROR-STATE CONTRACT for every
 * kit form control (Figma 979:5085). `invalid` paints the control's border
 * --color-danger and its fill --color-field-error-bg; `errorMessage`, when
 * non-empty, renders beneath it in --color-text-danger. The two are
 * independent on purpose: a field can be marked invalid without a message of
 * its own, which is how an either/or PAIR of fields shows one message under
 * the first while both read as invalid. NOTE: when this control sits inside
 * a `ui-form-field`, pass `errorMessage` to the WRAPPER instead — the inline
 * `.ui-field-error` span below stays only for callers that use this control
 * standalone.
 *
 * Every control that can hold a mandatory value implements these two inputs
 * with exactly these names and this markup, so feature code never has to ask
 * which control it is talking to.
 *
 * `type` (default 'text') switches the native input type. Only 'password' is
 * offered alongside the default, because that is the one variant that changes
 * BEHAVIOUR rather than presentation — masked glyphs, and the browser's
 * password-manager affordances. It is deliberately not a free `string`: the
 * numeric cases belong to `grouped` / ui-amount-input, and `type="number"`
 * would fight the grouping filter in onInput().
 *
 * `clearable` (default true) — while FOCUSED and non-empty, a trailing 16px
 * `clear-filled` icon-button replaces the field's usual trailing content and
 * empties the value on a real click; set false to suppress it (e.g. a field
 * that must never be blanked from the UI).
 *
 * `success` (default false) — a trailing 24px green check glyph
 * (`--color-success-strong`), DLS's Success-with-tick state.
 *
 * `readonly` (default false) — DLS's Read-only face: no box at all, kit
 * `body(md)` 14px text-strong on a 24px line, `aria-readonly`.
 *
 * A `[uiTextInputIcon]` slot projects a trailing 24px icon-button (DLS's
 * `eye_16` password-reveal glyph) — the caller supplies
 * `<button ui-icon-button size="tiny" uiTextInputIcon>…</button>`.
 *
 * RESKIN: delegate to the DLS text input; keep selector + inputs unchanged —
 * including `type`, which the DLS field is expected to expose in some form.
 * If it ships a separate password component instead, this input becomes the
 * switch between the two wrappers rather than a passed-through prop.
 */
declare class UiTextInput implements ControlValueAccessor {
    value: _angular_core.ModelSignal<string>;
    placeholder: _angular_core.InputSignal<string>;
    disabled: _angular_core.InputSignal<boolean>;
    bordered: _angular_core.InputSignal<boolean>;
    grouped: _angular_core.InputSignal<boolean>;
    /** Native input type — see the class docstring for why this is a two-value
     *  union and not an open string. */
    type: _angular_core.InputSignal<"password" | "text">;
    /** Error state — see the class docstring for the shared contract. */
    invalid: _angular_core.InputSignal<boolean>;
    errorMessage: _angular_core.InputSignal<string>;
    /** Trailing clear-on-focus button — see the class docstring. */
    clearable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** DLS Success-with-tick state — a trailing 24px green check. */
    success: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** DLS Read-only state — see the class docstring. */
    readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private native;
    protected focused: _angular_core.WritableSignal<boolean>;
    protected cvaDisabled: _angular_core.WritableSignal<boolean>;
    protected isDisabled: _angular_core.Signal<boolean>;
    /** Grouped presentation of `value` when `grouped` is on; otherwise the raw value. */
    protected readonly display: _angular_core.Signal<string>;
    protected showClear: _angular_core.Signal<boolean>;
    private onChange;
    protected onTouched: () => void;
    protected onInput(event: Event): void;
    protected onFocus(): void;
    protected onBlur(): void;
    protected clear(): void;
    writeValue(value: string): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTextInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTextInput, "ui-text-input", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "bordered": { "alias": "bordered"; "required": false; "isSignal": true; }; "grouped": { "alias": "grouped"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "clearable": { "alias": "clearable"; "required": false; "isSignal": true; }; "success": { "alias": "success"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, ["[uiTextInputIcon]"], true, never>;
}

/**
 * DLS `input-field` / Text area type chrome (REGISTER.md §21,
 * Figma 76086:347247) — same shell rules as ui-text-input (border/hover/
 * focus/disabled/invalid), 12/12 padding, kit `body(sm)`.
 *
 *   <ui-textarea [(value)]="description" [minHeight]="140" placeholder="Summary" />
 *
 * Not the rich-text composer (no toolbar); use ui-rich-text for that.
 * Usually wrapped in `ui-form-field` for the label/help/counter chrome.
 *
 * `bordered` (default true) drops the shell for fields embedded inside an
 * already-bordered composite (e.g. the AI drawer global/composer input row).
 *
 * `resizable` (default true) shows a 24px handler row bottom-right with an
 * 8px diagonal resize knob (two hairline strokes, hand-authored — DLS's
 * "remove handler to disable manual resize") and sets `resize: vertical`;
 * the browser's own resizer handle is hidden (`::-webkit-resizer`) so the
 * DLS knob is the only visible affordance. `maxLength`/the character
 * counter belong to the wrapping `ui-form-field`, not this control.
 *
 * RESKIN: delegate to the DLS textarea; keep selector + inputs unchanged.
 */
declare class UiTextarea implements ControlValueAccessor {
    value: _angular_core.ModelSignal<string>;
    placeholder: _angular_core.InputSignal<string>;
    minHeight: _angular_core.InputSignal<number>;
    disabled: _angular_core.InputSignal<boolean>;
    bordered: _angular_core.InputSignal<boolean>;
    /** Error state — same shared contract as ui-text-input. */
    invalid: _angular_core.InputSignal<boolean>;
    /** DLS resize knob — see the class docstring. */
    resizable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected cvaDisabled: _angular_core.WritableSignal<boolean>;
    protected isDisabled: _angular_core.Signal<boolean>;
    private onChange;
    protected onTouched: () => void;
    protected onInput(event: Event): void;
    writeValue(value: string): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTextarea, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTextarea, "ui-textarea", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "minHeight": { "alias": "minHeight"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "bordered": { "alias": "bordered"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "resizable": { "alias": "resizable"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

/** `[counter]` payload for `ui-form-field` — a raw count against a max,
 *  rendered "0/400" right-aligned on the help row (DLS's character-count
 *  affordance, set 12110:99059). `null`/omitted hides the counter. */
interface UiFormFieldCounter {
    readonly count: number;
    readonly max: number;
}
/**
 * DLS `input-field` composite (REGISTER.md §21, Figma set
 * `input-field` 12110:99059; Small nodes 76086:347238 default, 347780
 * read-only, 347231 error) — the label / optional / info / help / counter /
 * error chrome that wraps ANY kit control, projected as the default slot:
 *
 *   <ui-form-field label="Product name" [optional]="true" info="Shown on the client statement">
 *     <ui-text-input [(value)]="productName" placeholder="Enter product name" />
 *   </ui-form-field>
 *
 *   <ui-form-field label="Notes" help="Visible to the desk head" [counter]="{ count: notes().length, max: 400 }">
 *     <ui-textarea [(value)]="notes" />
 *   </ui-form-field>
 *
 *   <ui-form-field label="Trade reference" [invalid]="true" errorMessage="Reference is required">
 *     <ui-text-input [(value)]="ref" [invalid]="true" />
 *   </ui-form-field>
 *
 * `ui-form-field` never owns the control's value or validity — those stay on
 * the projected control (`ui-text-input`, `ui-textarea`, `ui-select`, …),
 * mirroring `ui-checkbox-group`'s decoupling for the same reason (Angular
 * content projection has no channel into a projected child's own inputs).
 * `invalid`/`errorMessage` here only swap the HELP ROW for the message; a
 * caller wanting the projected control itself to paint invalid passes its
 * own `[invalid]` alongside (see the third example).
 *
 * Inputs, verbatim (the migration contract ~120 hand-rolled label sites —
 * `.field-label`, `.form-label`, `.form-field`, `.detail-field-label` — move
 * onto AFTER this lands):
 * - `label` (string, required in practice) — kit `type.label(sm)` 13/500 in
 *   `--color-text-body`.
 * - `optional` (`booleanAttribute`) — appends "(optional)" after the label,
 *   same de-emphasis idiom as `ui-checkbox-group`'s `.cbg-optional`.
 * - `info` (string) — a 16px info-circle glyph after the label/optional,
 *   carrying the text as a `[uiTooltip]` (hover + focus, matching the
 *   directive's own contract). Omit to skip the glyph entirely.
 * - `help` (string) — body/sm `--color-text-subtle` under the control.
 * - `counter` (`UiFormFieldCounter | null`) — "count/max" right-aligned on
 *   the same help row, 8px gap from the help text.
 * - `invalid` (boolean) + `errorMessage` (string) — when both are set, the
 *   help row shows `errorMessage` in `--color-text-danger` INSTEAD of
 *   `help`/`counter` (same either/or the help row already does).
 * - `readonly` (boolean) — DLS's read-only label gap (4px, not 8px); the
 *   PROJECTED CONTROL is expected to render its own read-only face (see
 *   `ui-text-input`'s `readonly` input) — this component only tightens the
 *   label gap to match.
 * - `for` (string, optional) — placed on the `<label for>` when the
 *   projected control exposes a matching id.
 * - `value` (`string | null`, default `null`, 5 Sep 2026) — READ-ONLY TEXT
 *   the field renders ITSELF, no control needed:
 *
 *     <ui-form-field label="Desk" value="FX Options" />
 *
 *   The text draws in `ui-text-input`'s exact read-only face (kit
 *   `body(md)` 14px, `--color-text-strong`, 24px line, no box — see
 *   `.ti-readonly` in text-input.scss) and the label gap tightens to the
 *   read-only 4px automatically, as if `readonly` had been passed. This
 *   is the kit answer to the app's ~40 hand-rolled `.detail-field-label` +
 *   `.detail-field-value` pairs (Profile, Team Members, System Access
 *   drawers) — a label over static text — which until now had to wrap a
 *   `ui-text-input [readonly]` just to get the typography. `label`,
 *   `help`, `optional`, `info`, `for` all keep working. When `value` is
 *   set the default slot is NOT rendered — a field is either a control or
 *   a value, never both; pass `null` (the default) to get the projected
 *   control back. `''` is a real (empty) value and renders the empty
 *   read-only line at its 24px height, so a grid of fields keeps its rows
 *   aligned when one is blank.
 *
 * - `multiline` (`booleanAttribute`, default `false`, 6 Sep 2026) — with
 *   `value`, renders the text `white-space: pre-line` so the newlines in
 *   it survive as line breaks (a paragraph of spec prose, a `\n\n`-joined
 *   description). Same face — `body(md)`, `--color-text-strong`, the 24px
 *   line — and the same 24px minimum; the field simply grows a line per
 *   break. Without `multiline` (or without `value`) nothing changes: the
 *   single-line face collapses whitespace exactly as before, so a grid of
 *   one-line fields is unaffected. This is the kit answer to NPA's
 *   `.field-block` spec prose (inventory B20c) and the review page's
 *   Product Description, both of which the single-line face would have
 *   flattened:
 *
 *     <ui-form-field label="Purpose or rationale" [value]="purpose()" multiline />
 *
 * - `layout` (`'vertical' | 'horizontal'`, default `'vertical'`, 5 Sep
 *   2026) — `horizontal` puts the label in a fixed-width column on the
 *   LEFT and the control (or `value`) on the right, vertically aligned to
 *   the control's first line: the label row takes the control's 32px
 *   height (24px in the read-only / `value` face) and centres the label
 *   in it, so a one-line control reads as a pair and a textarea keeps
 *   the label on its first line. `help`/error/counter render under the
 *   VALUE column, not the label. This is the kit answer to the app's six
 *   label-left field tables (NPA draft/generate/review, the new-request
 *   log — inventory B18, B20-B23):
 *
 *     <ui-form-field layout="horizontal" label="Product name">
 *       <ui-text-input [(value)]="productName" />
 *     </ui-form-field>
 *     <ui-form-field layout="horizontal" label="Desk" value="FX Options" />
 *
 * - `labelWidth` (`number | null`, px, default `null` = 160px) — the label
 *   column's width. It lands on the host as the `--ff-label-width` custom
 *   property, which is ALSO how a whole grid of fields aligns: set
 *   `--ff-label-width: 280px` once on the wrapper and every horizontal
 *   field under it takes it; pass the input only to override one field.
 *   (An input that always wrote its default would shadow the wrapper's
 *   value — hence `null`, not `160`, as the default.)
 *
 * A `[ui-form-field-caption]` slot projects at the label row's right edge —
 * DLS's stepper "Bid size: 0.01" caption (body/sm, right-aligned).
 *
 * RESKIN: delegate to the DLS Angular `input-field` wrapper; keep this
 * selector and every input name — the migration wave targets this exact
 * contract, not whatever the DLS package happens to call its own inputs.
 */
declare class UiFormField {
    label: _angular_core.InputSignal<string>;
    optional: _angular_core.InputSignal<boolean>;
    info: _angular_core.InputSignal<string | undefined>;
    help: _angular_core.InputSignal<string>;
    counter: _angular_core.InputSignal<UiFormFieldCounter | null>;
    invalid: _angular_core.InputSignal<boolean>;
    errorMessage: _angular_core.InputSignal<string>;
    readonly: _angular_core.InputSignal<boolean>;
    for: _angular_core.InputSignal<string>;
    /** Read-only text rendered by the field itself, in place of a projected control. `null` (default) projects the slot. */
    value: _angular_core.InputSignal<string | null>;
    /** With `value`: keep its newlines as line breaks (`white-space: pre-line`). No effect on a projected control. */
    multiline: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Label above (default) or in a fixed-width column to the left of the control. */
    layout: _angular_core.InputSignal<"vertical" | "horizontal">;
    /** Horizontal label column width in px; `null` (default) defers to `--ff-label-width` on an ancestor, else 160px. */
    labelWidth: _angular_core.InputSignal<number | null>;
    protected labelWidthCss: _angular_core.Signal<string | null>;
    protected infoTooltip: _angular_core.Signal<UiTooltipContent | null>;
    protected showHelpRow: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiFormField, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiFormField, "ui-form-field", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "optional": { "alias": "optional"; "required": false; "isSignal": true; }; "info": { "alias": "info"; "required": false; "isSignal": true; }; "help": { "alias": "help"; "required": false; "isSignal": true; }; "counter": { "alias": "counter"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "for": { "alias": "for"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "multiline": { "alias": "multiline"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "labelWidth": { "alias": "labelWidth"; "required": false; "isSignal": true; }; }, {}, never, ["[ui-form-field-caption]", "*"], true, never>;
}

interface UiRadioOption {
    value: string;
    label: string;
    /** Second line under the label, kit `body(sm)` / `--color-text-subtle`,
     *  4px below — mirrors `ui-checkbox`'s `description`. */
    description?: string;
    disabled?: boolean;
}
type UiRadioLayout = 'vertical' | 'horizontal';
/**
 * DLS `radio-input` / `radio-button` / `radio-button-group` replica
 * (REGISTER.md §34, Figma 305:2705, audited 3 Sep 2026) — a
 * styled 20px control per option, in a row or a vertical list:
 *
 *   <ui-radio [options]="['Yes', 'No', 'Not Applicable']" [(value)]="businessCase" name="businessCase" />
 *
 *   <ui-radio
 *     [options]="[{ value: 'a', label: 'Option A', description: 'Applies desk-wide' }, { value: 'b', label: 'Option B' }]"
 *     layout="vertical"
 *     [(value)]="choice"
 *     name="choice"
 *   />
 *
 * ── DLS REPLICA — mirrors `ui-checkbox`'s state recipe (§10) exactly ────
 *
 * Control: a 20px circle, 2px `--color-icon` border, `--color-bg-level1`
 * background. The native `<input type="radio">` stays visually hidden but
 * focusable (CVA + real form semantics unchanged) — same visually-hidden
 * trick `ui-checkbox` uses, not `display:none`, so Tab/Space/arrow-key
 * native radio-group behaviour keeps working.
 *
 * - **Hover** — a 4px INNER ring of `--color-bg-success-subtlest`
 *   (box-shadow, checkbox's exact ring recipe), excluded for disabled /
 *   readonly.
 * - **Focus** — a 2px INNER ring of `--color-focus` on `:focus-visible`,
 *   winning over hover the same way checkbox orders the two rules.
 * - **Checked** — border `--color-icon-selected` (#00ab61) + a centred
 *   10.67px solid disc in the same green (DLS's 16px `radio-disc` box
 *   holding a 10.67px dot — drawn here as a single sized span rather than
 *   a second nested box, since only the dot itself paints).
 * - **Disabled** — `--color-bg-disabled` fill, `--color-border-disabled`
 *   border, disc (if checked) in `--color-icon-disabled`.
 * - **Error** (`invalid`) — `--color-bg-danger-subtlest` fill,
 *   `--color-danger` border, same hover halo and focus ring but in the
 *   danger tint (`hover` ring stays the success tint per DLS's own frames
 *   — see radio.scss).
 *
 * Rows: input + 8px gap + a text column (`label` kit `label(sm)` 13px/500
 * `--color-text-strong` on a 20px-min line — the owner's compactness
 * ruling carried over from checkbox, not DLS's own `label/md` 16px —
 * optional `description` `body(sm)` 13px `--color-text-subtle` 4px
 * under).
 *
 * `layout`: `'horizontal'` (DEFAULT — matches every existing caller's
 * current 24px-gap row) or `'vertical'` (DLS's list: 8px v-padding, 0 gap
 * between rows).
 *
 * `readonly` (new) — DLS `radio-button-group`'s Read-only variant: the
 * whole interactive list is replaced by the selected option's label as
 * plain text (kit `body(md)` 14px `--color-text-strong` — the same
 * read-only face `ui-select`/`ui-text-input` use), no box. Not
 * interactive by definition, so there is nothing left to focus or click.
 *
 * `invalid` + `errorMessage` — the kit's shared error contract (see
 * `ui-text-input`'s docstring). `.ui-field-error` renders under the
 * group; the field label/help row is `ui-form-field`'s job, not this
 * component's (callers wrap it, same as `ui-checkbox-group`).
 *
 * NOT `ui-radio-chiclet` — a bordered chip variant with its own file, for
 * callers that want a chip-style choice rather than a dot-and-label row.
 *
 * RESKIN: delegate to the DLS radio group; keep selector + inputs
 * unchanged (all additions are optional / additive).
 */
declare class UiRadio implements ControlValueAccessor {
    options: _angular_core.InputSignal<(string | UiRadioOption)[]>;
    name: _angular_core.InputSignal<string | undefined>;
    disabled: _angular_core.InputSignal<boolean>;
    value: _angular_core.ModelSignal<string | null>;
    /** `'horizontal'` (default, every existing caller's current row) or
     *  `'vertical'` (DLS's 8px-v-padding list). */
    layout: _angular_core.InputSignal<UiRadioLayout>;
    /** DLS `radio-button-group`'s Read-only variant — see the class doc. */
    readonly: _angular_core.InputSignal<boolean>;
    /** Error state — see ui-text-input's docstring for the shared contract. */
    invalid: _angular_core.InputSignal<boolean>;
    errorMessage: _angular_core.InputSignal<string>;
    protected cvaDisabled: _angular_core.WritableSignal<boolean>;
    protected isDisabled: _angular_core.Signal<boolean>;
    protected normalizedOptions: _angular_core.Signal<UiRadioOption[]>;
    protected selectedLabel: _angular_core.Signal<string>;
    private onChange;
    protected onTouched: () => void;
    protected onSelect(value: string): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiRadio, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiRadio, "ui-radio", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

/**
 * DLS `radio-chiclet` (REGISTER.md §34, Figma 52830:274830) —
 * a bordered chip radio, for the archive: no the reference app consumer names it yet
 * (owner ruling, round 30–34, 3 Sep 2026), so this ships as a sink-only
 * pair of components rather than wired into a page.
 *
 *   <ui-radio-chiclet-group [(value)]="scope" name="scope">
 *     <ui-radio-chiclet value="fx" label="FX">
 *       <svg uiChicletIcon width="16" height="16" …></svg>
 *     </ui-radio-chiclet>
 *     <ui-radio-chiclet value="rates" label="Rates">
 *       <ui-tag-info uiChicletTag label="NEW" />
 *     </ui-radio-chiclet>
 *   </ui-radio-chiclet-group>
 *
 * Two components, mirroring `ui-checkbox`/`ui-checkbox-group`'s split
 * (projected children own their own content; the group owns selection +
 * keyboard nav) rather than `ui-radio`'s flat `options` array — a chiclet
 * needs per-option content projection (`[uiChicletIcon]`, `[uiChicletTag]`)
 * that a data-only `options` shape cannot carry.
 *
 * `ui-radio-chiclet`: 40px min-height, 12px h / 8px v padding, radius 4,
 * 1px `--color-border`, label kit `label(sm)` 13px/500 `--color-text-strong`,
 * an optional 16px leading icon slot and an optional trailing tag slot
 * (a `ui-tag-info` fits the DLS trailing `tag-info` outline shape — see
 * the sink demo). States: hover `--color-bg-hover`; checked = border
 * `--color-primary` + bg `--color-primary-subtle` (DLS's `product_alt`
 * checked treatment mapped onto this kit's primary seam, same substitution
 * `ui-button`'s "Primary" variant makes); focus 2px inner `--color-focus`
 * ring; error border `--color-danger` + bg `--color-bg-danger-subtlest`;
 * read-only / disabled tones mirror `ui-checkbox`'s.
 *
 * `ui-radio-chiclet-group`: `value` model + `name` (for documentation
 * parity with `ui-radio`; chiclets are `role="radio"` elements, not native
 * inputs, so `name` has no DOM effect but is kept as part of the shared
 * radio-group-shaped contract), `layout` (`'horizontal'` default | `
 * 'vertical'`), `disabled` / `readonly` / `invalid` cascaded onto every
 * child that does not set its own. Arrow-key navigation is a roving
 * tabindex over the projected children (`ui-segmented`'s exact recipe,
 * §26) — Left/Up moves to the previous enabled chiclet, Right/Down to the
 * next, wrapping, and selects on arrival (radiogroup semantics, not
 * tablist).
 *
 * RESKIN: delegate to the DLS `radio-chiclet` Angular component if the
 * archive gains a consumer; keep both selectors and the icon/tag slot
 * names.
 */
declare class UiRadioChicletGroup {
    value: _angular_core.ModelSignal<string | null>;
    name: _angular_core.InputSignal<string | undefined>;
    layout: _angular_core.InputSignal<"vertical" | "horizontal">;
    disabled: _angular_core.InputSignal<boolean>;
    readonly: _angular_core.InputSignal<boolean>;
    invalid: _angular_core.InputSignal<boolean>;
    protected readonly children: _angular_core.Signal<readonly UiRadioChiclet[]>;
    /** The one tab stop: the checked chiclet, or the first enabled one with
     *  nothing checked yet — `ui-segmented`'s exact roving-tabindex rule. */
    /** Public — read by `UiRadioChiclet` (a sibling component's TypeScript,
     *  not a subclass) to resolve its own roving-tabindex stop. */
    readonly stopValue: _angular_core.Signal<string | null>;
    select(value: string): void;
    protected onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiRadioChicletGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiRadioChicletGroup, "ui-radio-chiclet-group", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, ["children"], ["*"], true, never>;
}
declare class UiRadioChiclet {
    private readonly group;
    private readonly elementRef;
    value: _angular_core.InputSignal<string>;
    label: _angular_core.InputSignal<string>;
    disabled: _angular_core.InputSignal<boolean>;
    protected readonly checked: _angular_core.Signal<boolean>;
    /** Public — the group reads this across component instances to walk
     *  arrow-key navigation and resolve the roving tab stop (`stopValue`
     *  below); a `protected` member is only reachable from within this
     *  class, not from a sibling component's TypeScript. */
    readonly isDisabled: _angular_core.Signal<boolean>;
    protected readonly isReadonly: _angular_core.Signal<boolean>;
    protected readonly isInvalid: _angular_core.Signal<boolean>;
    protected readonly tabIndex: _angular_core.Signal<0 | -1>;
    protected onClick(): void;
    /** Called by the group after an arrow-key move — focus must follow the
     *  selection by hand (`ui-segmented`'s exact note: the tabindex swing is
     *  a change-detection effect, not a focus move). */
    focusHost(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiRadioChiclet, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiRadioChiclet, "ui-radio-chiclet", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, ["[uiChicletIcon]", "[uiChicletTag]"], true, never>;
}

type UiSwitchSize = 'small' | 'medium';
/**
 * DLS `Switch` (REGISTER.md §39, Figma 84975:347031 — the
 * 16-symbol set On/Off × Default/Hover/Focus/Disabled × Small/Medium;
 * rebuilt to the harvested anatomy in the 6 Sep 2026 kit-fixes pass, item
 * 30, after the first build painted the wrong layer).
 *
 * ── ANATOMY (Small symbol 84975:347066) ──────────────────────────────────
 * `container` → `focus-ring` → `track` → `knob`, and it is the CONTAINER
 * that carries the state colour: the `<button class="ui-switch">` IS the
 * 28×18 filled pill (`--radius-pill`). Inside it, `.track` is a transparent
 * 20×10 positioning box inset 4px on every side (the `focus-ring` frame's
 * padding), and `.knob` is a 10×10 disc sitting in that box — at its left
 * edge off, `translateX(10px)` on (travel = track 20 − knob 10). The knob is
 * `--color-bg-level1` white with `--shadow-elevation-1`; disabled tints it
 * `--color-bg-disabled` (both disabled symbols carry that fill).
 *
 * Container colour per state (all `color/icon/…` roles, §39 "container
 * pill: On = icon-selected"):
 *   On   `--color-icon-selected` → hover `--color-icon-selected-hover`
 *        → disabled `--color-icon-selected-disabled`
 *   Off  `--color-icon-decorative` → hover `--color-icon-hover`
 *        → disabled `--color-icon-disabled`
 * Focus-visible = a 2px `--color-focus` ring on the `focus-ring` frame,
 * which is the same 28×18 box as the container — drawn as an INSET
 * box-shadow on the pill so the footprint never changes.
 *
 * ── SIZE ─────────────────────────────────────────────────────────────────
 * `size="small"` (default — the platform uses small only, owner's 6 Sep
 * ruling) is the 28×18 geometry above. `size="medium"` is DLS's own
 * "default" size: 40×24 pill, 32×16 track, 16px knob, travel 16, the same
 * 4px inset. The host carries `ui-switch--medium` for it; small adds no
 * class so every existing consumer and spec sees the same DOM as before.
 *
 * Renders as a single control; place a label next to it in the consumer's
 * template:
 *
 *   <label class="switch-wrap"><ui-switch [(checked)]="aiSwitch" /> Use AI to pre-fill</label>
 *
 * Replaces `ui-toggle` (deleted — see lib/toggle history
 * via `git log --follow` if you need the old 40x22 geometry).
 */
declare class UiSwitch implements ControlValueAccessor {
    checked: _angular_core.ModelSignal<boolean>;
    disabled: _angular_core.InputSignal<boolean>;
    name: _angular_core.InputSignal<string>;
    ariaLabel: _angular_core.InputSignal<string>;
    /** DLS Size axis — `small` (28×18, default) or `medium` (40×24). */
    size: _angular_core.InputSignal<UiSwitchSize>;
    protected cvaDisabled: _angular_core.WritableSignal<boolean>;
    protected isDisabled: _angular_core.Signal<boolean>;
    private onChange;
    protected onTouched: () => void;
    protected toggle(): void;
    writeValue(value: boolean): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiSwitch, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiSwitch, "ui-switch", never, { "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; }, never, never, true, never>;
}

/**
 * DLS "Currency" input-field type (REGISTER.md §21/§24, Figma
 * 76086:347728; leading segment 414:2914) — aligned onto the DLS chrome in
 * the archive round §21–§24 (owner decision, 3 Sep 2026). Same shared field
 * shell as `ui-phone-input`/`ui-number-input`/`ui-search-input`: 32px, bg
 * level_1, 1px border, radius 4. A leading `ui-code-segment` (currency code
 * + chevron, opening a listbox of `currencies` — the same segment
 * `ui-phone-input`'s dial code uses) + a 1px full-height divider + the
 * amount field (flex 1, left-aligned per the DLS "0.00" placeholder,
 * tabular-nums).
 *
 *   <ui-amount-input [(currency)]="ccy" [(amount)]="amt" />
 *
 * Numeric handling unchanged from the Phase-1 control: `inputmode="decimal"`,
 * stripping any character that isn't a digit or a decimal point on input.
 * The field DISPLAYS the value grouped with thousands separators
 * (1,000,000) as the user types, while the `amount` model stays a raw
 * digit string so host validation/submission are unaffected. Caret snaps
 * to the end on reformat — acceptable for this control.
 *
 * `invalid` + `errorMessage` — the canonical error-state contract (see
 * `ui-text-input`): paints the shell `--color-field-error-bg` /
 * `--color-danger` border and renders the message in a `.ui-field-error`
 * span beneath. NEW this round — the Phase-1 control had neither.
 *
 * No hidden mirrored native `<select>`: no e2e spec drives this control's
 * currency via `selectOption` (grepped an e2e spec for `ui-amount-input` —
 * the only hit is a comment noting an OLD regression test was retired), so
 * the DLS listbox segment replaces the native `<select>` outright rather
 * than keeping a parallel hidden one.
 *
 * RESKIN: delegate to the DLS Currency input Angular component; keep
 * selector + inputs unchanged.
 */
declare class UiAmountInput implements OnInit {
    currency: _angular_core.ModelSignal<string | null>;
    amount: _angular_core.ModelSignal<string>;
    currencies: _angular_core.InputSignal<string[]>;
    placeholder: _angular_core.InputSignal<string>;
    disabled: _angular_core.InputSignal<boolean>;
    invalid: _angular_core.InputSignal<boolean>;
    errorMessage: _angular_core.InputSignal<string>;
    /** Grouped presentation of the raw `amount` model — what the field shows. */
    protected readonly display: _angular_core.Signal<string>;
    ngOnInit(): void;
    protected onAmount(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiAmountInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiAmountInput, "ui-amount-input", never, { "currency": { "alias": "currency"; "required": false; "isSignal": true; }; "amount": { "alias": "amount"; "required": false; "isSignal": true; }; "currencies": { "alias": "currencies"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; }, { "currency": "currencyChange"; "amount": "amountChange"; }, never, never, true, never>;
}

/**
 * Shared leading "code" segment (Figma 414:2914) — the compact code+chevron
 * trigger DLS reuses verbatim between the Phone field (76086:347688) and the
 * Currency field (76086:347728): 12px h-pad, 8 gap, kit `body(sm)` 13
 * `--color-text-strong` tabular-nums value + a 16px chevron-down_16. A real
 * click opens a `ui-dropdown-menu` listbox of `button[ui-dropdown-item]`
 * rows (register §16) — the same open-signal + `document:click` pattern
 * `ui-kebab-menu` uses, not a native `<select>`, so it can draw the DLS
 * popover chrome.
 *
 *   <ui-code-segment [options]="['+65','+60','+62']" [(value)]="dialCode" />
 *   <ui-code-segment [options]="currencies()" [(value)]="currency" [disabled]="disabled()" />
 *
 * Extracted here (REGISTER.md §21/§23, audited 3 Sep 2026,
 * round §21–§24) rather than duplicated in `ui-phone-input` and
 * `ui-amount-input` — both fields draw the identical segment, so one
 * implementation is the single source of the popover behaviour.
 *
 * RESKIN: delegate to the DLS Phone/Currency field's own segment; keep
 * selector + inputs unchanged.
 */
declare class UiCodeSegment {
    options: _angular_core.InputSignal<string[]>;
    value: _angular_core.ModelSignal<string | null>;
    disabled: _angular_core.InputSignal<boolean>;
    protected open: _angular_core.WritableSignal<boolean>;
    private host;
    protected toggle(event: Event): void;
    protected pick(opt: string): void;
    protected onDocumentClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiCodeSegment, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiCodeSegment, "ui-code-segment", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

/**
 * DLS "Phone" input-field type (REGISTER.md §21, Figma
 * 76086:347688; leading segment 414:2914) — built for the archive round
 * §21–§24 (owner decision, 3 Sep 2026). Same shared field shell as
 * `ui-number-input`/`ui-amount-input`/`ui-search-input`: 32px, bg level_1,
 * 1px border, radius 4, 12px h-pad. A leading `ui-code-segment` (dial code
 * + chevron, opening a listbox of `dialCodes`) + a 1px full-height divider
 * + the number field (flex 1, `inputmode="tel"`, tabular-nums).
 *
 *   <ui-phone-input [(dialCode)]="code" [(number)]="phone" />
 *   <ui-phone-input [(dialCode)]="code" [(number)]="phone" [dialCodes]="['+65','+60']" />
 *
 * Twin `model()`s rather than one CVA value — same shape as
 * `ui-amount-input`'s `currency`/`amount` pair, which this control mirrors
 * (it reuses the same leading segment, `ui-code-segment`, that the
 * Currency type now also uses).
 *
 * `invalid` + `errorMessage` — the canonical error-state contract (see
 * `ui-text-input`): paints the shell `--color-field-error-bg` /
 * `--color-danger` border and renders the message in a `.ui-field-error`
 * span beneath.
 *
 * RESKIN: delegate to the DLS Phone input Angular component; keep selector
 * + inputs unchanged.
 */
declare class UiPhoneInput implements OnInit {
    dialCode: _angular_core.ModelSignal<string | null>;
    number: _angular_core.ModelSignal<string>;
    dialCodes: _angular_core.InputSignal<string[]>;
    placeholder: _angular_core.InputSignal<string>;
    disabled: _angular_core.InputSignal<boolean>;
    invalid: _angular_core.InputSignal<boolean>;
    errorMessage: _angular_core.InputSignal<string>;
    ngOnInit(): void;
    protected onNumber(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiPhoneInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiPhoneInput, "ui-phone-input", never, { "dialCode": { "alias": "dialCode"; "required": false; "isSignal": true; }; "number": { "alias": "number"; "required": false; "isSignal": true; }; "dialCodes": { "alias": "dialCodes"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; }, { "dialCode": "dialCodeChange"; "number": "numberChange"; }, never, never, true, never>;
}

/**
 * DLS "Number with stepper" input-field type (REGISTER.md §21,
 * Figma 76086:347895 / 347901 / 136462:184297) — built for the archive
 * round §21–§24 (owner decision, 3 Sep 2026). Same shared field shell as
 * `ui-phone-input`/`ui-amount-input`/`ui-search-input`: 32px, bg level_1,
 * 1px border, radius 4. A numeric native input (right-aligned, tabular
 * nums) + a 1px full-height divider + a "Stepper Set" (12px h-pad, 8 gap):
 * a 32px `ui-icon-button` minus, a 16px-tall divider, a 32px `ui-icon-button`
 * plus (register §8).
 *
 *   <ui-number-input [(value)]="qty" [step]="0.01" [min]="0" placeholder="0.00" />
 *
 * CVA, same pattern as `ui-text-input`: works with plain two-way binding
 * or reactive forms. `value` is `number | null` — `null` shows the
 * placeholder, distinct from `0`.
 *
 * Clicking a stepper button, or ArrowUp/ArrowDown in the field, steps the
 * value by `step` (default 1) and clamps to `min`/`max` when set;
 * `disabled` disables both the field and the stepper buttons.
 *
 * `invalid` + `errorMessage` — the canonical error-state contract (see
 * `ui-text-input`).
 *
 * RESKIN: delegate to the DLS Number-with-stepper Angular component; keep
 * selector + inputs unchanged.
 */
declare class UiNumberInput implements ControlValueAccessor {
    value: _angular_core.ModelSignal<number | null>;
    step: _angular_core.InputSignal<number>;
    min: _angular_core.InputSignal<number | undefined>;
    max: _angular_core.InputSignal<number | undefined>;
    placeholder: _angular_core.InputSignal<string>;
    disabled: _angular_core.InputSignal<boolean>;
    invalid: _angular_core.InputSignal<boolean>;
    errorMessage: _angular_core.InputSignal<string>;
    protected cvaDisabled: _angular_core.WritableSignal<boolean>;
    protected isDisabled: _angular_core.Signal<boolean>;
    protected display: _angular_core.Signal<string>;
    private onChange;
    protected onTouched: () => void;
    protected onInput(event: Event): void;
    protected onKeydown(event: KeyboardEvent): void;
    protected stepBy(direction: 1 | -1): void;
    /** Rounds to the same decimal precision as `step` (e.g. step 0.01 → 2dp)
     *  so repeated floating-point addition never drifts (0.1 + 0.2 traps). */
    private round;
    writeValue(value: number | null): void;
    registerOnChange(fn: (value: number | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNumberInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiNumberInput, "ui-number-input", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

type UiInfoBannerTone = 'info' | 'warning' | 'success' | 'error';
/**
 * Information banner — the DLS 3.1 `info-banner` component (page
 * 305:2707, set 12044:100307, REGISTER.md §20, audited
 * 2 Sep 2026). Grown additively from the Phase-1 single-tone banner: a
 * full-width elevated card with a 4px accent bar down its left edge, a
 * 24px FILLED status icon, optional title, an optional actions row and an
 * optional dismiss — now four tones instead of one.
 *
 *   <ui-info-banner message="Filling out the Special Request Details section
 * is enough to save this form for later.
 * To submit to the desk head, all sections must be completed." />
 *
 *   <ui-info-banner tone="warning" title="Review before submitting"
 *     message="3 fields could not be validated automatically.">
 *     <button ui-info-banner-actions ui-button variant="secondary" size="tiny">Review</button>
 *     <button ui-info-banner-actions ui-button variant="plain" size="tiny">Dismiss</button>
 *   </ui-info-banner>
 *
 * `message` is a plain string; lines separated by `\n` render as separate
 * paragraphs (kept as a string so the common case stays bind/interpolate-able,
 * matching how the Figma copy ships as two literal lines).
 *
 * Omit `message` to project arbitrary markup into the same slot instead:
 *
 *   <ui-info-banner [dismissible]="false">
 *     <p class="title">Portfolio Opted Out</p>
 *     <ol>…</ol>
 *   </ui-info-banner>
 *
 * Projected default-slot nodes are styled by the HOST's own stylesheet,
 * not this one (same precedent as before this round).
 *
 * **`tone`** — `info` (default, keeps the 3 existing callers byte-
 * identical) | `warning` | `success` | `error`. Drives the left bar, the
 * status icon and its fill: info `--color-info-bar` #8657ff
 * (circle-information-filled), warning `--color-warning-strong` #eb9600
 * (triangle-exclamation-filled), success `--color-success-strong`
 * #00ab61 (circle-check-filled), error `--color-danger` #ff4724
 * (triangle-exclamation-filled — the same glyph as warning, DLS reuses
 * it for both, only the fill differs). The warning/error triangle is the
 * exact path `ui-alert` already draws (alert.ts) — one hand-authored
 * evenodd path, not redrawn here.
 *
 * **`title`** — optional. `type.heading(2xs)` — 14px/600/1.4,
 * `--color-text-strong` — the platform's compactness-override title size
 * (DLS's own node reads heading/2xs at 16px; every other kit title
 * already stands on the 14px override — see `ui-alert`, `ui-card`), 4px
 * above the description.
 *
 * **`[ui-info-banner-actions]`** — a projected actions row below the
 * title/message block, 8px gap between items, 8px of space above the row
 * itself (register §20: "optional actions row 8px below"). Rendered as
 * an always-present
 * flex row rather than gated behind a content-query round trip — an
 * empty row costs nothing (`:empty { display: none }` collapses it to
 * zero height and no gap contribution in info-banner.scss, the same
 * "always render, let CSS no-op it" precedent `ui-alert`'s `.actions`
 * div documents).
 *
 * Dismissal is component-owned: clicking the dismiss button hides the
 * banner (no `hidden`/`visible` input to manage from the host) and emits
 * `closed` so a host that wants to react (e.g. clear related form state)
 * still can. The dismiss control is now a real `ui-icon-button` (`size=
 * "tiny"`, a 24×24 box with a 16px glyph) instead of the old hand-rolled
 * close button — same close glyph, now sized and coloured by the kit
 * icon-button component rather than a local `.close` rule. The `.close`
 * CLASS name is kept as an additional static class on that button (not a
 * new API surface) so f6d's existing `.close` locator — asserting the
 * dismiss control is ABSENT when `dismissible=false` — keeps working
 * unchanged.
 *
 * This closes §2 Alert's "tones deferred to item 20" note: `ui-alert`
 * stays danger-only by design, and the info/warning/success tone axis
 * DLS puts on the same Figma set as its danger cell lives here instead.
 *
 * RESKIN: delegate to the DLS Angular alert/banner component if one
 * exists; keep the selector and every input (`message`, `dismissible`,
 * `tone`, `title`) unchanged.
 */
declare class UiInfoBanner {
    /** Optional — when empty/absent, projected content fills the slot instead. */
    message: _angular_core.InputSignal<string>;
    dismissible: _angular_core.InputSignal<boolean>;
    /** DLS's Type axis, renamed `tone` — see the class doc. Default `info` keeps the 3 existing callers byte-identical. */
    tone: _angular_core.InputSignal<UiInfoBannerTone>;
    /** Optional title above the message, `type.heading(2xs)` — 14px/600. */
    title: _angular_core.InputSignal<string | undefined>;
    closed: _angular_core.OutputEmitterRef<void>;
    protected dismissed: _angular_core.WritableSignal<boolean>;
    protected hasMessage: _angular_core.Signal<boolean>;
    protected lines: _angular_core.Signal<string[]>;
    protected bannerClass: _angular_core.Signal<string>;
    protected dismiss(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiInfoBanner, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiInfoBanner, "ui-info-banner", never, { "message": { "alias": "message"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, never, ["*", "[ui-info-banner-actions]"], true, never>;
}

type UiFileThumbnailType = 'image' | 'pdf' | 'document' | 'preview';
/**
 * File thumbnail — DLS 3.1 `_file-thumbnail` (Figma 18095:160474,
 * REGISTER.md §45/§46, built 4 Sep 2026). A 40×40 tile,
 * radius `--border-radius-indicator` (4), background `--color-bg-alt`,
 * `overflow: hidden`, that draws one of three 24px file-type glyphs
 * (Image | PDF | Document) centred in `--color-icon` — OR, `type="preview"`,
 * fills the tile with the file's own image (`src`, `object-fit: cover`)
 * and washes it with a translucent brand overlay on hover/press.
 *
 *   <ui-file-thumbnail type="pdf" />
 *   <ui-file-thumbnail type="preview" src="data:image/…" />
 *
 * Composed by BOTH halves of this DLS pair, not implemented twice:
 * `ui-upload-file`'s Left content slot (§45's `upload-file` row) and
 * `ui-file-row`'s optional leading thumbnail (§46's `File`, Simple type,
 * `[thumbnail]="true"`).
 *
 * **Glyphs** — hand-drawn 24-viewBox outlines (this kit carries no DLS/DBS
 * icon font), `currentColor` on `--color-icon`. The pdf/image/document
 * trio is drawn to match `ui-file-row`'s PRE-EXISTING inline thumb glyphs
 * exactly (file-row.ts's `kind` switch) — same shapes, same kit, one
 * visual language for "this is a PDF" wherever it appears. `document` is
 * also the default `type`, DLS's generic-file fallback.
 *
 * **Preview overlay** — DLS specs a 30%-opacity INDIGO wash on Hover, a
 * stronger one on Pressed. This kit's white-label seam has no indigo step
 * at all (DLS's indigo here is a brand accent, not part of the
 * neutral/primary ladder), and tokens.css carries exactly ONE translucent
 * brand-tinted token: `--color-primary-halo`, rgba(0,119,204,0.2) — 20%,
 * not 30% (GAP, reported in the round's report). Hover uses it once, at
 * face value. Pressed does NOT invent a second, darker token — it stacks
 * a SECOND identical `--color-primary-halo` layer (the overlay's own
 * background plus an inset box-shadow of the same token) on top of the
 * first, so two 20% layers of the same hue compose to a visibly stronger
 * wash without a new token or a raw hex.
 *
 * RESKIN: delegate to the DLS Angular `_file-thumbnail`; keep selector,
 * `type` and `src` unchanged.
 */
declare class UiFileThumbnail {
    /** DLS's Type axis. Defaults to `document`, DLS's generic-file glyph. */
    type: _angular_core.InputSignal<UiFileThumbnailType>;
    /** Required (and only read) when `type="preview"` — the image URL or
     *  data URI to fill the tile with. */
    src: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiFileThumbnail, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiFileThumbnail, "ui-file-thumbnail", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "src": { "alias": "src"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** File-type families the thumbnail glyph switches on (derived from the name). */
type UiFileKind = 'pdf' | 'image' | 'doc';
/**
 * Uploaded-file row — DLS 3.1 `File` (Figma 135552:1133, Simple type, 43
 * tall, REGISTER.md §46, grown 4 Sep 2026): 40x40 file-type
 * thumbnail, file name + optional size, and a right-aligned download /
 * remove action pair.
 *
 *   <ui-file-row name="price-quotation.pdf" size="3.2 MB"
 *                (download)="save(f)" (remove)="drop(f)" />
 *   <ui-file-row thumbnail fileType="pdf" name="Passport.pdf" href="#"
 *                size="3.2 MB" (open)="preview(f)" (download)="save(f)" (remove)="drop(f)" />
 *
 * The row fills the width of its container; the title wraps rather than
 * truncating, so long file names stay fully readable. Omit `size` (or pass
 * an empty string) and the subtitle line is not rendered at all.
 *
 * Each action is independently switchable — `[downloadable]="false"` for a
 * file still uploading, `[removable]="false"` for a read-only attachment
 * list. Download always renders before remove.
 *
 * **The default thumbnail** (no `thumbnail` input) is UNCHANGED from
 * before this round: a bare inline glyph chosen from the extension on
 * `name` (pdf / image / generic document) — deliberately not an input, so
 * a host can never label a `.pdf` with an image glyph. This is the exact
 * markup the three pre-existing callers (new-request-modal, request-detail,
 * large-order-sections) already render; none of them pass `thumbnail`, so
 * none of them see any visual change.
 *
 * **`thumbnail` + `fileType`** (additive, DLS's optional §46 thumbnail
 * slot) swap that inline glyph for a real `ui-file-thumbnail` (§45) —
 * composed, not reimplemented, per the gap register's own proposal. Pass
 * `thumbnailSrc` alongside `fileType="preview"` to fill it with an image.
 *
 * **`href` + `open`** (additive, DLS's Simple-type LINK first line) — when
 * `href` is non-empty, the name renders through `a[ui-link]` (1px
 * underline, `--color-text`) instead of plain text. `open` alone does NOT
 * flip this — `output()` exposes no reliable "has a listener" check in
 * this kit (see `ui-table-header`'s own note on the same limitation), so
 * `href` is the one observable signal a link is wanted. A click ALWAYS
 * prevents the browser's own navigation and emits `open` instead — see
 * `onOpenClick`'s doc for why (this app's mock data has no real file
 * server, and this repo's `<base href="/">` makes even `href="#"`
 * resolve to the site root, not the current route). The three
 * pre-existing callers never pass `href`, so they keep the plain-text
 * name unchanged.
 *
 * RESKIN: delegate to the DLS file/attachment list item; keep selector,
 * inputs and outputs unchanged.
 */
declare class UiFileRow {
    name: _angular_core.InputSignal<string>;
    /** Optional — when empty/absent the subtitle line is not rendered. */
    size: _angular_core.InputSignal<string>;
    downloadable: _angular_core.InputSignal<boolean>;
    removable: _angular_core.InputSignal<boolean>;
    /** Additive (§46) — renders a leading `ui-file-thumbnail` instead of the
     *  bare inline glyph below. Default false keeps the three pre-existing
     *  callers' markup untouched. */
    thumbnail: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Passed straight through to the composed `ui-file-thumbnail` when
     *  `thumbnail` is true. Ignored otherwise. */
    fileType: _angular_core.InputSignal<UiFileThumbnailType>;
    /** `ui-file-thumbnail`'s `src`, for `fileType="preview"`. Ignored unless
     *  both `thumbnail` and `fileType="preview"` are set. */
    thumbnailSrc: _angular_core.InputSignal<string>;
    /** Additive (§46) — non-empty makes the name an `a[ui-link]` instead of
     *  plain text. `open` alone does not trigger this (see class doc). */
    href: _angular_core.InputSignal<string>;
    download: _angular_core.OutputEmitterRef<void>;
    remove: _angular_core.OutputEmitterRef<void>;
    /** Additive (§46) — fires on a click of the linked name. The click's
     *  default is ALWAYS prevented first — see `onOpenClick` below. */
    open: _angular_core.OutputEmitterRef<void>;
    protected hasSize: _angular_core.Signal<boolean>;
    protected hasLink: _angular_core.Signal<boolean>;
    /**
     * `href` never actually navigates the browser — this app is entirely
     * mock data with no real file server behind it (same footing as
     * `ui-file-drop`'s "THE UPLOAD IS MOCK" doc), and this repo's
     * `<base href="/">` (index.html) makes even a same-page fragment like
     * `href="#"` resolve to the SITE ROOT, not the current route — a real
     * click would silently bounce the whole app to `/home`. `href` is kept
     * as a real attribute purely for the anchor's presentational/
     * accessibility value (hover status-bar preview, right-click "copy link
     * address", the `<a>` semantics screen readers announce) while `open`
     * is the one real signal a caller acts on.
     */
    protected onOpenClick(event: MouseEvent): void;
    /** Thumbnail glyph family, parsed off the file extension in `name`. */
    protected kind: _angular_core.Signal<UiFileKind>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiFileRow, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiFileRow, "ui-file-row", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "downloadable": { "alias": "downloadable"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; "thumbnail": { "alias": "thumbnail"; "required": false; "isSignal": true; }; "fileType": { "alias": "fileType"; "required": false; "isSignal": true; }; "thumbnailSrc": { "alias": "thumbnailSrc"; "required": false; "isSignal": true; }; "href": { "alias": "href"; "required": false; "isSignal": true; }; }, { "download": "download"; "remove": "remove"; "open": "open"; }, never, never, true, never>;
}

type UiFileDropAlignment = 'center' | 'left';
/**
 * Drag-and-drop upload zone — DLS 3.1 `upload-area` (Figma 1183:2303,
 * REGISTER.md §45, grown 4 Sep 2026): dashed rounded
 * rectangle with a cloud-upload glyph, "Drag your file here or browse"
 * (browse styled as a link) and a supported-formats hint line underneath.
 *
 *   <ui-file-drop (browse)="attach()" />
 *   <ui-file-drop hint="Supports PDF (up to 5MB)" (browse)="attach()" />
 *   <ui-file-drop alignment="left" (browse)="attach()" />
 *   <ui-file-drop [invalid]="true" errorMessage="File must be under 10MB." (browse)="attach()" />
 *
 * THE UPLOAD IS MOCK — there is no real file picker or drag-payload
 * parsing. Clicking anywhere in the zone (including the "browse" word),
 * pressing Enter/Space while it has focus, or dropping a file onto it all
 * do the exact same thing: emit `browse` once. The host is responsible for
 * appending a mock attachment in response.
 *
 * The whole zone is a single keyboard-operable control (role="button",
 * tabindex 0) — "browse" is styled text inside it, not a nested interactive
 * element, so focus/activation stays on one control.
 *
 * **Anatomy** (DLS 1183:2303): 1px DASHED `--color-border` (`--color-danger`
 * when `invalid` — see below), radius `--border-radius-panel-lg` (8, via
 * the existing `--radius-md` alias), background `--color-bg-level1`, 12px
 * padding on every side. `alignment` (DLS's Alignment axis) switches the
 * inner layout: `center` (default) stacks the glyph above an 8px-gapped
 * copy block; `left` runs the glyph beside a 12px-gapped copy block. Either
 * way the copy block itself keeps its own internal 4px gap between the
 * "Drag your file here or browse" line and the hint line.
 *
 * **Hover vs. drag-over** — two DISTINCT treatments, not the same rule
 * reused: Hover only darkens the border a step (`--color-border-hover`);
 * an active drag-over additionally tints the whole zone
 * (`--color-primary` border + `--color-info-bg` fill), so a file dragged
 * over the zone reads more insistently than a plain mouse hover. Declared
 * in that order in file-drop.scss so a drag (which is also a hover) wins.
 *
 * **`invalid`** (DLS's Error state) swaps the border to `--color-danger`
 * — tokens.css carries no dedicated `--color-border-danger` role, but
 * `--color-danger` (#ff4724) is the EXACT hex DLS's own border-danger
 * uses, so this is a real match, not a nearest-fallback GAP — and, when
 * `errorMessage` is non-empty, renders it in `body(sm)` /
 * `--color-text-danger` beneath the zone (the same role/token
 * `ui-form-field`'s own error row uses, form-field.scss).
 *
 * RESKIN: delegate to the DLS file-upload/dropzone component if one
 * exists; keep selector, `hint`/`alignment`/`invalid`/`errorMessage`
 * inputs and the `browse` output unchanged.
 */
declare class UiFileDrop {
    /** Second line of copy — defaults to the standard supported-formats hint. */
    hint: _angular_core.InputSignal<string>;
    /** DLS's Alignment axis — `center` (default, glyph above copy) | `left`
     *  (glyph beside copy). */
    alignment: _angular_core.InputSignal<UiFileDropAlignment>;
    /** DLS's Error state — swaps the border to the danger token. */
    invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Shown under the zone, danger text, only while `invalid` is true. */
    errorMessage: _angular_core.InputSignal<string>;
    /** Emitted on click (zone or "browse"), Enter/Space, or drop — always the
     *  same signal, never a payload; there is nothing real to hand back. */
    browse: _angular_core.OutputEmitterRef<void>;
    protected readonly dragging: _angular_core.WritableSignal<boolean>;
    protected readonly ariaLabel: _angular_core.Signal<string>;
    protected emitBrowse(): void;
    protected onKeydown(event: KeyboardEvent): void;
    protected onDragOver(event: DragEvent): void;
    protected onDragLeave(event: DragEvent): void;
    protected onDrop(event: DragEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiFileDrop, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiFileDrop, "ui-file-drop", never, { "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "alignment": { "alias": "alignment"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; }, { "browse": "browse"; }, never, never, true, never>;
}

/**
 * Collapsible secondary-nav CHROME (Figma 993:7046) — the absolutely
 * positioned panel frame, its expanded/collapsed widths
 * (`--nav-secondary-w` / `--nav-secondary-w-collapsed`, tokens.css), and the
 * footer collapse/expand control. This is the shared part of the three
 * nav-panel shells (My Profile, Team Management → System Access, Murex
 * Trade Monitoring) — see each shell's own header comment for why the item
 * lists themselves stay copies rather than a shared component.
 *
 *   <ui-nav-panel [(expanded)]="navExpanded">
 *     <div class="nav-panel-title"><h2 ui-page-title>My profile</h2></div>
 *     <div class="nav-panel-items"> …the shell's own routerLink items… </div>
 *   </ui-nav-panel>
 *
 * `expanded` is a `model()` so a shell CAN mirror it (e.g. to shift its
 * content region — see profile.scss `.content-collapsed`), but nothing
 * requires binding it: it defaults to `true`, and since every consuming
 * shell is destroyed on module exit, a fresh instance (fresh default) is
 * exactly the "always expanded on landing, no persistence" behaviour asked
 * for — with zero extra state management.
 *
 * Collapsed state hides the projected title/items entirely (Figma: a bare
 * ~40px rail with a single centred `»` control, no labels) — only the
 * expand control renders. Three spec files assert those projected nodes have
 * count 0 when collapsed (f13-profile, f14-system-access,
 * f15-monitoring-split), so the `@if` around the BODY is contractual: do not
 * "fix" the collapse by mounting-and-hiding it without changing those specs.
 *
 * THE TOGGLE ITSELF IS NOT INSIDE THAT `@if`. It used to be — one button in
 * the `@if` branch and a second in the `@else` — which meant every click
 * DESTROYED the element that was clicked. Measured consequences: keyboard
 * focus dropped to `<body>` (so tabbing after a collapse restarted from the
 * top of the document), and the control jumped 421.5px vertically at frame 0
 * because the two branches sit in different places. One persistent button
 * that swaps its label, `aria-label`, classes and chevron rotation off
 * `expanded()` fixes both, and lets the chevron animate between states
 * instead of being two hardcoded path pairs.
 *
 * The 421.5px jump ITSELF is deliberate and remains: expanded, the control is
 * a footer row (`« Collapse view`); collapsed, it is a centred rail control —
 * those are two different designed end-states (the kit's internal notes), not a
 * bug. Animating the travel between them WAS tried (transition `flex-grow` on
 * `.nav-panel-footer` 1 -> 0, which — measured — lands the collapsed centred
 * glyph within 0.5px of the expanded control's frame-0 position at ANY panel
 * height, so it is structurally available). It was rejected for now because it
 * forces the item list's own height to animate 421px -> 842px as a side
 * effect: the body then overflows for the first ~55ms of every expand
 * (scrollHeight 520 vs height 421), which flickers a scrollbar in and out on
 * any platform with classic non-overlay scrollbars — i.e. the Windows
 * deployment target. Moving the collapsed control is the product owner's call,
 * not this component's; leave the end-states alone until asked.
 *
 * ACCESSIBLE NAMES ARE A CONTRACT: 'Collapse view' / 'Expand view' are what
 * the specs match on with `getByRole('button', { name })`. The expanded state
 * carries `aria-label` as well as the visible label so the name is stated in
 * one place for both states rather than coming from text in one and a label
 * in the other.
 *
 * A shell needing TWO LEVELS projects `ui-nav-group` (nav-group.ts) and
 * `[ui-nav-sub-item]` (nav-sub-item.ts) into the same slot instead of a
 * flat item list — Figma 155:3121. Those are additive: this component is
 * unchanged by them, and the flat shells stay flat.
 *
 * A shell wanting the full DLS `nav-side-secondary` header/footer anatomy
 * (§29) projects `ui-nav-panel-header` (nav-panel-header.ts) as the first
 * child of the default slot, and `[ui-nav-footer-item]` rows
 * (nav-footer-item.ts) wrapped in a `[uiNavPanelFooter]` element:
 *
 *   <ui-nav-panel [(expanded)]="navExpanded">
 *     <ui-nav-panel-header title="System Access" />
 *     <div class="nav-panel-items">…</div>
 *     <div uiNavPanelFooter>
 *       <button ui-nav-footer-item label="Print"><svg uiNavFooterIcon>…</svg></button>
 *     </div>
 *   </ui-nav-panel>
 *
 * The footer slot renders ABOVE this component's own "Collapse view"
 * toggle, restyled this round to the identical 12px-padding / 8px-gap
 * geometry so the two read as one list — see nav-footer-item.ts for why
 * the toggle itself stays a distinct persistent element rather than
 * becoming a fourth `[ui-nav-footer-item]` instance. Collapsed, the footer
 * slot is unmounted (same `@if` shape as the body) and only the toggle's
 * bare 24px chevron strip remains, per DLS's 40px-wide collapsed rail.
 *
 * RESKIN: composed the reference app chrome, not a single DLS component — verify
 * whether the DLS library ships a collapsible side-nav before wrapping;
 * see the kit's internal notes
 */
declare class UiNavPanel {
    expanded: _angular_core.ModelSignal<boolean>;
    /** Target of the toggle's `aria-controls`; see the header comment. */
    protected readonly bodyId: string;
    protected toggle(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavPanel, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiNavPanel, "ui-nav-panel", never, { "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; }, { "expanded": "expandedChange"; }, never, ["*", "[uiNavPanelFooter]"], true, never>;
}

/** DLS Form-type status per item/sub-item (REGISTER.md §29). */
type UiNavStatus = 'completed' | 'error' | undefined;
/**
 * Expandable GROUP row inside a `ui-nav-panel` (Figma 155:3121,
 * `nav-side-secondary/item` in its expandable state). 40px tall: a filled
 * disclosure triangle at 12px (16x16, pointing right when collapsed and
 * down when expanded), then the label at 36px. Whatever the shell projects
 * renders below it as the design's `dropdown` block — in practice a run of
 * `[ui-nav-sub-item]` rows.
 *
 * The projected content is ALWAYS in the DOM, open or shut; the disclosure is
 * a 120ms grid-track transition and `inert`, not a structural if. See the
 * template comment for why, and nav-group.scss for the timing rationale — a
 * spec that counts rows across the whole panel therefore counts every group's,
 * not just the open ones.
 *
 *   <ui-nav-group label="Section" [(expanded)]="sectionOpen">
 *     <a ui-nav-sub-item label="All items" [active]="true" [routerLink]="…"></a>
 *   </ui-nav-group>
 *
 * GROUPS ARE INDEPENDENT BY CONSTRUCTION. Each instance owns its own
 * `expanded` signal, so opening one cannot close another — there is no
 * shared open-set to get the accordion semantics wrong (contrast the
 * primary nav rail, which has one component rendering every group and so
 * had to model the same requirement explicitly as a Set). A shell that
 * wants to drive or observe the state binds `[(expanded)]`; one that
 * doesn't binds nothing and gets a self-contained disclosure.
 *
 * `defaultExpanded` seeds the initial state for the common case — a shell
 * that wants the group holding the active route open on landing but does
 * not otherwise care to hold the signal itself.
 *
 * The group row is a real `<button>`, not a link: it toggles, it never
 * navigates. A group that should ALSO navigate is not this component.
 *
 * `status` (DLS "Type Form", §29) adds a trailing 16px status icon after the
 * label — a hand-authored `check` in `--color-success-strong` for
 * `'completed'`, a hand-authored `triangle-exclamation-filled` in
 * `--color-text-danger` for `'error'` (tokens.css has no separate
 * `--color-danger-strong`; this is the same #d62300 value under its
 * text/icon role — see tokens.css's own "same hex, different DLS role"
 * house rule). The wrapper renders whenever `status()` is set; project
 * `[uiNavStatus]` alongside it to swap in custom markup instead of the
 * built-in glyph (both can be present in the DOM — CSS does not hide
 * either one, so a caller doing this owns not setting `status` to a value
 * whose default icon it doesn't want alongside its own).
 *
 * RESKIN: composed the reference app chrome like `ui-nav-panel` itself, not a single
 * DLS component — verify whether the DLS library ships a collapsible
 * side-nav (with its own group/sub-item parts) before wrapping any of this
 * family; see the kit's internal notes
 */
declare class UiNavGroup {
    label: _angular_core.InputSignal<string>;
    /** Initial state only — read once, in `ngOnInit`. */
    defaultExpanded: _angular_core.InputSignal<boolean>;
    expanded: _angular_core.ModelSignal<boolean>;
    /** DLS Form-type trailing status icon — see the header comment. */
    status: _angular_core.InputSignal<UiNavStatus>;
    ngOnInit(): void;
    protected toggle(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiNavGroup, "ui-nav-group", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "defaultExpanded": { "alias": "defaultExpanded"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; }, { "expanded": "expandedChange"; }, never, ["[uiNavStatus]", "*"], true, never>;
}

/**
 * Child row of a `ui-nav-group` (Figma 155:3121 / 192450:1064,
 * `nav-side-secondary/sub-item`). 12px h / 8px v padding (32px tall): a
 * 16x16 sizer at 12px — an indent, deliberately NOT an icon slot — the
 * label at 36px, a trailing 16px slot at 212px holding an optional count
 * badge, and (Form type) a further trailing 16px status icon slot.
 *
 * APPLIED AS AN ATTRIBUTE, so the consuming shell picks the element and
 * keeps ownership of navigation:
 *
 *   <a ui-nav-sub-item label="All items" [routerLink]="…" [active]="…"></a>
 *   <button ui-nav-sub-item label="All items" (click)="…"></button>
 *   <span ui-nav-sub-item label="Later" [disabled]="true"></span>
 *
 * That is the whole reason there is no `(selected)` output and no `route`
 * input: routing is the shell's business, and the three existing nav-panel
 * shells each drive it differently. This component owns geometry, type and
 * state styling only.
 *
 * `active` is an INPUT rather than a `routerLinkActive` class, and that is
 * a real decision. A two-level nav has to know which group holds the active
 * route in order to open it, so the shell is already computing "which row
 * is active" in TypeScript; feeding that same answer in as an input keeps
 * one source of truth. Mixing the two would also pit a host class binding
 * against `routerLinkActive`'s imperative `addClass` for the same class.
 *
 * `disabled` renders a non-clickable roadmap entry — greyed text, no hover
 * wash, `not-allowed` cursor, `aria-disabled`. It styles only: put it on a
 * `<span>` (or a real `[disabled]` button) so there is nothing to click in
 * the first place. Rendering a disabled `<a routerLink>` still navigates.
 *
 * `status` (DLS "Type Form", §29) adds a trailing 16px status icon —
 * `completed` / `error` — see nav-group.ts's identical input for the full
 * rationale (same icons, same tokens). It is a separate slot from the
 * count `badge` above: a sub-item realistically carries a tally OR a
 * completion state, never both.
 *
 * RESKIN: part of the composed `ui-nav-panel` family — verify whether the
 * DLS library ships its own side-nav (with group/sub-item parts) before
 * wrapping any of it; see the kit's internal notes
 */
declare class UiNavSubItem {
    label: _angular_core.InputSignal<string>;
    /**
     * Trailing count. `null` (the default) renders no badge — note that `0`
     * therefore renders a badge reading "0", which is the honest behaviour:
     * "none" and "not counted" are different answers and only the consumer
     * knows which one it means.
     */
    count: _angular_core.InputSignal<string | number | null>;
    /** Selected row — the tinted background. Driven by the shell's routing. */
    active: _angular_core.InputSignal<boolean>;
    /** DLS Form-type trailing status icon (§29) — see the header comment. */
    status: _angular_core.InputSignal<UiNavStatus>;
    /** Visible but not selectable (a roadmap entry). Styling only — see the
     *  class comment: the element itself must not be clickable. */
    disabled: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavSubItem, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiNavSubItem, "[ui-nav-sub-item]", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "count": { "alias": "count"; "required": false; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, ["[uiNavStatus]"], true, never>;
}

/**
 * Header of a `ui-nav-panel` (Figma `nav-side-secondary-header`, 192450:1064
 * region) — REGISTER.md §29. Project it as the FIRST child of
 * `ui-nav-panel`'s default slot, ahead of the item list:
 *
 *   <ui-nav-panel [(expanded)]="navExpanded">
 *     <ui-nav-panel-header title="System Access" avatarName="Aiko Mori"
 *       previousPage="Team Management" (previous)="back()" />
 *     <div class="nav-panel-items">…</div>
 *   </ui-nav-panel>
 *
 * DLS geometry: 12px h / 16px v padding, bottom decorative rule, 16px
 * column gap between the optional "Previous page" row and the title row.
 * `previousPage` renders a tiny PLAIN `ui-button` (not a real back-nav —
 * the shell owns navigation, same division of labour as `[ui-nav-sub-item]`)
 * with a leading 16px chevron-left, emitting `previous` on click.
 * `avatarName` renders a 32px initials `ui-avatar` beside the title; when
 * absent the title group is just the title (DLS's "Form type centres the
 * title group without an avatar" — with no avatar box widening the row,
 * the flex row's own `align-items: center` already reads as centred).
 * Title types at the kit's heading/2xs, which is 14px in tokens.css — the
 * DLS-replica-compactness override that keeps every the reference app title at 14
 * rather than the 16 DLS's own heading/2xs prints (the kit's internal notes).
 *
 * This is additive: existing nav-panel shells (My Profile, System Access,
 * Trade Monitoring) keep hand-rolling their own `.nav-panel-title` div and
 * are unaffected — nothing requires migrating them this round.
 */
declare class UiNavPanelHeader {
    title: _angular_core.InputSignal<string>;
    /** 32px initials avatar beside the title. Absent = title-only row. */
    avatarName: _angular_core.InputSignal<string | undefined>;
    /** Tiny plain "Previous page" button label. Absent = no back row. */
    previousPage: _angular_core.InputSignal<string | undefined>;
    /** Emitted when the "Previous page" button is clicked — the shell owns
     *  the actual navigation, same division of labour as `[ui-nav-sub-item]`. */
    previous: _angular_core.OutputEmitterRef<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavPanelHeader, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiNavPanelHeader, "ui-nav-panel-header", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "avatarName": { "alias": "avatarName"; "required": false; "isSignal": true; }; "previousPage": { "alias": "previousPage"; "required": false; "isSignal": true; }; }, { "previous": "previous"; }, never, never, true, never>;
}

/**
 * Row inside a `ui-nav-panel`'s footer (Figma `nav-side-secondary/footer-item`,
 * 192450:1064 footer region) — REGISTER.md §29. Applied as an
 * attribute, same convention as `[ui-nav-sub-item]`, so the consuming shell
 * keeps ownership of the click/nav behaviour:
 *
 *   <div uiNavPanelFooter>
 *     <button ui-nav-footer-item label="Print" (click)="print()">
 *       <svg uiNavFooterIcon>…16px printer glyph…</svg>
 *     </button>
 *     <a ui-nav-footer-item label="Settings" [routerLink]="…" [selected]="onSettings()">
 *       <svg uiNavFooterIcon>…16px gear glyph…</svg>
 *     </a>
 *   </div>
 *
 * Project into `ui-nav-panel`'s `[uiNavPanelFooter]` slot, ABOVE the panel's
 * own built-in "Collapse view" control — the sink demo's Print / Settings /
 * Collapse view triad (REGISTER.md §29) is exactly this: two
 * `ui-nav-footer-item` rows plus the panel's own toggle, which stays a
 * distinct persistent element for the reasons `nav-panel.ts`'s header
 * comment documents (one control that survives the expand/collapse toggle,
 * never two elements swapped in and out) — restyled to the identical
 * 12px-padding / 8px-gap / 16px-icon geometry so the three rows read as
 * one list even though the last one is not literally this component.
 *
 * 12px padding all round, 8px gap, a 16px leading icon slot
 * (`[uiNavFooterIcon]`) and a label/sm 13/500 `--color-text-strong` — same
 * hover/selected wash as an item row (`--color-bg-hover` / selected
 * `--color-primary-subtle`).
 */
declare class UiNavFooterItem {
    label: _angular_core.InputSignal<string>;
    /** Tinted selected state — e.g. the settings page currently open. */
    selected: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavFooterItem, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiNavFooterItem, "[ui-nav-footer-item]", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, {}, never, ["[uiNavFooterIcon]"], true, never>;
}

/**
 * Badge — the DLS 3.1 `badge` component (page 379:18, set 379:23), six
 * symbols on ONE component set, two axes:
 *
 *   <ui-badge [label]="12" />
 *   <ui-badge label="99+" />
 *   <ui-badge [label]="12" emphasis="high" />
 *   <ui-badge type="dot" emphasis="high" />
 *   <ui-badge [label]="98" emphasis="subtle" tone="red" />
 *
 * **Type** — `label` (default; hugs content, "12" measures 21×16) or `dot`
 * (a bare 8×8 circle, `--size-base-5xs`, no content — the unread/status
 * marker). Label nodes: 5182:2 / 379:22 / 379:24. Dot nodes: 403:2617 /
 * 77321:354343 / 77321:354344. Code Connect maps the set to
 * `<dbs-badge [priority]="'low'|'medium'|'high'">12</dbs-badge>` (a `dot`
 * is the same element with no content).
 *
 * **Emphasis** — `low` (default) | `medium` | `high`, DLS's three fills,
 * identical for both types:
 * - `low` — `--color-tag-neutral` bg, `--color-text-body` text.
 * - `medium` — `--color-bg-inverse` bg, `--color-text-inverse` text.
 * - `high` — `--color-bg-danger-strong` bg, `--color-text-on-dim` text.
 *
 * COMPACTNESS OVERRIDE (owner ruling, 2 Sep 2026 — the second after the
 * accordion title): DLS types every Label at `label/xs` (12px). Low was
 * already shipping at `label/2xs` (10px) from an earlier the reference app-file harvest
 * and the owner kept it that way rather than growing it back to spec, and
 * ruled the new Medium in at 10px alongside it. High alone stays at DLS's
 * 12px. So the label sizes are Low 10 / Medium 10 / High 12 — deliberate,
 * not a DLS voice, do not "fix" Low or Medium back to 12px.
 *
 * `emphasis="subtle"` is a FOURTH value with no DLS counterpart — the reference app
 * extension carried over unchanged from the old `variant="subtle"` (Figma
 * 227:2860, the org-card risk-score / report-count pill): auto height,
 * tight ~2px/6px padding, no border, and a `tone`
 * (red/amber/green/light/dark) input that picks the tint. It rides the same
 * `emphasis` axis because it is still "how emphatic is this pill", not a
 * separate component. `subtle` has no DLS `type="dot"` counterpart either
 * — passing `type="dot"` with `emphasis="subtle"` is not a combination DLS
 * or the reference app defines, so the dot silently falls back to the `low` fill rather
 * than throwing (see `hostClass` below).
 *
 * The High emphasis keeps a 16px `min-width` so a single digit renders as a
 * true circle rather than a squashed pill — not on the DLS node (DLS's own
 * single digit hugs to ~15px, near-circular anyway), a reference-app extension
 * kept for the small visual difference it makes at the smallest count.
 *
 * A `high`-emphasis badge is not positioned here. It is an inline-flex chip
 * like any other, and OVERLAYING it on an icon is the consumer's layout
 * problem (see nav-rail.scss) — a kit component that positioned itself
 * absolutely could only ever fit one call site.
 *
 * NEITHER `ui-pill` NOR `ui-tag-info` could carry this, and both were
 * checked before adding a third small chip:
 *
 * - `ui-pill [dot]="false"` is the right SHAPE but the wrong everything
 *   else — no fixed height (2px padding either side of `label/xs` 12px, so
 *   ~18px and free to grow), a paler fill (`--color-border-subtle`), and a
 *   `color`/`dot` API built around STATUS. Making it fit would mean a
 *   fourth colour, a size input and a height it currently refuses to have.
 * - `ui-tag-info` is 20px at radius 4 on `--color-tag-new`. Its squared
 *   corner is the whole point of that component — the thing that reads as a
 *   recency marker rather than a status pill — so re-pointing it here would
 *   delete the distinction it exists to make.
 *
 * The question this answers is a third one again: "how many things are in
 * there?" (or, for `type="dot"`, "is there something here at all?"). No
 * state, no recency — a quantity (or a presence) beside a label. DLS names
 * it separately and so do we.
 *
 * RESKIN: `emphasis` maps 1:1 onto DLS's `dbs-badge` `priority` axis
 * (`low`/`medium`/`high`); `type="dot"` is `dbs-badge` with no content.
 * Wrap it keeping the `ui-badge` selector and the `label`/`type`/`emphasis`
 * inputs — `subtle` has no DLS counterpart and stays the reference app token-reskin
 * fallback it already is.
 */
declare class UiBadge {
    /**
     * Badge text. `number` is the common case and is accepted directly so a
     * consumer never has to stringify a count; `string` covers the truncated
     * forms ("99+") that are the consumer's decision, not this component's.
     * OPTIONAL — `type="dot"` renders no content at all, so a required input
     * would force every dot caller to pass a label nobody ever sees.
     */
    label: _angular_core.InputSignal<string | number | undefined>;
    /** DLS's `Type` axis — see the class comment. */
    type: _angular_core.InputSignal<"label" | "dot">;
    /** DLS's `Emphasis` axis, plus the reference app-only `subtle` — see the class comment. */
    emphasis: _angular_core.InputSignal<"low" | "medium" | "high" | "subtle">;
    /**
     * Tint for `emphasis="subtle"` only, ignored otherwise. Mirrors
     * `ui-status-tag`'s red/amber/green tag palette for the risk-band tones so
     * "red" reads the same wherever it appears on the platform; `light` and
     * `dark` are the two neutral count-pill pairings the org chart already
     * uses for an unselected/selected row.
     */
    tone: _angular_core.InputSignal<"light" | "dark" | "green" | "red" | "amber">;
    protected hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiBadge, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiBadge, "ui-badge", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "emphasis": { "alias": "emphasis"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type UiCurrencyPairSign = 'none' | 'positive' | 'negative';
type UiCurrencyPairSize = 'xl' | 'lg' | 'md' | 'sm' | 'xs';
/**
 * Currency pair — the DLS 3.1 `currency-pair` component (page 2062:0, set
 * `currency-pair` 2062:535, REGISTER.md §13, audited
 * 2 Sep 2026; the `md` size also appears at 94684:309653, `xs` at
 * 2099:8991). A right-aligned inline row — currency code + amount, an
 * optional sign glyph — for archive rows and summary tiles:
 *
 *   <ui-currency-pair currency="SGD" amount="14,000.00" />
 *   <ui-currency-pair currency="SGD" amount="14,000.00" sign="positive" size="xl" />
 *   <ui-currency-pair currency="SGD" amount="14,000.00" sign="negative" size="sm" />
 *   <ui-currency-pair masked size="md" />
 *
 * NOT for the blotter: the reference app runs currency as its own column there (a
 * standing rule — see `.ui-cell-currency` in `ui-tables.css`, deliberately
 * unused), so this component has no blotter call site. It exists for the
 * archive and for summary-tile contexts where currency and amount travel
 * together as one visual unit.
 *
 * `amount` is a plain string, pre-formatted by the caller ("14,000.00")
 * — this component does no number formatting, matching how `ui-badge`
 * takes its `label` pre-stringified for the truncated ("99+") case.
 *
 * **Sign.** `none` (default) | `positive` | `negative` — renders a "+" or
 * "-" glyph as its OWN span, styled identically to the amount (DLS's own
 * choice; not a plain hyphen-minus swapped for a true minus sign U+2212 —
 * the Figma node ships the ASCII hyphen). `masked` (boolean) renders
 * "••••••" in the amount's style with NO currency code and no sign glyph
 * at all — DLS's own masked-value pattern, used wherever a portfolio
 * amount must be hideable.
 *
 * **Size → kit type roles.** DLS pairs a currency-code role with an
 * amount role per size step. The CURRENCY code renders `body(md)` —
 * 14px/400 — at every size: DLS's own register text calls for "body-md
 * 16" at xl/lg and "body-sm 14" at md/sm/xs, but this kit's `body` role
 * only has two rungs (`sm` 13px, `md` 14px — `_type.scss`) and 14px is
 * the number every one of DLS's five cells resolves to once mapped onto
 * the nearer kit rung (16 has no kit equivalent and borrows down to 14;
 * 14 already lands on `body(md)` exactly) — so one mixin, `body(md)`,
 * correctly serves the whole size axis rather than swapping roles
 * per-size for a distinction the kit's two-rung scale can't actually
 * draw.
 *
 * The AMOUNT scales with `size`, and `xl`/`lg`/`md` need the avatar.scss
 * "borrow the size half" trick: the `heading` role's SIZE tokens, with
 * everything else — family, weight, line-height, letter-spacing — held
 * on `body`'s bold cell (`body-bold`, weight 600), since there is no
 * `heading` role at weight 600/leading 1.5 to reach for directly. `sm`/
 * `xs` need no borrowing — both land on a real `body(…, $bold: true)`
 * cell:
 *
 * | size | currency (kit)         | amount (kit)                                    |
 * |------|-------------------------|--------------------------------------------------|
 * | xl   | `body(md)` — 14px/400   | size `--font-size-heading-lg` (28px), borrowed, 600 |
 * | lg   | `body(md)` — 14px/400   | size `--font-size-heading-md` (24px), borrowed, 600 |
 * | md   | `body(md)` — 14px/400   | size `--font-size-heading-sm` (20px), borrowed, 600 |
 * | sm   | `body(md)` — 14px/400   | `body(md, $bold: true)` — 14px/600, real          |
 * | xs   | `body(md)` — 14px/400   | `body(sm, $bold: true)` — 13px/600, real          |
 *
 * DLS's own register text cites its source pixel values before the
 * compactness overrides landed (e.g. "heading-xs 20" where this kit's
 * `heading-xs` is actually 16px and `heading-sm` is the token that reads
 * 20) — the table above is what actually renders, resolved against
 * `tokens/_type.scss`'s real `--font-size-*` values, not DLS's
 * raw node text.
 *
 * Currency colour is always `--color-text-subtle`; amount and sign are
 * always `--color-text-strong`, weight 600 (`body-bold`) regardless of
 * size.
 *
 * **Layout** — `align-items: baseline` (not `center`) so the amount's
 * larger cap-height sits on the same text baseline as the currency code,
 * `justify-content: flex-end` (DLS right-aligns this component wherever
 * it appears), 4px gap, `white-space: nowrap` (the row never wraps).
 *
 * Host classes: `ui-currency-pair ui-currency-pair--{size}`, plus
 * `--positive` / `--negative` (sign() !== 'none') and `--masked`.
 *
 * RESKIN: delegate to the DLS Angular currency-pair component; keep this
 * selector and the `currency`/`amount`/`sign`/`size`/`masked` inputs.
 */
declare class UiCurrencyPair {
    /** Currency code, e.g. "SGD". Ignored when `masked` is true. */
    currency: _angular_core.InputSignal<string>;
    /** Pre-formatted amount string, e.g. "14,000.00" — this component does no number formatting. */
    amount: _angular_core.InputSignal<string>;
    /** DLS's Value axis, renamed `sign` — see the class doc. */
    sign: _angular_core.InputSignal<UiCurrencyPairSign>;
    /** DLS's Size axis, xl through xs — see the size table in the class doc. */
    size: _angular_core.InputSignal<UiCurrencyPairSize>;
    /** DLS's Mask axis. Renders "••••••" in the amount style, no currency, no sign. */
    masked: _angular_core.InputSignal<boolean>;
    protected hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiCurrencyPair, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiCurrencyPair, "ui-currency-pair", never, { "currency": { "alias": "currency"; "required": false; "isSignal": true; }; "amount": { "alias": "amount"; "required": false; "isSignal": true; }; "sign": { "alias": "sign"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "masked": { "alias": "masked"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * One item on a summary card: a headline figure with a caption under it.
 *
 * `count` is a STRING OR NUMBER because both readings are figures — `16` and
 * `29/35` are the same kind of thing to this component, and forcing the
 * consumer to stringify a count would be noise.
 */
interface UiSummaryItem {
    count: string | number;
    label: string;
    /**
     * A status dot beside the label, in this colour. Present or absent per
     * ITEM, not per card — the trades-review card mixes a plain caption with
     * four dotted ones. Rendered through `ui-pill variant="plain"`, so the
     * dot-colour table stays in one place instead of being copied per card.
     */
    dot?: UiPillColor;
    /**
     * Paints the FIGURE in the danger hue. Separate from `dot` because the two
     * answer different questions — a red dot says "this bucket is the adverse
     * one", the red figure says "look at this number" — and a consumer that
     * wants them to agree derives both from one source rather than this
     * component inferring one from the other.
     */
    danger?: boolean;
    /**
     * A change indicator beside the count — Desk Head Risk & Controls
     * (Figma 1603:134848, "Portfolio Summary Statistics"): "40 ▲3" red,
     * "49,001.72K ▼9,001.23" green.
     *
     * `tone` is EXPLICIT, never derived from `direction`. A rising breach
     * count is bad news drawn with an up-glyph; a rising recovered-volume
     * figure is good news drawn the same way — the glyph says which way the
     * number moved, the tone says whether that is welcome, and only the
     * caller who knows what the figure means can say which is which.
     */
    delta?: {
        value: string;
        direction: 'up' | 'down';
        tone: 'danger' | 'success';
    };
}
/**
 * Summary card — the white strip of headline figures that sits above a
 * blotter, with a hairline divider between items and an optional card
 * title. Its frame is the CARD FRAME verbatim — `--color-bg-level1`,
 * `--radius-md`, `--shadow-elevation-2`, no border — the same three tokens
 * `ui-card` paints, so the two read as one surface side by side (kit-fixes
 * item 17, 6 Sep 2026; it used to carry its own 1px border and a lighter
 * raw shadow).
 *
 *   <ui-summary-card [items]="figures()" />
 *   <ui-summary-card title="Reviewer progress" [items]="[{ count: '4/8', label: 'Completed' }]" />
 *
 * WHY THIS IS A KIT COMPONENT. Its chrome — surface, border, radius, shadow,
 * the 8/12 padding rhythm, the 24px hairline — existed as loose CSS classes
 * copied between call sites, and its layout was consequently fixed three
 * separate times, each fix landing in one copy. The classes had already
 * drifted: two of the copies carried `flex: 0 0 auto` +
 * `justify-content: space-between` overrides, which is why their items spread
 * across the card instead of sitting against their dividers like every other
 * copy's. Chrome shared by three call sites is exactly what the two-layer
 * rule puts in the kit.
 *
 * EVERY ITEM IS AN EQUAL COLUMN (`flex: 1 1 0; min-width: 0`) WITH ITS
 * CONTENT ANCHORED LEFT. That single rule is what makes all three uses
 * agree, and it is the whole fix — a one-item card, a three-item card and a
 * five-item card all read the same way, with each figure hard against the
 * divider that precedes it, and when the card narrows every pillar shrinks
 * by the same amount (the caption ellipsises on one line, the count never
 * wraps — kit-fixes item 12, 6 Sep 2026). Do not add a hugging or
 * distributing mode: that is the bug coming back.
 *
 * ── The delta indicator (D-Head Risk & Controls kit gap 1) ──────────────
 * Figma's delta chip is red (#e53939 on #fff4f4) or green (#00926b on
 * #effbf9) — a tint pair that matches neither `--color-danger`/
 * `--color-chart-negative-fill` nor `--color-chart-positive`/-fill closely
 * enough to repoint, so `--color-delta-danger(-bg)`/`--color-delta-success
 * (-bg)` were added to `tokens.css` with these exact values (DLS's own
 * Data/Green/10-80 for the success side). The glyph is
 * drawn inline (`.summary-delta-glyph`, an 8x6 CSS triangle) rather than the
 * Figma export, matching how `ui-accordion`'s chevron is hand-drawn from the
 * DLS path instead of a downloaded asset — a solid triangle has no vector
 * detail an export would preserve that CSS cannot. The value text is 14px
 * medium, which is DLS `label/sm` in Figma's own scale but this kit's
 * `label(md)` — see the kit's internal notes's note on the two libraries' size steps
 * not lining up 1:1.
 *
 * The count, delta and caption stay FLAT siblings under `.summary-card` —
 * no wrapper groups count+delta into their own row. A wrapper would move
 * `.summary-count`'s DOM sibling from the caption to the wrapper, and F24's
 * "the red figure is the Breach one" spec walks
 * `.summary-count--danger` -> `xpath=following-sibling::span` to prove the
 * red paint and its caption never drift apart by position. `flex-wrap` on
 * the card plus `flex-basis: 100%` on the caption gets the same two-line
 * look without moving anyone in the DOM.
 *
 * RESKIN: no DLS equivalent found — DLS has no multi-figure summary strip.
 * Expect a token reskin only; the surface/border/shadow are the same card
 * treatment `ui-card` uses.
 */
declare class UiSummaryCard {
    /** Optional card title. Omitted, the figures start at the top of the card. */
    title: _angular_core.InputSignal<string>;
    items: _angular_core.InputSignal<readonly UiSummaryItem[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiSummaryCard, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiSummaryCard, "ui-summary-card", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface UiSegment {
    key: string;
    label: string;
    /** Inert: no pointer, no keyboard stop, no selection. */
    disabled?: boolean;
}
/**
 * Segmented control — DLS `switch-tab` / `switch-tab-group`
 * (REGISTER.md §41, Figma 6765:41863): one grey track carrying
 * mutually exclusive slices, the chosen one raised as a white pill (also
 * used at 1002:236111, frame 994:233795: `All | Banking | Trading` on the
 * P&L Trend and Breakdown card headers, `By Product | By Instrument` on the
 * bottom Breakdown card).
 *
 * Round 41 audit pinned the track to the DLS numbers: bg
 * `--color-bg-disabled` (#eef2f5), radius `--border-radius-panel-lg` (8),
 * 4px inter-segment gap (`--gap-unit-inline-h`); each option 32 tall
 * (`--size-base-sm`, was the table-cell 24 before this round), 12px
 * h-padding, 4px (action-alt) radius — both already correct pre-audit; the
 * active pill's fill renamed `--color-bg-level2` → `--color-bg-level1` to
 * match the DLS node's own name (same #ffffff hex, no visual change). See
 * segmented.scss for the per-rule reasoning.
 *
 *   <ui-segmented [segments]="scopes" [(value)]="scope" label="P&L scope" />
 *
 * ── Why this is NOT `ui-filter-tabs` ────────────────────────────────────
 * `ui-filter-tabs` is DLS's filter-tab-group: SEPARATE outlined pills, the
 * chosen one filled with the inverse surface, used to NARROW a list that is
 * already on the page — where "none of them" and "all of them" are coherent
 * states. This is one CONTINUOUS track with an inset selection, used to
 * switch a card between slices that partition the same data. Nothing about
 * the two looks alike — no track, no inset, no shadow, no inverse fill — and
 * they mean different things, so a `variant` input on filter-tabs would fork
 * its template and every one of its style rules while pretending to be one
 * component. Same argument filter-tabs itself makes against `ui-tabs`.
 *
 * ── Why radio-group semantics and not `tablist` ─────────────────────────
 * A tablist promises tab PANELS: `aria-controls` pointing at a `tabpanel`,
 * and a screen reader announcing "tab 2 of 3" as a navigation move. This
 * control has no panels — it re-slices the data inside ONE card that is
 * already there, which is a CHOICE among mutually exclusive values, i.e. a
 * radio group. That choice also buys the right keyboard contract for free:
 * arrows move AND select (a radio group is one tab stop with a roving
 * tabindex), which is exactly how a segmented control should behave, whereas
 * a tablist's arrows-move-focus-only model would be wrong here.
 *
 * RESKIN: this now IS the DLS `switch-tab-group` (Round 41 audit, above) —
 * nothing further to delegate to. Keep the selector, the `segments`/`value`
 * API and the radio semantics unchanged.
 */
declare class UiSegmented {
    segments: _angular_core.InputSignal<UiSegment[]>;
    value: _angular_core.ModelSignal<string | undefined>;
    /** Accessible name for the group — a radiogroup with no label is anonymous. */
    label: _angular_core.InputSignal<string>;
    private readonly options;
    /**
     * Roving tabindex: the group is ONE tab stop. The selected option owns it;
     * with nothing selected yet the first enabled option does, so the control is
     * still reachable from the keyboard before it has a value.
     */
    protected readonly stopIndex: _angular_core.Signal<number>;
    protected select(segment: UiSegment): void;
    protected onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiSegmented, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiSegmented, "ui-segmented", never, { "segments": { "alias": "segments"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

/** One line. A `null` value is a GAP in the record, never a zero. */
interface UiLineSeries {
    key: string;
    label: string;
    values: (number | null)[];
}
/** A labelled gridline. The label is the CALLER's string — see UiLineChart. */
interface UiChartTick {
    value: number;
    label: string;
}
/** A callout pinned to one point of one series (Figma's `+7,477K` peak). */
interface UiLineAnnotation {
    seriesKey: string;
    /** Index into `categories`. */
    index: number;
    label: string;
    /** Which side of the point the callout sits on. Default 'above'. */
    place?: 'above' | 'below';
}
interface PlottedLine {
    key: string;
    label: string;
    color: string;
    dash: string | null;
    d: string;
}
interface PlacedText {
    text: string;
    /** Percentage across the plot. */
    x: number;
    /** Percentage down the plot. Absent on x-axis labels, which sit below it. */
    y?: number;
    /** Horizontal alignment class suffix, so an end label never overflows. */
    align: 'start' | 'mid' | 'end';
    place?: 'above' | 'below';
}
/**
 * Multi-series line chart — the Dashboard's **P&L Trend** card
 * (Figma 1002:236111, frame 994:233795, plot 994:233891): four series over
 * six months, four labelled gridlines, an x-axis, point callouts and a
 * legend beneath.
 *
 *   <ui-line-chart
 *     [series]="pnl" [categories]="months" [ticks]="pnlTicks"
 *     [annotations]="pnlNotes" label="P&L trend by portfolio, Jan to Jun 2026" />
 *
 * ── Presentational, and static ──────────────────────────────────────────
 * Every number arrives as an input; the component derives geometry and
 * nothing else. It has no hover layer, no tooltip and no animation — the
 * owner's call for this round ("charts need not be interactive but must
 * match the Figma"), and a deliberate departure from the data-viz default of
 * shipping a crosshair. The mitigation is the one that default exists to
 * buy: every value a reader would hover for is reachable as text, from the
 * gridline labels, the callouts, and the data table below.
 *
 * ── Why hand-built SVG and no charting library ──────────────────────────
 * Plan §7. A library brings a second styling system into a kit that must be
 * reskinned onto DBS DLS, the two-layer rule bans hex and requires tokens,
 * and none of a library's interactivity is wanted here.
 *
 * ── Why the text is HTML and only the marks are SVG ─────────────────────
 * The plot is a 100x100 viewBox with `preserveAspectRatio="none"`, so one
 * SVG user unit IS one percent of the plot in each axis and the same numbers
 * drive the SVG paths and the absolutely-positioned HTML labels — they
 * cannot drift apart. Stretching that viewBox would also stretch any text
 * and stroke inside it, so the strokes carry `vector-effect:
 * non-scaling-stroke` and the text never enters the SVG at all. Every label
 * therefore keeps its real DLS type at every width, which a uniformly scaled
 * chart-in-an-SVG would lose the moment the card narrowed.
 *
 * ── The kit does no number formatting ───────────────────────────────────
 * `ticks` and `annotations` carry the caller's own strings. Figma's axis
 * reads `8K / 0 / -8K / -16K` and its callouts read `+7,477K` / `(25,892K)`
 * — three different conventions for a number in one card. A formatter in
 * here would have to guess which, and would be the piece a reskin cannot
 * see. Locale and accounting brackets belong to the caller.
 *
 * ── Accessibility ───────────────────────────────────────────────────────
 * The SVG is `role="img"` with the caller's `label` as its accessible name
 * and its `<title>`, plus `description` as `<desc>` when given. That alone
 * would still leave the values unreadable, so the component also renders the
 * series as a visually-hidden data table: a chart that is only a picture is
 * not honest, and the table is the text alternative that makes it one. It is
 * a real `<table>` because that is what a table IS to a screen reader — the
 * kit is the layer where real elements live.
 *
 * RESKIN: if DLS ships a chart component, delegate to it and keep this
 * selector and the series/categories/ticks/annotations API. Otherwise only
 * the `--color-chart-*` tokens need repointing.
 */
declare class UiLineChart {
    series: _angular_core.InputSignal<UiLineSeries[]>;
    /** The x axis. Its LENGTH is the number of plotted points, not the data's. */
    categories: _angular_core.InputSignal<string[]>;
    /** Labelled gridlines, in the order they should read top to bottom. */
    ticks: _angular_core.InputSignal<UiChartTick[]>;
    annotations: _angular_core.InputSignal<UiLineAnnotation[]>;
    /** Accessible name — what the chart shows, not "chart". */
    label: _angular_core.InputSignal<string>;
    /** Optional longer text alternative, rendered as the SVG's `<desc>`. */
    description: _angular_core.InputSignal<string>;
    /**
     * Vertical domain. The ticks are folded in ALONGSIDE the data rather than
     * defining the scale, so a caller's rounded axis can never clip a real
     * point off the top of the plot, and an axis that is wider than the data
     * still renders every gridline it promised.
     */
    private readonly domain;
    private readonly y;
    private readonly x;
    protected readonly gridlines: _angular_core.Signal<{
        y: number;
        value: number;
        label: string;
    }[]>;
    protected readonly lines: _angular_core.Signal<PlottedLine[]>;
    protected readonly xLabels: _angular_core.Signal<PlacedText[]>;
    protected readonly callouts: _angular_core.Signal<PlacedText[]>;
    /** Pull a label at either end of the plot inboard, so it cannot overflow. */
    private alignAt;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiLineChart, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiLineChart, "ui-line-chart", never, { "series": { "alias": "series"; "required": true; "isSignal": true; }; "categories": { "alias": "categories"; "required": true; "isSignal": true; }; "ticks": { "alias": "ticks"; "required": false; "isSignal": true; }; "annotations": { "alias": "annotations"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface Band {
    /** Above the zero line or below it. Nothing else about a band matters. */
    sign: 'pos' | 'neg';
    /** The wash under the trace, closed onto the zero line. */
    fill: string;
    /** The trace itself — the band's own edge, never the baseline edge. */
    stroke: string;
}
/**
 * Sparkline — the small signed-area chart beside the Dashboard's **YTD
 * Performance** figures (Figma 1002:236111, frame 994:233795, node
 * 994:233841): one trace over a zero baseline, green where the period is up
 * and red where it is down, each run washed down to the line.
 *
 *   <ui-sparkline [values]="ytd" label="Year-to-date P&L by week" />
 *
 * ── Why the sign, and not a series colour ───────────────────────────────
 * This is the one chart in the set whose colour is not identity — it is
 * POLARITY, a diverging encoding with zero as its neutral midpoint. So it
 * takes `--color-chart-positive` / `--color-chart-negative` and never a
 * categorical slot: the day someone plots two sparklines side by side, slot 1
 * must still mean "the first series", not "a good month".
 *
 * ── Zero is always in the domain ────────────────────────────────────────
 * Above and below only mean anything relative to a baseline that is on the
 * chart, so the domain is widened to include 0 even when every reading has
 * the same sign. An all-positive sparkline therefore sits entirely above its
 * line, which is the true picture, rather than being re-centred into a
 * half-red one.
 *
 * ── Presentational, static, and hand-built ──────────────────────────────
 * Same three reasons as `ui-line-chart`, and the same 100x100 stretched
 * viewBox with `vector-effect: non-scaling-stroke`, so the trace keeps its
 * weight at any card width. There is no axis and no legend here, so nothing
 * needs to stay out of the SVG.
 *
 * ── Accessibility ───────────────────────────────────────────────────────
 * `role="img"` with the caller's `label` as the accessible name, and the
 * readings as a clipped list — the same argument as `ui-line-chart`'s table.
 * A sparkline is the most picture-like chart in the set and so the one that
 * most needs a text alternative; it sits beside a figure that names the
 * period's total, and without the list that figure is all a screen reader
 * gets.
 *
 * RESKIN: only the `--color-chart-*` tokens need repointing.
 */
declare class UiSparkline {
    /** One reading per period, in order. `null` is a GAP, never a zero. */
    values: _angular_core.InputSignal<(number | null)[]>;
    /** Accessible name — what the trace shows, not "sparkline". */
    label: _angular_core.InputSignal<string>;
    /** Optional longer text alternative, rendered as the SVG's `<desc>`. */
    description: _angular_core.InputSignal<string>;
    /** Period names for the text alternative. Falls back to a 1-based index. */
    categories: _angular_core.InputSignal<string[]>;
    private readonly domain;
    private readonly y;
    protected readonly zeroY: _angular_core.Signal<string>;
    protected readonly bands: _angular_core.Signal<Band[]>;
    /** One signed run to its wash and its trace. A flat-at-zero run has neither. */
    private toBand;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiSparkline, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiSparkline, "ui-sparkline", never, { "values": { "alias": "values"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "categories": { "alias": "categories"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** One band of every stack — a product, an instrument class, a bucket. */
interface UiStackedBarCategory {
    key: string;
    label: string;
}
/** One column. `values` are positional: index i is `categories[i]`. */
interface UiStackedBarColumn {
    key: string;
    /** The x-axis label. */
    label: string;
    values: number[];
    /**
     * The label above the bar — the CALLER's string, so `1,113` and `4,167`
     * read exactly as the frame does. Omit it and the bar carries no label.
     */
    total?: string;
}
interface Segment$1 {
    key: string;
    label: string;
    color: string;
    hatch: string | null;
    /** Height as a percentage of the plot. */
    height: number;
    gapped: boolean;
}
interface Column {
    key: string;
    label: string;
    total: string | null;
    /** Stack height as a percentage of the plot — where the total label sits. */
    height: number;
    /** Top of the stack first, so the DOM order reads as the legend does. */
    segments: Segment$1[];
}
/**
 * Stacked column chart — the Dashboard's **Breakdown by product/instrument**
 * card (Figma 1002:236111, frame 994:233795, plot 994:233952): six columns,
 * each a stack of four categories, a labelled y-grid, a total above each
 * bar, and a legend beneath.
 *
 *   <ui-stacked-bar-chart
 *     [categories]="products" [columns]="months" [ticks]="volumeTicks"
 *     label="Trade volume by product, months 3 to 8" />
 *
 * ── Presentational, and static ──────────────────────────────────────────
 * Every number arrives as an input. No hover, no tooltip, no animation —
 * the owner's call for this round, same as D4's two charts. The mitigation
 * is the same one: every value a reader would hover for is reachable as
 * text, from the gridline labels, the totals above the bars, and the data
 * table below.
 *
 * ── Why the marks are HTML boxes and not SVG ────────────────────────────
 * D4's chassis puts the marks in a 100x100 viewBox stretched with
 * `preserveAspectRatio="none"` and keeps every label as HTML outside it, so
 * nothing is ever scaled away from its real DLS type. That reasoning is
 * kept here; the implementation is not, because a stretched viewBox cannot
 * draw THESE marks. A rectangle in it has a horizontally squashed corner
 * radius and a bar whose thickness grows with the card, and the 2px surface
 * gap between segments would be 2px only at one width. A line has none of
 * those problems, which is why D4's chart is SVG and this one is not.
 * Everything the chassis actually guarantees still holds: one coordinate
 * system (percentages of the plot) shared by marks and labels so they
 * cannot drift, and marks and text both measured in final pixels.
 *
 * ── The palette, and what a fifth category wears ────────────────────────
 * Four hues, assigned in fixed order, never cycled — see `chart-palette.ts`.
 * A fifth category repeats the first hue with a 45-degree hatch and the
 * legend swatch carries the same hatch. Figma's own stacked bars use four
 * DIFFERENT hues from the P&L lines, two of them greens one step apart
 * (`green-40` #5ed1b1 beside `green-70` #00b383) sitting adjacent in the
 * stack — the exact adjacency the D4 palette was validated to avoid. The
 * validated four are used instead, deliberately.
 *
 * ── The kit does no number formatting ───────────────────────────────────
 * `ticks` and `total` carry the caller's own strings, for D4's reason: a
 * formatter in the kit would be the piece a reskin cannot see, and Figma's
 * own axis (`0 / 1.5K / 3.0K / 4.5K`) and totals (`1,113`) are in different
 * conventions.
 *
 * ── Accessibility ───────────────────────────────────────────────────────
 * The plot is `role="img"` with the caller's `label` as its accessible name,
 * plus a visually-hidden data table carrying every segment and every total.
 * The clip is on a WRAPPER, never on the table itself — a table sizes to its
 * content and ignores `width: 1px`.
 *
 * RESKIN: if DLS ships a stacked bar chart, delegate to it and keep this
 * selector and the categories/columns/ticks API. Otherwise only the
 * `--color-chart-*` tokens need repointing.
 */
declare class UiStackedBarChart {
    /**
     * The stack, listed TOP band first — the order the legend reads, so a
     * reader matching a swatch to a band never has to invert anything.
     */
    categories: _angular_core.InputSignal<UiStackedBarCategory[]>;
    columns: _angular_core.InputSignal<UiStackedBarColumn[]>;
    /** Labelled gridlines. Their values fold into the scale, never define it. */
    ticks: _angular_core.InputSignal<UiChartTick[]>;
    /** Accessible name — what the chart shows, not "chart". */
    label: _angular_core.InputSignal<string>;
    /** Column sums, used by the table when a caller gives no `total` string. */
    protected readonly totals: _angular_core.Signal<number[]>;
    /**
     * Every bar grows from zero, so the scale is 0..max rather than a fitted
     * window: a stacked bar with a floating baseline misstates every share it
     * draws. The ticks fold in ALONGSIDE the data for D4's reason — a caller's
     * rounded axis must never clip a real column off the top.
     */
    private readonly max;
    protected readonly gridlines: _angular_core.Signal<{
        pct: number;
        value: number;
        label: string;
    }[]>;
    protected readonly swatches: _angular_core.Signal<{
        key: string;
        label: string;
        color: string;
        hatch: string | null;
    }[]>;
    protected readonly plotted: _angular_core.Signal<Column[]>;
    private sum;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiStackedBarChart, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiStackedBarChart, "ui-stacked-bar-chart", never, { "categories": { "alias": "categories"; "required": true; "isSignal": true; }; "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "ticks": { "alias": "ticks"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** One row. `display` is the CALLER's string — see UiBarList. */
interface UiBarListItem {
    key: string;
    label: string;
    value: number;
    display: string;
}
interface Row$2 {
    key: string;
    label: string;
    display: string;
    /** Bar length as a percentage of the shared track. */
    width: number;
}
/**
 * Horizontal bar list — the Dashboard's **Top Contributors** card (Figma
 * 1002:236111, frame 994:233795, lists 994:234015 and 994:234053): a row
 * per category, the name on the left, a bar, and the value right-aligned.
 * The card carries two of these, By Portfolio and By Trader.
 *
 *   <ui-bar-list [items]="byPortfolio" label="Top contributors by portfolio" />
 *
 * ── One hue for every bar, and why there is no legend ───────────────────
 * These are nominal categories — portfolios, traders — with no natural
 * order, and the bar LENGTH already carries the value. Colouring each row a
 * different hue would spend the identity channel on information the chart
 * has already shown, and colouring them darker-where-bigger would re-encode
 * length as lightness. So every bar wears one hue, and the row's own name is
 * its direct label: a legend box with a single swatch would only restate the
 * card title. That is also why there is no hidden data table here — unlike a
 * line or a donut, this chart's every value is ALREADY real text on screen,
 * so a second copy would just make a screen reader read the card twice.
 *
 * The hue is `--color-chart-series-3`, violet, which is what Figma's own
 * bars use and independently the best-contrasting slot in the palette
 * (5.5:1 on the white card, where two of the four sit below 3:1).
 *
 * ── One scale across the whole list ─────────────────────────────────────
 * Bar length is a share of the largest value in the list, so the lengths are
 * comparable down the column. `max` lets a caller impose a scale from
 * outside when two lists must be read against each other; without it each
 * list scales to its own top row. (Figma's own bars are ~91% of the track at
 * the top, and its last row is drawn LONGER than its value warrants — a mock
 * artefact, not a rule.)
 *
 * ── Presentational, and static ──────────────────────────────────────────
 * Every number arrives as an input; no hover, no tooltip, no animation, on
 * the owner's call for this round. The mitigation D4 established is free
 * here: the value a reader would hover for is printed on the row.
 *
 * RESKIN: if DLS ships a bar list, delegate to it and keep this selector and
 * the items/max API. Otherwise only `--color-chart-series-3` needs
 * repointing, via the `--bl-bar-color` hook.
 */
declare class UiBarList {
    items: _angular_core.InputSignal<UiBarListItem[]>;
    /**
     * The scale's top, when it must be shared with another list. Omitted, each
     * list scales to its own largest value.
     */
    max: _angular_core.InputSignal<number | null>;
    /** Accessible name for the list — what it ranks, not "chart". */
    label: _angular_core.InputSignal<string>;
    private readonly scale;
    protected readonly rows: _angular_core.Signal<Row$2[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiBarList, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiBarList, "ui-bar-list", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** One row: a ranked category or person, with up to two trailing metrics. */
interface UiRankedListItem {
    key: string;
    label: string;
    /** The secondary line under `label` — "3 traders", "8 trade reviews not closed". */
    sublabel?: string;
    /**
     * Bar length. Omitted (or `showBar` false on the list) draws no bar — the
     * Flagged-individuals lists (Figma 1603:135075 / 1603:135119) carry no bar
     * at all, only the label pair and a metric.
     */
    value?: number;
    metrics: {
        primary: string;
        secondary?: string;
    };
}
interface Row$1 {
    key: string;
    label: string;
    sublabel: string | null;
    width: number;
    metrics: {
        primary: string;
        secondary?: string;
    };
}
/**
 * Ranked list — Desk Head Risk & Controls kit gap 2 (Figma 1603:134968
 * "Breaches reported", 1603:135075 / 1603:135119 "Flagged individuals"): a
 * vertical list of ranked rows, each a two-line label, an optional danger
 * bar, one or two trailing metrics, and an optional chevron to drill in.
 *
 *   <ui-ranked-list [items]="byUsecase" label="Breaches by usecase"
 *     [showChevron]="true" (rowActivated)="openUsecase($event)" />
 *
 * ── Why this is not `ui-bar-list` ────────────────────────────────────────
 * `ui-bar-list` is a flat name + one value; this row carries a SUBLABEL, up
 * to two metrics, and a drill-in affordance none of that component's
 * call sites need. Bending it to fit here would give every existing caller
 * dead inputs, so this is its own component — the same reasoning D4 used to
 * keep chart components apart rather than folding them into one
 * everything-prop shape.
 *
 * ── The sort-flip rule (`emphasis`) ──────────────────────────────────────
 * The Figma sheet's designer note: whichever metric the list is CURRENTLY
 * sorted by renders as prominent text (`text-strong`), the other drops to
 * subtle metadata. The rows for "Breach count" (1603:134968) show
 * `metrics.primary` strong and `.secondary` subtle; "Impacted volume"
 * (1603:135119) shows the single visible metric strong the same way. So
 * this is an INPUT (`emphasis`), never a hardcoded "primary is always
 * bold" — a dashboard that flips its own sort passes `'secondary'` and the
 * component repaints, rather than the two metrics silently disagreeing with
 * whatever the sort control now says.
 *
 * ── The bar's colour ──────────────────────────────────────────────────────
 * Figma's bar is a literal red (`primitive-color-red-60` #ff5c5c), close to
 * but distinct from `--color-chart-negative` (#ff4724, the signed-area
 * pair's red) — added to `tokens.css` as its own token,
 * `--color-chart-breach`, rather than bent onto the nearest existing one.
 * `ui-stacked-bar-list`'s "Breach reported" segment uses the same token.
 *
 * ── Presentational, and static ──────────────────────────────────────────
 * Every number arrives as an input; no hover, no tooltip, no animation —
 * D4's rule, held here too. Every value a reader would hover for is already
 * printed on the row.
 *
 * RESKIN: if DLS ships a ranked/breach list, delegate to it and keep this
 * selector and the items/emphasis API. Otherwise only `--rl-bar-color`
 * needs repointing.
 */
declare class UiRankedList {
    items: _angular_core.InputSignal<readonly UiRankedListItem[]>;
    /** The scale's top, when it must be shared with another list. */
    max: _angular_core.InputSignal<number | null>;
    /** Draws the danger bar. Off for a list with no `value`s, like Flagged individuals. */
    showBar: _angular_core.InputSignal<boolean>;
    /** Draws the trailing chevron and lets rows emit `rowActivated`. */
    showChevron: _angular_core.InputSignal<boolean>;
    /** Which metric column currently carries the sort — see the sort-flip note above. */
    emphasis: _angular_core.InputSignal<"primary" | "secondary">;
    /** Accessible name for the list — what it ranks, not "list". */
    label: _angular_core.InputSignal<string>;
    /** Emits the activated row's `key` when its chevron is clicked. */
    rowActivated: _angular_core.OutputEmitterRef<string>;
    private readonly scale;
    protected readonly rows: _angular_core.Signal<Row$1[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiRankedList, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiRankedList, "ui-ranked-list", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "showBar": { "alias": "showBar"; "required": false; "isSignal": true; }; "showChevron": { "alias": "showChevron"; "required": false; "isSignal": true; }; "emphasis": { "alias": "emphasis"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; }, { "rowActivated": "rowActivated"; }, never, never, true, never>;
}

/** One series in the stack — e.g. "Breach reported" / "Non-Breach". */
interface UiStackedBarListSeries {
    key: string;
    name: string;
    /** A `var(--color-...)` reference — never a literal hex, same rule as `UiChartSlot`. */
    color: string;
}
/** One row. `segments` are positional: index i is `series[i]`. */
interface UiStackedBarListRow {
    key: string;
    label: string;
    segments: number[];
    /** The caller's own formatted total — see the kit's number-formatting note below. */
    total: string;
    /** The caller's own formatted share, e.g. "38%". */
    pct: string;
}
/** Header labels over the label column (optional) and the two trailing
 *  metric columns. */
interface UiStackedBarListColumns {
    /** Heading over the label column — Figma 1603:135199 says "Usecase".
     *  Optional so the existing consumer's `{ total, pct }` keeps compiling. */
    label?: string;
    total: string;
    pct: string;
}
interface Segment {
    key: string;
    color: string;
    width: number;
    gapped: boolean;
}
interface Row {
    key: string;
    label: string;
    total: string;
    pct: string;
    width: number;
    segments: Segment[];
}
/**
 * Horizontal stacked bar list — Desk Head Risk & Controls kit gap 3 (Figma
 * 1603:135199, "Detection overview" / "All outcomes"): one row per
 * category, a two-segment bar (breach / non-breach), two trailing metric
 * columns with headers, a bottom value axis, and a legend.
 *
 *   <ui-stacked-bar-list [rows]="byUsecase" [series]="outcomeSeries"
 *     [ticks]="pctTicks" [columns]="{ label: 'Usecase', total: 'Total count', pct: '% breaches' }"
 *     label="Breach outcomes by usecase" />
 *
 * ── Anatomy (kit-fixes walk item 27, 6 Sep 2026 — rebuilt to the node) ──
 * The owner: "the numbers and the bars should be cleanly spaced. Implement
 * the Figma design." Per 1603:135199 / 1603:135210:
 *   - column-heading row (`Usecase` … `Total count`, `% breaches`) in
 *     label(xs) / `--color-text-subtle`, a 1px `--color-border-decorative`
 *     rule under it;
 *   - a label column that is the node's 150px (`--sbl-label-width`) wherever
 *     there is room and ellipsises down to `--sbl-label-min` where there is
 *     not;
 *   - the bar track fills the REMAINING width, never below
 *     `--sbl-track-min` — the node's own bar is `flex-[1_0_0] min-w-px`
 *     (I1603:135248;1534:25636);
 *   - rows on a 36px pitch, 16px bars vertically centred, 1px
 *     `--color-border-decorative` rule between rows;
 *   - segments in `series` order — the consumer passes red (`breach`) then
 *     green (`non-breach`);
 *   - the axis under the last row: ticks 0 / 25 / 50 / 75 / 100 spread over
 *     the track's FULL width (0 at the track's left edge, 100 at its right)
 *     with every label centred under its tick — the end labels overhang
 *     the track by half their width, as in the node;
 *   - `Total count` / `% breaches`: right-aligned columns sized to their own
 *     CONTENT, as the node draws them (1603:135243 / 1603:135214 are
 *     auto-width right-aligned text, not a fixed box);
 *   - a legend row (dot + label) at the bottom.
 * Every geometry hook is a CSS variable on `:host` so a consumer that needs
 * a wider label column can set it without touching the component.
 *
 * ── Why it survives a narrow card (the second half of item 27) ──────────
 * The first rebuild gave the label and both number columns FIXED widths
 * (150 / 72 / 72 + three 16px gaps = 342px) and handed the track the
 * remainder. In a two-up dashboard card at 1440 that remainder was 126px
 * and the chart was still broken where the owner actually looks at it. The
 * columns are now one `subgrid` declaration on `.sbl-frame` (see the scss
 * header for the full measurement table): the number columns take their
 * own `max-content` — 62.6 / 65.5px for these headings, not a guessed 72 —
 * the label column is `minmax(96px, 150px)`, and the track is
 * `minmax(120px, 1fr)`. At the node's own 616px card the track lands on
 * 241.9px, which is `Chart grid` 1603:135212's `w-[241px]`.
 *
 * ── Why this is not `ui-stacked-bar-chart` rotated ───────────────────────
 * That chart's chassis is COLUMNS: one shared 0..max scale running up the
 * page, a total above each bar, categories on the x-axis. This chart's
 * scale runs left-to-right, the "total" is a table column rather than a
 * bar-cap label, and every row carries a second metric (`pct`) that
 * chart has no slot for. Same stacking maths (`plotted()` mirrors that
 * component's `segments`/`gapped` logic almost line for line), different
 * shape — see that component's own doc note on keeping chart shapes apart
 * rather than bending one to fit two layouts.
 *
 * ── Simplified from Figma's own layout ───────────────────────────────────
 * Figma's frame (1603:135199) draws the grid, the tick labels and the
 * total/pct columns as three separately-positioned absolute layers stacked
 * behind the bars. This component uses ONE column declaration — label /
 * track / total / pct on `.sbl-frame`, taken by the header, every row and
 * the axis through `grid-template-columns: subgrid` — which keeps them
 * aligned by construction instead of by matching pixel offsets across
 * layers. Same visual result; `ui-stacked-bar-chart`'s own doc comment
 * makes the same call for its HTML-vs-SVG choice.
 *
 * ── One deviation from the node, recorded ────────────────────────────────
 * The node draws NO horizontal rule between rows and none under the heading
 * row (1603:135247 is a plain 16px-gap stack). The rules here are the
 * kit-fixes walk's own instruction for item 27 ("rows … with 1px rule
 * between rows"), so they stay; flagged for the lead rather than silently
 * reconciled either way.
 *
 * ── The series colours ────────────────────────────────────────────────────
 * Figma's two bands are a literal red (`primitive-color-red-60` #ff5c5c)
 * and green (`primitive-color-green-40` #5ed1b1) — neither in the four-hue
 * categorical palette (`chart-palette.ts`, which is for NOMINAL categories
 * with no "good/bad" reading, and a breach outcome is not one) nor close
 * enough to the signed-area `--color-chart-negative`/`-positive` pair to
 * reuse. Added to `tokens.css` as `--color-chart-breach`/
 * `--color-chart-non-breach`, the same red `ui-ranked-list`'s bar uses. The
 * component itself stays opinion-free — `series[].color` takes any
 * `var(--color-...)` reference, the sink demo just happens to pass these two.
 *
 * ── The kit does no number formatting ────────────────────────────────────
 * `total`, `pct` and `ticks` all carry the caller's own strings — D4's rule,
 * held by `ui-stacked-bar-chart` too. `ticks` defaults to 0/25/50/75/100
 * when omitted (the node's axis); pass your own to change the scale.
 *
 * ── Presentational, and static ──────────────────────────────────────────
 * Every number arrives as an input; no hover, no tooltip, no animation.
 *
 * RESKIN: if DLS ships a horizontal stacked bar, delegate to it and keep
 * this selector and the rows/series/ticks/columns API.
 */
declare class UiStackedBarList {
    rows: _angular_core.InputSignal<readonly UiStackedBarListRow[]>;
    series: _angular_core.InputSignal<readonly UiStackedBarListSeries[]>;
    /** Labelled gridlines on the value axis. Their values fold into the
     *  scale. Empty/omitted = the node's 0 / 25 / 50 / 75 / 100. */
    ticks: _angular_core.InputSignal<readonly UiChartTick[]>;
    columns: _angular_core.InputSignal<UiStackedBarListColumns>;
    /** Accessible name — what the chart shows, not "chart". */
    label: _angular_core.InputSignal<string>;
    private readonly axisTicks;
    private readonly totals;
    /** Every bar grows from zero — same 0..max scale rule as `ui-stacked-bar-chart`. */
    private readonly max;
    protected readonly gridlines: _angular_core.Signal<{
        pct: number;
        value: number;
        label: string;
    }[]>;
    protected readonly plotted: _angular_core.Signal<Row[]>;
    private sum;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiStackedBarList, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiStackedBarList, "ui-stacked-bar-list", never, { "rows": { "alias": "rows"; "required": true; "isSignal": true; }; "series": { "alias": "series"; "required": true; "isSignal": true; }; "ticks": { "alias": "ticks"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** One slice. `display` is the CALLER's string — see UiDonutChart. */
interface UiDonutSegment {
    key: string;
    label: string;
    value: number;
    display?: string;
}
interface Slice {
    key: string;
    label: string;
    value: string;
    share: string;
    /** Either a palette slot or a `url(#…)` at this instance's hatch. */
    stroke: string;
    dashArray: string;
    dashOffset: number;
}
interface Hatch {
    id: string;
    angle: number;
    color: string;
}
interface LegendEntry {
    key: string;
    label: string;
    color: string;
    hatch: string | null;
}
/**
 * Donut chart — the Dashboard's **Product Breakdown** (Figma 1002:236111,
 * frame 994:233795, donut 1243:80948): a ring of six slices with a figure
 * and a caption in the hole.
 *
 *   <ui-donut-chart [segments]="products" centerValue="100K"
 *     centerLabel="Total P&L" label="P&L by product" />
 *
 * ── The centre label is TWO strings, and it is HTML ─────────────────────
 * `centerValue` is the hero figure, `centerLabel` the caption under it.
 * They are absolutely-positioned HTML over the SVG rather than `<text>`
 * inside it, for D4's reason: text inside a scaled viewBox is scaled type,
 * and a card that narrows would silently shrink `100K` out of the DLS
 * scale. Both are the caller's own strings — the kit formats no numbers.
 *
 * ── The legend is IN this component, and can be turned off ──────────────
 * Two or more series always ship with a legend, so this one carries its own
 * and a donut is never handed out identifiable by hue alone. But Figma's
 * card puts a RICHER legend beside the ring — name, share, value, and a
 * checkbox that filters the table next to it (1243:80962) — and that is a
 * control, not a chart part. So `showLegend` exists: D6 sets it false and
 * supplies that one. Turning it off is a deliberate promise by the caller
 * to provide its own, which is why the default is on.
 *
 * ── Six slices against four hues ────────────────────────────────────────
 * The palette is four wide and is never cycled (see `chart-palette.ts`), so
 * slices five and six repeat the first two hues with a 45-degree hatch, and
 * the legend swatch carries the same hatch. The texture is the data-viz
 * backup channel, opt-in and used here for exactly what it is for.
 *
 * ── Why this one IS an SVG, when the bar charts are not ─────────────────
 * An arc has no HTML equivalent. Unlike D4's plots, the viewBox is NOT
 * stretched — a circle drawn into a squashed viewBox is an ellipse — so the
 * ring scales uniformly and `vector-effect` is deliberately absent: the ring
 * SHOULD get thicker as the donut gets bigger. Only the text stays out.
 *
 * ── Presentational, and static ──────────────────────────────────────────
 * No hover, no tooltip, no animation, on the owner's call for this round.
 * Every value a reader would hover for is reachable as text, from the
 * legend, the centre figure and the data table.
 *
 * RESKIN: if DLS ships a donut, delegate to it and keep this selector and
 * the segments/centre API. Otherwise only the `--color-chart-*` tokens need
 * repointing.
 */
declare class UiDonutChart {
    segments: _angular_core.InputSignal<UiDonutSegment[]>;
    /** The hero figure in the hole — the caller's string, e.g. `100K`. */
    centerValue: _angular_core.InputSignal<string>;
    /** The caption under it, e.g. `Total P&L`. */
    centerLabel: _angular_core.InputSignal<string>;
    /** Accessible name — what the ring divides, not "chart". */
    label: _angular_core.InputSignal<string>;
    /** Optional longer text alternative, rendered as the SVG's `<desc>`. */
    description: _angular_core.InputSignal<string>;
    /**
     * On by default: two or more series always ship with a legend. Turn it off
     * only when the CALLER supplies one, as the Figma card does.
     */
    showLegend: _angular_core.InputSignal<boolean>;
    protected readonly radius = 40;
    protected readonly thickness = 20;
    private readonly instance;
    /** Only positive readings have an arc; a ring cannot show a negative share. */
    private readonly positives;
    private readonly total;
    /**
     * A pattern per hatched SLOT, keyed by the slot's index so two slices on
     * the same slot share one definition. The id carries this component's
     * instance number because an SVG id is document-global, and a second donut
     * on the page would otherwise silently paint through the first's patterns.
     */
    private readonly hatchById;
    protected readonly hatches: _angular_core.Signal<Hatch[]>;
    protected readonly legend: _angular_core.Signal<LegendEntry[]>;
    protected readonly slices: _angular_core.Signal<Slice[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiDonutChart, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiDonutChart, "ui-donut-chart", never, { "segments": { "alias": "segments"; "required": true; "isSignal": true; }; "centerValue": { "alias": "centerValue"; "required": false; "isSignal": true; }; "centerLabel": { "alias": "centerLabel"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "showLegend": { "alias": "showLegend"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * The one place the kit decides which hue a categorical series wears.
 *
 * D4 established the rule inside `ui-line-chart`: the chart palette is FOUR
 * hues, assigned in fixed order, and it is never cycled — a fifth series
 * repeats the first hue with a SECOND channel carrying the difference, and
 * the legend swatch shows the same second channel so the repeat is never a
 * lie. D5 needs the identical rule in two more charts, so it lives here
 * rather than being re-typed three times and drifting.
 *
 * `ui-line-chart` keeps its own copy of the rule because its second channel
 * is a DASH, which only exists for a stroke. Fills get a texture instead —
 * the data-viz backup channel, opt-in and used here for exactly the reason
 * it exists: a repeated hue that must still be told apart.
 *
 * The palette ORDER is the colourblind-safety mechanism, validated in
 * `styles/tokens.css`. Re-run the validator before changing it.
 */
/** How many hues the chart palette has. Past this, slots repeat WITH a texture. */
declare const CHART_SERIES_SLOTS = 4;
interface UiChartSlot {
    /** A `var(--color-chart-series-N)` reference — never a literal hex. */
    color: string;
    /** Index into HATCH_ANGLES. 0 is solid. */
    band: number;
}
/** The slot for the Nth series, counting from zero. */
declare function uiChartSlot(index: number): UiChartSlot;
/** The hatch angle for a band, or `null` when the band is solid. */
declare function uiChartHatchAngle(band: number): number | null;
/**
 * The texture as a CSS background-image, for the charts whose marks are HTML
 * boxes. Stripes are cut in the SURFACE colour rather than in a darker step
 * of the hue: the surface is what separates marks everywhere else in this
 * kit (the 2px gap, the 2px ring), so the texture is the same idea at a
 * smaller pitch and cannot be mistaken for a second data value.
 */
declare function uiChartHatchCss(band: number): string | null;

type UiDrawerFooterLayout = 'default' | 'stacked' | 'right';
/**
 * Right-edge sliding panel — the DLS 3.1 `drawer` component (page 1656:258,
 * set 2350:12317, REGISTER.md §15, audited + grown ADDITIVELY
 * 2 Sep 2026 — the §13–§20 round). Fixed to the viewport's right edge, no
 * gaps top/right/bottom:
 *
 *   <ui-drawer heading="Profile" [open]="drawerOpen()" (closed)="drawerOpen.set(false)">
 *     …body…
 *   </ui-drawer>
 *
 * NON-MODAL, unlike `ui-modal-shell`: no backdrop, and the page behind it
 * stays interactive — the Figma spec has no scrim layer, so this doesn't
 * invent one. Escape closes it while open (a document-level listener, since
 * there is no backdrop to own the keydown), matching the platform convention
 * `ui-modal-shell` and `[uiTooltip]` already follow.
 *
 * Rendered via `@if (open())` rather than a `display: none` host style, so a
 * closed drawer leaves nothing in the DOM (no hidden animation state to
 * reset, no offscreen focusable content).
 *
 * **Header** (2277:12259; Medium and "Small (for internal tools)" measure
 * identically) — 24px h / 16px v padding, `--shadow-elevation-2` INSTEAD of
 * a bottom rule (the sink used to draw a 1px border here; DLS draws a
 * shadow, so the border is gone, not merely hidden). Content row gap 12,
 * -4px optical end margins on the leading (back button) and trailing
 * (actions group) edges so a 32px icon-button's 24px glyph lands flush
 * with the 24px header padding rather than the button's own box:
 *
 *   <ui-drawer heading="Case #4471" subtitle="Opened 2 Sep" [count]="3"
 *     back [open]="drawerOpen()" (backActivated)="onBack()" (closed)="drawerOpen.set(false)">
 *     <button ui-drawer-actions ui-button variant="secondary">Edit</button>
 *     …body…
 *   </ui-drawer>
 *
 * `subtitle` — `body(sm)` 13px `--color-text-subtle`, 4px under the
 * heading. `count` — an optional `ui-badge` at DLS's Medium emphasis
 * (§4, the inverse-grey pill), 8px right of the heading. `back` renders a
 * leading 32px `ui-icon-button` (24px chevron-left) and emits
 * `backActivated` on click — OFF by default, since most drawers have no
 * back navigation. Title-group is `min-height: 32` so a bare heading
 * (no subtitle) still centres against the 32px back/close buttons.
 *
 * Optional HEADER-ACTIONS slot — DLS iconButton/button slots beside the
 * close icon — via `[ui-drawer-actions]`. Projects left of the close
 * button, inside the same flex group (8px gap), so the header's
 * space-between layout still keeps heading left, actions+close right.
 * Empty when unused — no stray gap, since the wrapper `<div class="header-actions">`
 * is the flex container that already holds close. The close button (and
 * the back button, when shown) are now `button[ui-icon-button]` (§8) —
 * grey glyph, DLS's real icon-button anatomy — rather than a hand-rolled
 * `<button>`; class names (`close-btn`) are kept unchanged so existing
 * specs (f39-org-chart et al.) that target them by class still pass.
 *
 * **Body** (239346:102685) — 24/24 padding, slot, unchanged. Optional
 * `flush` input drops that inset to zero (`panel-body--flush`) for a body
 * whose own content draws edge-to-edge rows and hairlines — list-style
 * drawers like the sign-off tracker — where the kit's 24px inset would just
 * double up against the content's own edge padding.
 *
 * **Footer** (158851:9191) — an optional `[ui-drawer-footer]` slot, only
 * rendered when the caller projects into it (`.drawer-footer:empty` is
 * hidden by CSS — the same always-render-let-:empty-collapse pattern
 * `ui-alert`'s actions slot and `ui-coachmark`'s image slot use, no
 * `hasFooter` input needed). 24px h / 16px v padding, gap 8,
 * `--shadow-sticky-bottom`. `footerLayout`:
 *
 *   <ui-drawer heading="Add Task" [open]="open()" (closed)="open.set(false)">
 *     …body…
 *     <button ui-drawer-footer ui-button variant="secondary" size="small" (click)="cancel()">Cancel</button>
 *     <button ui-drawer-footer ui-button variant="primary" size="small" (click)="save()">Save</button>
 *   </ui-drawer>
 *
 * - `default` (the default) — DLS's "Default" type: each projected child
 *   gets `flex: 1`, so two buttons split the row evenly (Label secondary +
 *   Label primary).
 * - `stacked` — DLS's "Stacked" type: column, each child full-width.
 *   Primary-first is the CALLER's job (DOM order), not a CSS reorder — DLS
 *   shows primary over secondary and this component has no way to tell
 *   which projected child is which.
 * - `right` — DLS's "Right-aligned" type: `justify-content: flex-end`,
 *   children hug their own width rather than stretching.
 *
 * OWNER'S RULING (2 Sep 2026, carried from the Button pass §7): footer
 * buttons are `ui-button size="small"` (32px) — the platform's compact
 * voice — not DLS's own 48px Large buttons for this slot. The caller
 * supplies its own `ui-button`s; this component only lays out whatever is
 * projected, same division of labour as `[ui-drawer-actions]`.
 *
 * Docblock node refs for the record: set 2350:12317; header 2277:12259;
 * body 239346:102685; footer 158851:9191 (Default | Stacked |
 * Right-aligned types).
 *
 * RESKIN: delegate to the DLS Angular `drawer`; keep selector + inputs
 * unchanged.
 */
declare class UiDrawer {
    heading: _angular_core.InputSignal<string>;
    open: _angular_core.InputSignal<boolean>;
    closed: _angular_core.OutputEmitterRef<void>;
    /** DLS gap (b) — `body(sm)` 13px `--color-text-subtle`, 4px under the heading. */
    subtitle: _angular_core.InputSignal<string | undefined>;
    /** DLS gap (b) — an `ui-badge` at Medium emphasis, 8px right of the heading. `undefined` renders none. */
    count: _angular_core.InputSignal<string | number | undefined>;
    /**
     * DLS gap (b) — a leading 32px back icon-button (24px chevron-left). Off
     * by default. `transform: booleanAttribute` so a bare `back` attribute
     * (no `[back]="true"` binding needed) reads as true — the same ergonomics
     * `ui-icon-button`'s `outline` gets, since `back` sits right next to it
     * on a drawer's opening tag and consumers reach for the HTML-boolean
     * spelling by habit.
     */
    back: _angular_core.InputSignalWithTransform<boolean, unknown>;
    backActivated: _angular_core.OutputEmitterRef<void>;
    /**
     * Drops the body's 24px inset to zero, for content that draws its own
     * edge-to-edge rows and hairlines (list-style drawers like the sign-off
     * tracker) — the kit's own padding would otherwise double up against the
     * content's. `transform: booleanAttribute` for the same bare-attribute
     * ergonomics as `back`.
     */
    flush: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** DLS's footer Type axis — see the class doc. Only read when a caller projects `[ui-drawer-footer]` content. */
    footerLayout: _angular_core.InputSignal<UiDrawerFooterLayout>;
    protected onEscape(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiDrawer, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiDrawer, "ui-drawer", never, { "heading": { "alias": "heading"; "required": true; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "count": { "alias": "count"; "required": false; "isSignal": true; }; "back": { "alias": "back"; "required": false; "isSignal": true; }; "flush": { "alias": "flush"; "required": false; "isSignal": true; }; "footerLayout": { "alias": "footerLayout"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "backActivated": "backActivated"; }, never, ["[ui-drawer-actions]", "*", "[ui-drawer-footer]"], true, never>;
}

interface UiBreadcrumbItem {
    label: string;
    id?: string;
}
type UiBreadcrumbSegment = {
    kind: 'crumb';
    item: UiBreadcrumbItem;
    current: boolean;
} | {
    kind: 'menu';
    hidden: UiBreadcrumbItem[];
};
/**
 * DLS `Breadcrumb` (set 270365:28502, REGISTER.md §6, audited
 * 2 Sep 2026) — one axis, Overflow menu False/True. Each non-current crumb
 * IS an instance of the DLS button at Variant=Plain, Size=Tiny (link node
 * 270365:28531), so this component depends on `ui-button` shipping that
 * `variant="plain" size="tiny"` contract (register item 7, built
 * concurrently against the same brief). The ellipsis/overflow trigger IS an
 * instance of the DLS icon button at Size=Tiny (menu-button 1400:2542, no
 * label to give it) — `ui-icon-button size="tiny"` (register item 8; retired
 * `ui-button`'s stand-in `iconOnly` flag, which mis-coloured and mis-sized
 * the glyph — see REGISTER.md §8).
 *
 *   <ui-breadcrumb [items]="crumbs" (navigate)="onCrumbClick($event)" />
 *   <ui-breadcrumb [items]="crumbs" [maxItems]="4" (navigate)="..." />
 *
 * Overflow (`maxItems`, default 0 = never collapse; values below 2 also
 * never collapse — collapsing to fewer than 2 visible crumbs makes no
 * sense): once `items().length > maxItems()`, the row renders the FIRST
 * item, a separator, the ellipsis menu button, another separator, then the
 * LAST `maxItems - 1` items — DLS's own "Label / … / Label / Label" shape
 * (separator 1400:2554 ×2 either side of menu-button 1400:2542). Opening
 * the menu-button reveals every item strictly between the first crumb and
 * the visible tail, as `role="menuitem"` rows; choosing one emits
 * `navigate` and closes the popover, same as clicking a visible crumb.
 * Escape and an outside click also close it.
 *
 * The CURRENT crumb (always the last item, whether or not it fell inside
 * the collapsed tail) renders as inert text — `--color-text-strong`, no
 * button chrome, `aria-current="page"` — never a `navigate`-emitting link.
 *
 * Text sizes: the owner's ruling (2 Sep 2026, corrected mid-build from an
 * initial 14px brief) keeps the crumbs and the current crumb at the kit's
 * `type.label('sm')` — 13px/500 — rather than DLS's own "label/sm" 14px;
 * that 14px is a DLS-side naming quirk (its "sm" role is one step above
 * this kit's "sm" step), not something the platform inherits. The
 * separator keeps the kit's `type.label('md')` (14px/500) standing in for
 * DLS's own label/md 16px — this codebase's label scale
 * (tokens/_type.scss) has no 16px step, so 14 is the closest
 * existing one (see breadcrumb.scss).
 *
 * RESKIN: delegate to the DLS Angular breadcrumb; keep the selector and
 * the `items` / `maxItems` inputs plus the `navigate` output unchanged.
 */
declare class UiBreadcrumb {
    items: _angular_core.InputSignal<UiBreadcrumbItem[]>;
    /** 0 (default) = never collapse. Values below 2 also never collapse. */
    maxItems: _angular_core.InputSignal<number>;
    navigate: _angular_core.OutputEmitterRef<UiBreadcrumbItem>;
    protected menuOpen: _angular_core.WritableSignal<boolean>;
    private host;
    protected readonly segments: _angular_core.Signal<UiBreadcrumbSegment[]>;
    protected onNavigate(item: UiBreadcrumbItem): void;
    protected pickHidden(item: UiBreadcrumbItem): void;
    protected toggleMenu(event: Event): void;
    protected onDocumentClick(event: Event): void;
    protected onEscape(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiBreadcrumb, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiBreadcrumb, "ui-breadcrumb", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; "maxItems": { "alias": "maxItems"; "required": false; "isSignal": true; }; }, { "navigate": "navigate"; }, never, never, true, never>;
}

type UiCoachmarkPlacement = 'top' | 'top-left' | 'top-right' | 'bottom' | 'bottom-left' | 'bottom-right' | 'left' | 'right' | 'none';
/**
 * Coachmark — the DLS 3.1 `coachmark` component (page 21702:183823, set
 * `188493:2143`, REGISTER.md §12, audited 2 Sep 2026). A 320px
 * dark onboarding-tour panel: title + close, projected body copy, an
 * optional image, and an optional "N of M" stepper footer with outlined
 * on-dim arrow controls.
 *
 *   <ui-coachmark title="Filter your trades" placement="bottom" (closed)="dismiss()">
 *     Use the filter bar to narrow this list by desk, status or date.
 *   </ui-coachmark>
 *
 *   <ui-coachmark
 *     title="Step 2: Review flags"
 *     [step]="2" [total]="5"
 *     placement="bottom-left"
 *     (previous)="back()" (next)="advance()" (closed)="dismiss()"
 *   >
 *     Detected mismatches are highlighted in amber.
 *     <img uiCoachmarkImage src="…" alt="" />
 *   </ui-coachmark>
 *
 * ── PANEL (188493:2144) ───────────────────────────────────────────────────
 * bg `--color-bg-dim` (#172733, DLS `background-level_4`), radius
 * `--radius-sm` (4, `border_radius-panel-md`), 16px horizontal / 12px
 * vertical padding, 16px internal gap between the content block / image /
 * footer, 320px wide (`width` input, default 320 — a plain `number` in px
 * rather than a CSS length, since every DLS instance and every call site
 * this component has today is a fixed pixel width; nothing stops widening
 * that to accept a string later). Neither the horizontal 16px padding nor
 * the 16px inter-block gap has a matching token — DLS's panel-padding scale
 * runs h-sm(12)/h-lg(24) and the gap scale tops out at block-h(12); no
 * h-md(16) or gap-lg(16) step exists (the same trap `ui-card`'s 16px gap
 * documents, card.scss). Hardcoded here rather than reaching for the
 * nearest wrong-value token; flagged to the lead as a token gap, same as
 * `ui-card`'s.
 *
 * ── HEADER + BODY (`.cm-content`) ─────────────────────────────────────────
 * `title` heading/2xs white — 14px here (compactness override, DLS's own
 * printed heading/2xs is 16; the owner's ruling already pulls this role to
 * 14px everywhere else it appears, see `ui-tooltip`'s title and
 * REGISTER.md's decision log) — flex 1, a 24px
 * `ui-icon-button shape="square" size="tiny" tone="on-dim" [outline]="true"`
 * close control (DLS: outline · tiny · dim — the outline was missing until
 * the 6 Sep 2026 harvest, item 29; hand-authored 16px × glyph) at the
 * row's other end, 12px between them.
 * Body is the default-slot projection, body/sm white, 4px under the header
 * row (both wrapped in `.cm-content` so that 4px is one `gap`, not a
 * margin either side could duplicate).
 *
 * ── IMAGE (optional, `[uiCoachmarkImage]`) ────────────────────────────────
 * 288×162 (16:9) box, 4px radius, `overflow: hidden`. The caller projects
 * an `<img>`; `.cm-image` is always rendered — an unprojected slot renders
 * nothing and `.cm-image:empty { display: none }` (coachmark.scss) collapses
 * its box and its share of the panel's gap, the same "always-render, let
 * :empty do the work" call `ui-alert`'s actions slot documents — cheaper
 * than a `ContentChild` round-trip to detect projected content. TRAP: the
 * projected `<img>` carries the CALLER's encapsulation attribute, not this
 * component's, so a plain scoped `.cm-image img { … }` rule can never reach
 * it (the kit's internal notes "projected content cannot be styled from its host");
 * coachmark.scss sizes it to fill via `::ng-deep`, the same escape
 * `ui-button`'s icon slots and `ui-icon-button`'s glyph use.
 *
 * ── FOOTER (optional, `step`/`total`) ─────────────────────────────────────
 * Renders only when `total` is set (DLS's title+body+close-only variation
 * has no footer at all). Left: "{step} of {total}" body/sm white, flex 1 —
 * omitted (footer right-aligned via `.cm-footer--end`) when `step` isn't
 * also set, so a caller can show bare prev/next controls with no counter.
 * Right: two 32px `ui-icon-button size="small" tone="on-dim" [outline]="true"`
 * controls, 8px apart — hand-authored 24px arrow-left / arrow-right glyphs.
 * DLS's two step-edge variations are input-driven, not separate templates:
 * on step 1 the back button is omitted entirely (DLS "1 of 5" shows only
 * →, not a disabled ←); on the last step the forward button's glyph swaps
 * to a tick (DLS "5 of 5") and still emits `next` — the caller decides what
 * "done" means (close the tour, navigate away, …), this component only
 * reports the click. `.cm-next--last` marks that swapped state for anyone
 * scripting against it (tests included) without parsing the projected SVG.
 *
 * ── POINTER (`.cm-pointer`, DLS `.tooltip-pointer` 188493:2145) ──────────
 * Rebuilt 6 Sep 2026 (kit-fixes item 29). DLS's pointer is a 34×8 BOX
 * whose visible triangle is the path `M17 0 L22 8 H12 Z` — 10 wide × 8
 * tall, centred in the box — filled with the panel's `--color-bg-dim`. It
 * is NOT a 34-wide wedge: the first build drew the whole box as a
 * border-triangle, 3.4× too wide. Rendered here as an inline `<svg>` (34×8
 * on the top/bottom edges, 8×34 on the sides; `pointerKind` picks the
 * path that points the right way), `pointer-events: none`.
 * `placement` sets which EDGE it sits on — the edge FACING the anchor, i.e.
 * the side the panel was placed on relative to it: `top*` placements put
 * the panel above the anchor, so the pointer sits on the panel's BOTTOM
 * edge, pointing down; `bottom*` is the mirror (pointer on the TOP edge,
 * pointing up); `left` (panel to the anchor's left) puts it on the RIGHT
 * edge, pointing right; `right` on the LEFT edge, pointing left. Along
 * the edge (harvested off the nine `Placement=` symbols, panel 320 wide):
 * the bare `top`/`bottom` values centre the box (x=143, tip at 160);
 * `-left`/`-right` put the box FLUSH with the panel corner (x=0 / x=286,
 * so the tip lands 17px in from that corner — not 16px inset as before);
 * `left`/`right` centre the 8×34 box on the side edge (y=143). `none`
 * renders no pointer at all — the DLS "No arrow" axis value.
 *
 * ── POSITIONING IS THE CALLER'S JOB ────────────────────────────────────────
 * Unlike `ui-tooltip`, this component does NOT anchor, flip, or track
 * anything — `placement` only selects the pointer's edge/alignment, exactly
 * as documented above. The panel renders wherever it sits in the DOM; a
 * caller wanting it pinned beside a real anchor element positions the host
 * itself (`position: absolute`/`fixed` + coordinates, a CDK overlay, or
 * simple in-flow placement next to the target) and picks the matching
 * `placement` so the pointer's edge agrees with where the panel actually
 * ended up. That split is deliberate, not a shortcut: DLS's own "arrow can
 * move based on where the content is" framing (recorded on `ui-tooltip`)
 * describes a floating tooltip anchored to one small trigger; a coachmark
 * is placed by a TOUR — a sequence with its own step-to-target mapping,
 * possibly scroll-into-view logic, possibly a scrim — none of which exists
 * in the reference app yet. Building a bespoke positioner here would be guessing at
 * that future directive's shape. RESKIN: the DLS Angular `coachmark`'s own
 * positioning (if the Storybook entry has one) or a future
 * `ui-coachmark-anchor` directive is where that logic belongs; this
 * component's job stays "render the DLS 3.1 panel anatomy correctly", the
 * same scope `ui-tooltip`'s docblock draws around its own panel-building
 * half versus its anchoring half.
 *
 * Variations frame (188493:2270) covered: title+body+close only (no
 * `step`/`total`); + stepper; first step (no back button); last step (tick
 * glyph); with image.
 *
 * RESKIN: delegate to the DLS Angular Storybook `coachmark`, keeping this
 * selector, the `title`/`step`/`total`/`placement`/`width` inputs, the
 * `[uiCoachmarkImage]` slot and the `closed`/`previous`/`next` outputs.
 */
declare class UiCoachmark {
    /** Heading/2xs (14px here — compactness override), required — DLS's
     *  panel never appears without one. */
    title: _angular_core.InputSignal<string>;
    /** Pointer edge + alignment only — see the class doc's Positioning section. */
    placement: _angular_core.InputSignal<UiCoachmarkPlacement>;
    /** Panel width in px. DLS's own instances are all 320; exposed rather
     *  than hardcoded in case a future tour step needs a wider panel for a
     *  bigger image. */
    width: _angular_core.InputSignal<number>;
    /** Current step, 1-based. Omit for a non-stepper coachmark (no footer,
     *  since `total` gates the footer, not this). */
    step: _angular_core.InputSignal<number | undefined>;
    /** Total step count. Setting this is what turns the footer on — see the
     *  class doc's Footer section. */
    total: _angular_core.InputSignal<number | undefined>;
    /** The close (×) control. */
    closed: _angular_core.OutputEmitterRef<void>;
    /** The back arrow — never emitted from step 1, since the control isn't
     *  rendered there. */
    previous: _angular_core.OutputEmitterRef<void>;
    /** The forward arrow/tick. Always emitted on click, including the last
     *  step — this component doesn't decide what "done" means. */
    next: _angular_core.OutputEmitterRef<void>;
    protected stepperText: _angular_core.Signal<string | null>;
    protected isFirstStep: _angular_core.Signal<boolean>;
    protected isLastStep: _angular_core.Signal<boolean>;
    protected hostClass: _angular_core.Signal<string>;
    /** Which way the pointer's triangle points — the edge it sits on is the
     *  one FACING the anchor (see the class doc's Pointer section), so
     *  `bottom*` (panel below the anchor) points UP, `top*` points DOWN,
     *  `left` (panel to the anchor's left) points RIGHT, `right` points LEFT.
     *  `null` for `none`. */
    protected pointerKind: _angular_core.Signal<"left" | "right" | "up" | "down" | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiCoachmark, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiCoachmark, "ui-coachmark", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "placement": { "alias": "placement"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "total": { "alias": "total"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "previous": "previous"; "next": "next"; }, never, ["*", "[uiCoachmarkImage]"], true, never>;
}

type UiChipKind = 'input' | 'suggestion';
/**
 * Chip — the DLS 3.1 `chip` components (page 220898:2706, REGISTER.md
 * §11, audited 2 Sep 2026). Two DLS component sets, one component, switched
 * by `type`:
 *
 *   <ui-chip label="John Doe" (removed)="remove(p)">
 *     <svg uiChipIcon>…16px…</svg>
 *   </ui-chip>
 *   <ui-chip label="Read-only" [readonly]="true" />
 *   <button ui-chip kind="suggestion" label="Reset password" (click)="run()"></button>
 *
 * **`chip-input`** (220898:11643) — "used in conjunction with inputs or
 * multi-selects to encapsulate a block of information": a non-interactive
 * `<ui-chip>` element (a span-like host, deliberately NOT a button) with an
 * optional trailing 24px CIRCLE `ui-icon-button` (close_16, pulled in by a
 * `-4px` optical margin — the §8 tiny icon-button IS the remove control,
 * hover/pressed/focus all live on it, not the chip body) that emits
 * `removed`. `readonly` hides the remove control — DLS's Read-only state.
 *
 * **`.chip-suggestion`** (220898:11789) — "a few selected options the user
 * can press": the WHOLE chip is the control, so it is a real `<button>`,
 * reached via the `button[ui-chip]` attribute selector so native semantics
 * (type, disabled, click, keyboard activation) stay intact — the same
 * pattern `ui-button` and `ui-icon-button` use. Carries `--shadow-elevation-2`
 * at rest; hover/pressed/focus/disabled are native `:hover`/`:active`/
 * `:focus-visible`/`:disabled` rules (see chip.scss).
 *
 * `type` DEFAULTS FROM THE HOST TAG the caller wrote, rather than one fixed
 * default for both selectors: `<ui-chip>` (the element selector) defaults to
 * `input`, `<button ui-chip>` (the attribute selector) defaults to
 * `suggestion` — each selector's natural default matches its own DLS
 * anatomy, so a suggestion-chip caller doesn't have to repeat
 * `kind="suggestion"` on every button. Either can still override explicitly
 * (an explicit `kind="input"` on a `<button ui-chip>` is legal but has no
 * DLS anatomy behind it, same "CSS renders it, nothing recommends it" shape
 * as `ui-button`'s undocumented Variant×Tone cells).
 *
 * Shared chrome (both types): 32px tall (`--size-base-sm`), `--radius-pill`,
 * background `--color-bg-alt` (#f7f7f7), 0 8px padding (DLS
 * `padding-indicator-h-lg` — NO SUCH TOKEN EXISTS in tokens.css yet, so this
 * is hand-written 8px; report to the lead in case one should be added), 4px
 * inline gap (`--gap-unit-inline-h`), an optional 16px leading icon
 * projected via `[uiChipIcon]`, label at the kit's `label(sm)` — 13px/500
 * (OWNER'S RULING, the same compactness call `ui-button`/`ui-badge` make;
 * DLS's own printed spec says 14px for this role and this component
 * deliberately does not chase it).
 *
 * NOT `ui-pill` (a status dot + label answering "what state is this thing
 * in?") and NOT `ui-tag-info` (a positional "which of these is newest?"
 * marker, present zero or one times over a list) — see those files'
 * docblocks. A chip answers neither question: it either ENCAPSULATES a
 * piece of information the user entered (removable, `chip-input`) or OFFERS
 * a suggested action to press (`chip-suggestion`). Different question,
 * different component — DLS names it separately and so does this kit.
 *
 * RESKIN: delegate to the DLS Angular `chip-input` / `chip-suggestion`
 * components; keep both selectors and every input/output unchanged.
 */
declare class UiChip {
    private readonly elementRef;
    /**
     * DLS's two sets. Left `undefined` by default so the host tag can supply
     * its own default — see the class doc's "type defaults from the host tag"
     * section.
     */
    kind: _angular_core.InputSignal<UiChipKind | undefined>;
    /** Chip text — DLS `label(sm)`, both types. */
    label: _angular_core.InputSignal<string>;
    /**
     * `chip-input`'s Read-only state: hides the remove control so the chip
     * becomes plain, non-removable information. No effect on a suggestion
     * chip, which has no remove control to begin with — use the native
     * `disabled` attribute on a `button[ui-chip]` for that set instead.
     */
    readonly: _angular_core.InputSignal<boolean>;
    /** Emitted when the input chip's remove control is activated. */
    removed: _angular_core.OutputEmitterRef<void>;
    protected resolvedKind: _angular_core.Signal<UiChipKind>;
    protected hostClass: _angular_core.Signal<string>;
    protected onRemoveClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiChip, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiChip, "ui-chip, button[ui-chip]", never, { "kind": { "alias": "kind"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; }, { "removed": "removed"; }, never, ["[uiChipIcon]"], true, never>;
}

type UiModalFooterLayout = 'default' | 'overflow' | 'stacked';
/**
 * `ui-modal` — the DLS 3.1 `modal` component (page 305:2697, set
 * 166757:32212, REGISTER.md §28, audited 3 Sep 2026): a
 * centred 600px DIALOG, distinct from `ui-modal-shell` (the full-viewport
 * FOCUS OVERLAY, §19). **TERMINOLOGY RULING (owner, 3 Sep 2026): "modal" =
 * this component, "focus overlay" = the shell — never conflate them.**
 * Neither component reads the other; this one is new, not grown onto the
 * shell, because their anatomy (backdrop-centred dialog vs full-viewport
 * panel-with-1200px-column) diverges too far to share a template.
 *
 *   @if (confirmOpen()) {
 *     <ui-modal title="Revoke access?" (dismissed)="confirmOpen.set(false)">
 *       <p>Aiko Mori loses desk access immediately.</p>
 *       <ui-checkbox uiModalFooterStart [(checked)]="ack">I understand</ui-checkbox>
 *       <button uiModalActions ui-button variant="secondary" size="small" (click)="confirmOpen.set(false)">Cancel</button>
 *       <button uiModalActions ui-button variant="primary" tone="destructive" size="small" (click)="revoke()">Revoke</button>
 *     </ui-modal>
 *   }
 *
 * (The checkbox/action markup above is illustrative placement, not a real
 * projection order requirement — `uiModalFooterStart`/`uiModalActions` are
 * attribute selectors, so the two can sit anywhere in the light DOM.)
 *
 * **Panel** (166757:32212) — `--color-bg-level2`, `--radius-md` (8),
 * `--shadow-elevation-5` (added to tokens.css this round, next to
 * elevation-4 — 0 0 1px .25 + 0 12px 24px .2), overflow clip, `width()`
 * (default 600, DLS's Desktop breakpoint) with a 328px floor (DLS's
 * Mobile breakpoint) as `min-width` rather than a second layout, since the
 * kit has no separate mobile shell for this component yet. `max-height`
 * caps the whole panel at 80vh so a tall body scrolls internally instead
 * of pushing the footer off-screen.
 *
 * **Header** (166757:32228) — 24h/16v padding, 1px
 * `--color-border-decorative` bottom rule, 12px gap: optional 24px status
 * icon in a 32px-min `[uiModalIcon]` wrapper (`hasIcon` gates the slot,
 * same explicit-flag pattern `ui-modal-shell` uses for its own icon disc —
 * Angular content queries cannot see inside an attribute-selector slot
 * from the outside, so auto-detecting "is anything projected" isn't
 * available here either), a text column (title `heading(sm)` 20/600
 * `--color-text-strong` on a 32px-min line; subtitle `body(md)` 14px
 * `--color-text-subtle`, 4px under), then `closable`'s 32px small
 * `ui-icon-button` close with a −4px optical right margin (same trim
 * `ui-modal-shell`'s `.ms-actions` already carries).
 *
 * **Body** (166757:32222) — 24/24 padding, 16px column gap (no DLS 16
 * gap step exists — same as `ui-modal-shell`'s content column, stays
 * raw), projected `<ng-content>`. `description` renders DLS's
 * "Description Only" slot (`body(md)` 14px `--color-text`) ahead of any
 * projected content, so a caller can combine a lead line with a custom
 * body rather than choosing one or the other.
 *
 * **Footer** (166757:32257) — 1px top rule, 24h/16v padding;
 * `<ng-content select="[uiModalFooterStart]">` (a caller's own
 * `ui-checkbox`) and `<ng-content select="[uiModalActions]">` (the
 * caller's own `ui-button`s, **Small per the compact ruling** — DLS shows
 * Medium 40, not built, §7). `footer` picks the DLS Footer Type:
 * `default` (checkbox flex-1 left + button group right, one row),
 * `overflow` (checkbox row stacked over a right-aligned button row) or
 * `stacked` (full-width buttons, DLS's mobile-only type). The footer
 * collapses to nothing when NEITHER slot has projected content — the
 * `:has(> .mf-start:empty):has(> .mf-actions:empty)` rule in modal.scss,
 * the same always-render-let-CSS-collapse trick `ui-drawer`'s
 * `.drawer-footer:empty` uses, extended with `:has()` because this footer
 * has two independent slots instead of one.
 *
 * **Dismissal** — Escape (document-level listener, same non-focus-owning
 * pattern `ui-modal-shell`/`ui-drawer` use) and a backdrop mousedown both
 * close when `closable()`; `closable` ALSO gates whether the close button
 * renders at all (false removes the affordance entirely — DLS's reading
 * for a modal a caller wants forced through to completion, no bail-out).
 * `dismissed` fires on every close path;
 * `open` is a `model()` so `[(open)]` mirrors it without a separate
 * boolean flag at the call site, and is also written directly so a
 * `(dismissed)`-only caller (the common case) doesn't have to.
 *
 * **Focus** — opening captures `document.activeElement` and moves focus
 * into the panel (its own `tabindex="-1"` root, since the DLS anatomy has
 * no single obvious default control); closing returns it to whatever had
 * focus before, so a "Revoke access" button reclaims focus after its own
 * confirm dialog closes rather than dropping focus to `<body>`. A
 * document-level Tab listener loops focus inside the panel while open —
 * neither `ui-modal-shell` nor `ui-drawer` had a reusable trap to import
 * (§19/§15 don't implement one; see their source), so this is a fresh,
 * minimal implementation rather than a port.
 */
declare class UiModal {
    open: _angular_core.ModelSignal<boolean>;
    title: _angular_core.InputSignal<string>;
    subtitle: _angular_core.InputSignal<string | undefined>;
    /** Gates the 32px `[uiModalIcon]` wrapper — projecting the slot alone renders nothing until this is set, same explicit-flag precedent `ui-modal-shell`'s `hasIcon` sets. */
    hasIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** DLS's "Description Only" body slot — kit `body(md)` 14px `--color-text`, ahead of any projected content. */
    description: _angular_core.InputSignal<string | undefined>;
    /** Desktop breakpoint default (166757:32212); DLS's 328 Mobile breakpoint is the floor via `min-width` in modal.scss rather than a second layout. */
    width: _angular_core.InputSignal<number>;
    /** DLS's Footer Type axis — `default` | `overflow` | `stacked`. See the class doc. */
    footer: _angular_core.InputSignal<UiModalFooterLayout>;
    /** Gates the close button AND Escape/backdrop dismissal — DLS's "no bail-out" reading for a modal a caller wants forced to completion. */
    closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    dismissed: _angular_core.OutputEmitterRef<void>;
    private readonly panel;
    private opener;
    constructor();
    protected onEscape(): void;
    protected onTab(event: KeyboardEvent): void;
    protected onBackdropMouseDown(event: MouseEvent): void;
    protected requestClose(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiModal, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiModal, "ui-modal", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "hasIcon": { "alias": "hasIcon"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "footer": { "alias": "footer"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "dismissed": "dismissed"; }, never, ["[uiModalIcon]", "*", "[uiModalFooterStart]", "[uiModalActions]"], true, never>;
}

type UiLoaderKind = 'partial' | 'spinner';
/**
 * Loader — the DLS 3.1 `loader` component (page 10392:69046,
 * REGISTER.md §27, audited 3 Sep 2026). DLS ships FOUR sets
 * (`loader-clover`, `loader-key`, `loader-partial`, `loader-skeleton`); the
 * two brand-mark tiles are DBS assets and not ours to replicate (the
 * skeleton set is `ui-skeleton`, next door). This component covers the
 * other two:
 *
 *   <ui-loader />                                    <!-- partial dots -->
 *   <ui-loader label="Loading transactions" />
 *   <ui-loader kind="spinner" />                      <!-- 48px tile -->
 *   <ui-loader kind="spinner" [background]="false" /> <!-- bare mark -->
 *   <ui-loader invert />                              <!-- on a dark/dim surface -->
 *
 * **`partial`** (default, DLS `loader-partial` 96939:279615): three 8px
 * circles, 8px gap, `--color-icon` fill at opacity 1 / .6 / .2 — the SAME
 * three values `ui-button`'s `[loading]` state already draws (button.scss),
 * kept identical here so a standalone loader and an in-button one read as
 * the same object. Unlike the button's dots (which stay static — the
 * button's own Pressed fill already reads as "busy"), a free-standing
 * loader gets DLS's gentle opacity cycle: each dot cross-fades through the
 * same three steps on a staggered delay, off by default under
 * `prefers-reduced-motion: reduce` (wrapped in the `no-preference` query,
 * same pattern tokens.css's own tactile-press rule uses) — the STATIC
 * opacities are the base CSS regardless of motion setting, so a
 * reduced-motion viewer still sees the three-step read, just without the
 * cross-fade.
 *
 * **`spinner`** (DLS `loader-clover`/`loader-key`, 14413:137934 /
 * 151423:3541): a 48px tile (radius 8, DLS bg `level_3`; this kit's token
 * ladder stops at `--color-bg-level2` — both resolve to white today, so
 * `--color-bg-level2` is the nearest existing step, reported here rather
 * than adding a `level_3` token for a same-value alias) holding a 32px
 * animated mark, `--shadow-elevation-3`. `[background]="false"` drops the
 * tile (DLS's Background=No), leaving just the 32px mark. The DBS clover
 * / key glyphs are brand assets this kit does not carry — `[uiLoaderMark]`
 * is the projection seam for a caller's own mark; the DEFAULT (unprojected)
 * mark is a neutral white-label spinner: a 32px ring, `--color-primary`
 * stroke, rotating — off under reduced motion (frozen at its rest frame,
 * same query pattern as the dots).
 *
 * **Label** (both kinds) — optional, 4px under the dots/tile, kit
 * `body(sm)` (13px — DLS prints this role at 14; the platform's standing
 * compactness override, same call as `ui-button` and `ui-empty-state`,
 * keeps it at 13), `--color-text-subtle`.
 *
 * **`invert`** — for a loader sitting on a dim/dark surface (the Primary
 * Nav, a dark card). DLS's own Invert reading uses `icon-inverse`; this
 * kit has no dedicated inverse ICON token (`--color-icon-inverse` does not
 * exist in tokens.css — grepped before writing this), so the dots fall
 * back to `--color-text-on-dim` (#ffffff, the kit's existing "text on a
 * dim/inverse surface" token) as the nearest on-hand substitute — reported
 * here rather than silently reaching for an unrelated token. The label DOES
 * have an exact match: `--color-text-on-dim-subtle` (#9ba4ab), DLS's real
 * "subtle text on dim" role.
 *
 * `role="status"` / `aria-live="polite"` on the host; `aria-label` is the
 * `label` input when set, else "Loading" — both dot/tile markup is
 * `aria-hidden` so the label (visible or the fallback) is what a screen
 * reader announces once, not per-frame.
 *
 * RESKIN: delegate to `dbs-loader`; the clover/key marks are DBS's own —
 * point `[uiLoaderMark]`'s default at nothing and let the DLS component's
 * own brand mark render, or keep projecting this kit's neutral ring if the
 * white-label build should stay brand-neutral even under the real DLS.
 */
declare class UiLoader {
    kind: _angular_core.InputSignal<UiLoaderKind>;
    label: _angular_core.InputSignal<string | undefined>;
    invert: _angular_core.InputSignal<boolean>;
    /** Spinner only — DLS's Background axis. Ignored for `kind="partial"`. */
    background: _angular_core.InputSignal<boolean>;
    protected readonly showTile: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiLoader, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiLoader, "ui-loader", never, { "kind": { "alias": "kind"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "invert": { "alias": "invert"; "required": false; "isSignal": true; }; "background": { "alias": "background"; "required": false; "isSignal": true; }; }, {}, never, ["[uiLoaderMark]"], true, never>;
}

type UiSkeletonType = 'text' | 'image-text' | 'image';
/**
 * Skeleton — the DLS 3.1 `loader-skeleton` component (Figma 14415:138020,
 * REGISTER.md §27, audited 3 Sep 2026). A `level_2` card
 * (radius 8, `--shadow-elevation-2`) with a fixed header and a body that
 * varies by `type`:
 *
 *   <ui-skeleton type="text" />        <!-- three bars, default -->
 *   <ui-skeleton type="image-text" />  <!-- 112 square + two bars -->
 *   <ui-skeleton type="image" />       <!-- 207 full-bleed block -->
 *
 * **Header** (every type): 24px h / 16px v padding, a bottom 1px
 * `--color-border-decorative` rule, one 16px-tall bar capped at 241px wide
 * (40% on anything narrower — DLS's own cap reading).
 *
 * **Body — `text`** (default): 24/24 padding, 8px gap, three 24px bars on
 * DLS's 4-column / 32px-gap grid: full width, then 3-of-4 columns (~75%),
 * then full width again.
 *
 * **Body — `image-text`**: a 112px square beside a column of two bars
 * (full width, then ~75%) — the same text pairing, run alongside a
 * thumbnail instead of alone.
 *
 * **Body — `image`**: a single 207px block, full width, flush to the
 * card's own rounded bottom corners (no body padding for this type — the
 * card clips via `overflow: hidden` so the block's square corners still
 * read as rounded).
 *
 * **Gradient** — every bar (`ui-skeleton-bar`, next to this file) sweeps
 * left→right: DLS prints `alt #f7f7f7 → pressed #dde3e7 → alt`; this kit's
 * `--color-bg-alt` (#f7f7f7) and `--color-bg-pressed` (#dde3e7) are exact
 * hex matches, not substitutions. Shimmer via `background-position`,
 * reduced-motion aware (frozen, not hidden).
 *
 * `aria-busy="true"` on the host; every bar and the card chrome are
 * `aria-hidden` — a skeleton has nothing for a screen reader to read out
 * frame-by-frame, the surrounding loading state (`ui-loader`'s
 * `aria-live` region, or a caller's own status text) is what announces it.
 *
 * RESKIN: delegate to `dbs-loader` Type=Skeleton; keep selector + `type`.
 */
declare class UiSkeleton {
    type: _angular_core.InputSignal<UiSkeletonType>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiSkeleton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiSkeleton, "ui-skeleton", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Bare skeleton bar — the shimmer primitive `ui-skeleton` composes into its
 * header/body anatomy below. Exposed standalone so a caller can build a
 * custom skeleton shape DLS's three fixed `ui-skeleton` types don't cover
 * (REGISTER.md §27):
 *
 *   <ui-skeleton-bar width="60%" height="16px" />
 *   <ui-skeleton-bar width="120px" />   <!-- height defaults to 24 -->
 *
 * Same gradient as every bar inside `ui-skeleton`: a left→right sweep,
 * `--color-bg-alt` → `--color-bg-pressed` → `--color-bg-alt`, animated via
 * `background-position` (reduced-motion aware — frozen, not hidden, under
 * `prefers-reduced-motion: reduce`).
 */
declare class UiSkeletonBar {
    width: _angular_core.InputSignal<string>;
    height: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiSkeletonBar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiSkeletonBar, "ui-skeleton-bar", never, { "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type UiLinkVariant = 'product' | 'subtle' | 'text' | 'on-dim';
/**
 * DLS `Link` (set 51914:259512, REGISTER.md §25, audited
 * 3 Sep 2026) — an inline text link, Variant Product | Subtle | Text | On
 * dim × State Default | Hover | Focus. Applied as an attribute so native
 * semantics stay intact, same house pattern as `ui-button`:
 *
 *   <a ui-link href="/audit-log">View history</a>
 *   <button ui-link type="button" variant="subtle" (click)="cancel()">Cancel</button>
 *   <a ui-link variant="product" [external]="true" href="https://…">DBS.com</a>
 *   <a ui-link variant="on-dim" href="#">Help &amp; feedback</a>
 *
 * **Anatomy**: inline text at the kit's `type.body('sm')` — 13px/400/1.5,
 * the standing "kit text sizes" ruling (DLS prints body/sm as 14; this kit's
 * body/sm step is 13 and link deliberately does not chase the DLS number,
 * same call as `ui-button`'s label(sm) doc). The underline is a SEPARATE
 * 1px full-width rule under the text, not `text-decoration` — DLS draws it
 * as its own bottom stroke so it sits at a fixed offset regardless of the
 * font's own descenders. Implemented here as the host's `border-bottom`
 * (1px solid, same colour as the text) rather than a nested underline
 * element: a link's projected content can be arbitrary inline content
 * (a `<button ui-link>`'s single text node, or an `<a>`'s), and a
 * `border-bottom` gets the "full width of the text, redrawn instantly on
 * colour change" behaviour for free without adding a wrapper span around
 * caller content.
 *
 * **Colours** (Variant → Default → Hover). DLS: Product text-product_alt
 * #ff3e3e → hover product_alt-hover #cf2929; Subtle text-subtle #69737b →
 * hover text-hover #303c44; Text text #455057 → hover #303c44; On dim
 * on_dim-strong white → hover on_dim-hover #c7cfd5. This kit's white-label
 * seam maps DLS's red product_alt onto `--color-primary` (the same seam
 * `ui-button`'s Primary variant uses), so:
 *
 *   product → `--color-primary` → hover `--color-primary-hover` (token
 *     exists, on-spec — the same pair the Primary button variant uses).
 *   subtle  → `--color-text-subtle` → hover — **no `--color-text-hover`
 *     token exists in tokens.css**; falls back to `--color-text-strong`
 *     (a real, close, GAP — see the round's report for the exact line).
 *   text    → `--color-text-body` (this kit's nearest existing token to
 *     DLS's plain-text role #455057; there is no bare `--color-text`) →
 *     hover — same fallback as subtle, `--color-text-strong` (DLS itself
 *     gives both roles the same #303c44 hover, so one fallback token for
 *     both keeps that parity even though tokens.css has no exact match).
 *   on-dim  → `--color-text-on-dim` → hover — **no
 *     `--color-text-on-dim-hover` token exists** (the DLS value #c7cfd5
 *     is not present as any token in tokens.css, though it coincides with
 *     `--color-border-disabled` / `--color-icon-disabled` — a border/icon
 *     role, not text); falls back to `--color-text-on-dim-subtle`
 *     (#9ba4ab) as the nearest existing ON-DIM TEXT role token — GAP, see
 *     the round's report.
 *
 * No token was invented and none of tokens.css was edited (owned by
 * another agent this round, per brief).
 *
 * **Focus** (`:focus-visible`): 2px solid `--color-focus` ring, radius 4,
 * wrapping the text AND the underline — drawn as an outset box-shadow
 * (not inset, unlike `ui-button`) since a link has no fill to protect and
 * the ring needs to clear the underline sitting just under the text. No
 * colour change on focus, matching DLS. Hover and focus are independent:
 * hover's colour rule is written with `:not(:focus-visible)` so a
 * keyboard-focused, mouse-hovered link keeps its focus ring without the
 * hover rule fighting it for specificity.
 *
 * **External**: `external` input appends the DLS "Relevant Links" pattern's
 * `↗` glyph after the label, as a real `aria-hidden` span
 * (`.ui-link-ext`) — not a pseudo-element, so it participates in normal
 * text flow/underline like the rest of the label.
 *
 * RESKIN: delegate to the DLS Angular `link` component; keep this
 * selector and the `variant` / `external` inputs unchanged.
 */
declare class UiLink {
    /** DLS's Variant axis — see the class doc for the colour ladder. */
    variant: _angular_core.InputSignal<UiLinkVariant>;
    /** DLS "Relevant Links" pattern — appends a real, aria-hidden `↗` glyph. */
    external: _angular_core.InputSignal<boolean>;
    protected hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiLink, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiLink, "a[ui-link], button[ui-link]", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "external": { "alias": "external"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * Marks the projected header block of `ui-nav-rail` — the 72px row holding
 * the logo mark (collapsed/with-labels) or mark + wordmark (expanded).
 * A pure content-projection marker, no behaviour of its own.
 *
 *   <div uiNavRailHeader>…mark + wordmark…</div>
 */
declare class UiNavRailHeader {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavRailHeader, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<UiNavRailHeader, "[uiNavRailHeader]", never, {}, {}, never, never, true, never>;
}
/**
 * Marks the projected footer block of `ui-nav-rail` — sticky, 1px top rule,
 * 8px top / 16px bottom padding (nav-rail.scss). Everything else (help,
 * notifications, profile, collapse toggle) is the consumer's own
 * `ui-nav-rail-item` rows projected inside it.
 *
 *   <div uiNavRailFooter>…footer items…</div>
 */
declare class UiNavRailFooter {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavRailFooter, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<UiNavRailFooter, "[uiNavRailFooter]", never, {}, {}, never, never, true, never>;
}
/**
 * DLS `nav-side-primary` (set 192450:1049, REGISTER.md §29,
 * audited 3 Sep 2026) — the dark left rail's OUTER FRAME: the 900-tall
 * column, its three width states, and the header/body/footer slots. The
 * anatomy INSIDE those slots — items, sections, rules — is
 * `ui-nav-rail-item` / `ui-nav-rail-section` / `ui-nav-rail-rule`
 * (siblings in this directory); this component owns only the shell.
 *
 *   <ui-nav-rail [expanded]="expanded()">
 *     <div uiNavRailHeader>…mark [+ wordmark]…</div>
 *     <ui-nav-rail-item …></ui-nav-rail-item>
 *     …
 *     <div uiNavRailFooter>…footer items…</div>
 *   </ui-nav-rail>
 *
 * Three width states, all driven off two boolean inputs (not an enum —
 * `withLabels` is an ADDITIVE compact type in the DLS set, not a third
 * point on the same axis as `expanded`, so the two are independent flags
 * exactly as the Figma component's own two axes are):
 * - default (`expanded=false`, `withLabels=false`): **72px**, icon-only.
 * - `expanded=true`: **240px**, icon + label rows, `Section` rows visible.
 * - `withLabels=true`: **88px**, the "With labels" compact type — 64-tall
 *   `ui-nav-rail-item[kind=compact]` rows, icon + label stacked. Takes
 *   priority over `expanded` in the stylesheet (nav-rail.scss) since the
 *   two are not meant to combine in the Figma set.
 *
 * Body scrolls independently of the fixed header/footer (`flex: 1`,
 * `overflow-y: auto`) — same shape as `ui-nav-panel`'s body.
 */
declare class UiNavRail {
    /** Default `false` — 72px icon-only rail. */
    expanded: _angular_core.InputSignal<boolean>;
    /** The 88px "With labels" compact type. Wins over `expanded` when both are set. */
    withLabels: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavRail, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiNavRail, "ui-nav-rail, nav[ui-nav-rail]", never, { "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "withLabels": { "alias": "withLabels"; "required": false; "isSignal": true; }; }, {}, never, ["[uiNavRailHeader]", "*", "[uiNavRailFooter]"], true, never>;
}

type UiNavRailItemKind = 'default' | 'profile' | 'abbreviation' | 'compact';
/**
 * DLS `nav-side/item` (REGISTER.md §29, audited 3 Sep 2026) —
 * the primary rail's row. Applied as an attribute on the host element the
 * consumer already owns for navigation (`<button>` for an action,
 * `<a>` for a routed link) — same convention as `[ui-nav-sub-item]` — so the
 * shell keeps full control of click/routerLink wiring and its own `class`
 * list (the `.item` class the e2e suite locates on, see nav-rail.ts in the
 * shell).
 *
 *   <button ui-nav-rail-item kind="default" label="Home" [expanded]="expanded()">
 *     <svg uiNavRailIcon …></svg>
 *   </button>
 *   <button ui-nav-rail-item kind="profile" label="Aiko Mori" [expanded]="expanded()" avatarColour="goji" />
 *   <button ui-nav-rail-item kind="compact" label="Home"><svg uiNavRailIcon …></svg></button>
 *
 * Anatomy: a 56×56 **indicator** (72px rail width minus 2×8px side pad)
 * holding a 24×24 glyph box — `<ng-content select="[uiNavRailIcon]">` for
 * `kind="default"`, a 24px `ui-avatar` for `kind="profile"`, or a 24px
 * initials tile for `kind="abbreviation"` — then, when `expanded()` is true,
 * a `label` at kit `label(sm)` 13/500 `--color-text-on-dim-subtle` (white
 * when `active`). `kind="compact"` (the 88px "With labels" rail) stacks
 * icon over a centred `label(2xs)` 10px caption instead, 64px tall, 12px
 * v-pad — driven by one CSS class swap (`.ui-nav-rail-item-compact`,
 * nav-rail-item.scss), not a second template.
 *
 * States: hover `--color-bg-on-dim-hover` #455057; **active = a full-width
 * band** `--color-bg-on-dim-pressed` #59656d with NO radius (DLS spec, not
 * the old 44px rounded row); `:focus-visible` a 2px inset `--color-focus`
 * ring; `disabled` dims text/icon and blocks pointer events.
 *
 * `badge` overlays the existing rail's notification chip on the glyph —
 * same offsets/anchoring as the pre-kit `.item-icon`/`.item-badge` pair
 * (see nav-rail-item.scss for the geometry rationale, ported verbatim).
 *
 * The glyph box and label span also carry the pre-kit `.item-icon` /
 * `.item-label` classes alongside their new `.rail-item-*` names — several
 * e2e specs (f20/f23/f24) locate on those class names directly rather than
 * through the shell's own `.item` wrapper, so this component keeps both
 * rather than requiring every spec to be rewritten for a purely internal
 * rename.
 */
declare class UiNavRailItem {
    kind: _angular_core.InputSignal<UiNavRailItemKind>;
    /** Visible row text — also the `profile`/`abbreviation` name source. */
    label: _angular_core.InputSignal<string>;
    /** Whether the rail is wide enough to show `label` (ignored for `compact`,
     *  which always shows its centred caption). */
    expanded: _angular_core.InputSignal<boolean>;
    active: _angular_core.InputSignal<boolean>;
    disabled: _angular_core.InputSignal<boolean>;
    /**
     * A parent row WITH sub-items (DLS 192450:1227 / 192450:1179). Changes only
     * the SELECTED tone: `group && active` bands `--color-bg-dim-hover` #303c44
     * (dim_alt) instead of the leaf `--color-bg-on-dim-pressed` #59656d, and its
     * hover stays the ordinary `--color-bg-on-dim-hover` #455057 rather than
     * holding the pressed tone (nav-rail-item.scss). Leaf items are unaffected.
     */
    group: _angular_core.InputSignal<boolean>;
    /** Notification count, or `null`/omitted for no badge at all. */
    badge: _angular_core.InputSignal<number | null>;
    avatarColour: _angular_core.InputSignal<"goji" | "ginger" | "lemon" | "lime" | "melon" | "mint" | "lavender" | "acai" | "goji-ginger" | "ginger-lemon" | "lemon-lime" | "lime-melon" | "melon-mint" | "mint-lavender" | "lavender-acai" | "acai-goji">;
    /** `kind="abbreviation"` only — defaults to `label`'s initials. */
    abbreviation: _angular_core.InputSignal<string>;
    protected readonly initials: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavRailItem, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiNavRailItem, "button[ui-nav-rail-item], a[ui-nav-rail-item]", never, { "kind": { "alias": "kind"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "group": { "alias": "group"; "required": false; "isSignal": true; }; "badge": { "alias": "badge"; "required": false; "isSignal": true; }; "avatarColour": { "alias": "avatarColour"; "required": false; "isSignal": true; }; "abbreviation": { "alias": "abbreviation"; "required": false; "isSignal": true; }; }, {}, never, ["[uiNavRailIcon]", "[uiNavRailTrailing]"], true, never>;
}

/**
 * DLS `nav-side/sub-item` — Action row (REGISTER.md §29). A
 * group's child row in the expanded (240px) rail only — collapsed/with-
 * labels rails never show sub-items, same as the pre-kit rail's
 * `[collapsed] .sub-item { display: none }` behaviour (now simply: the shell
 * never renders these rows when the rail isn't expanded).
 *
 *   <a ui-nav-rail-sub-item label="Profile & Mandates" [active]="isChildActive(child)"></a>
 *
 * 12px h-pad, 8px v-pad, radius `panel-md` 4px, `label(sm)` 13/500
 * `--color-text-on-dim-subtle` — white + `--color-bg-on-dim-pressed` when
 * `active`, `--color-bg-on-dim-hover` on hover. 240px wide.
 */
declare class UiNavRailSubItem {
    label: _angular_core.InputSignal<string>;
    active: _angular_core.InputSignal<boolean>;
    disabled: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavRailSubItem, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiNavRailSubItem, "button[ui-nav-rail-sub-item], a[ui-nav-rail-sub-item]", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * DLS `nav-side/item` "Section" row (REGISTER.md §29) — a
 * 32px-min group heading between items in the expanded rail: 8px h-pad +
 * a 16px left inset, 4px v-pad, uppercase `label(2xs)` 10px/500
 * `--color-text-on-dim-subtle`. The shell only mounts this row when the
 * rail is expanded (Section rows have no collapsed/with-labels
 * representation — DLS shows a bare `Rule` there instead, `ui-nav-rail-rule`).
 *
 *   <div ui-nav-rail-section label="Workspace"></div>
 */
declare class UiNavRailSection {
    label: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavRailSection, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiNavRailSection, "div[ui-nav-rail-section]", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * DLS `nav-side/item` "Rule" row (REGISTER.md §29) — a 32px-min
 * divider row holding a centred 1px hairline `--color-border-dim`. 56px wide
 * when collapsed/with-labels (mirrors the 56px indicator it sits under);
 * full width minus 8px side pads when the rail is expanded.
 *
 *   <div ui-nav-rail-rule [expanded]="expanded()"></div>
 */
declare class UiNavRailRule {
    expanded: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavRailRule, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiNavRailRule, "div[ui-nav-rail-rule]", never, { "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Marks the optional section label projected into `ui-nav-rail-flyout`
 * (DLS "SECTION row": 32px min, 12px h-pad / 4px v-pad, label/2xs 10px
 * uppercase `--color-text-on-dim-subtle`).
 *
 *   <ui-nav-rail-flyout>
 *     <span uiNavRailFlyoutSection>Workspace</span>
 *     <button ui-nav-rail-sub-item …></button>
 *   </ui-nav-rail-flyout>
 */
declare class UiNavRailFlyoutSection {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavRailFlyoutSection, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<UiNavRailFlyoutSection, "[uiNavRailFlyoutSection]", never, {}, {}, never, never, true, never>;
}
/**
 * DLS collapsed-rail flyout (REGISTER.md §29, 192450:1179 —
 * Expand=No, Selected, Sub-items=Yes): the panel a collapsed GROUP item's
 * sub-items appear in, since the 72px rail has no room to show them inline.
 *
 *   <div class="item-wrap">
 *     <button ui-nav-rail-item [group]="true" …></button>
 *     <ui-nav-rail-flyout>
 *       <button ui-nav-rail-sub-item …></button>
 *     </ui-nav-rail-flyout>
 *   </div>
 *
 * 240px wide, `--color-bg-dim-hover` (dim_alt #303c44 — same tone as the
 * collapsed selected parent band, DLS 192450:1179), radius 8
 * (`--radius-md`), `--shadow-elevation-4`, 12px h / 8px v padding.
 *
 * `position: fixed`, positioned in JS off `getBoundingClientRect()` of the
 * host's own DOM PARENT (the consumer's wrapper — `.item-wrap` in the
 * shell — read directly, no `anchor` input needed since this component is
 * always rendered as that wrapper's child) — NOT `position: absolute`
 * against a `position: relative` wrapper, which is what shipped first and
 * broke: the rail body scrolls (`overflow-y: auto`), and the CSS spec
 * forces `overflow-x: hidden` on an ancestor whenever `overflow-y` is
 * `auto` (register §29's "flex-shrink / overflow-hidden trap"), so an
 * absolutely-positioned panel measured correctly but was painted CLIPPED —
 * `document.elementFromPoint` at its centre hit the page behind it, and a
 * real click on a sub-item fell through and navigated the page instead
 * (lead's first live-app finding, 3 Sep 2026). `position: fixed` escapes
 * that clip entirely (its containing block is the viewport, not any
 * scrolling ancestor).
 *
 * VISIBILITY is fully JS-owned — NOT a CSS `.item-wrap:hover
 * .ui-nav-rail-flyout { display: flex }` rule. That was the second thing
 * that shipped and broke: the wrapper's own `::after` hover-bridge (meant
 * to keep `:hover` alive across the 8px gap to this now-`fixed` panel) is
 * ALSO a descendant of the same `overflow-x: hidden` rail body, so it was
 * clipped exactly like the panel itself — `elementFromPoint` in the bridge
 * zone hit the page, not the bridge, `.item-wrap:hover` never went true
 * past the row's own edge, and the panel could never be reached (lead's
 * SECOND live-app finding, same session). Instead: `mouseenter`/`focusin`
 * on the anchor (native listeners — Angular's `(mouseenter)` binding only
 * reaches the HOST, not an arbitrary DOM ancestor) opens the panel and
 * repositions it; `mouseleave`/`focusout` on EITHER the anchor or the panel
 * itself schedules a close after `CLOSE_DELAY_MS`, cancelled if the pointer
 * (or focus) lands back on either before it fires — that delay is what
 * survives the gap-crossing instant when the pointer is over neither.
 */
declare class UiNavRailFlyout implements AfterViewInit, OnDestroy {
    /** Demo-only visibility override (kitchen sink §29) — forces the panel
     *  open for measurement without simulating a real hover; ORed with the
     *  real `isOpen` state, so it never fights a genuine hover/focus. */
    open: _angular_core.InputSignal<boolean>;
    protected readonly isOpen: _angular_core.WritableSignal<boolean>;
    private readonly elementRef;
    private closeTimer;
    private readonly onAnchorEnter;
    private readonly onAnchorLeave;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /** Pointer/focus landed on the panel itself — cancel any pending close
     *  from having left the anchor row a moment ago. */
    protected onPanelEnter(): void;
    protected onPanelLeave(): void;
    private show;
    private scheduleClose;
    private cancelClose;
    private reposition;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiNavRailFlyout, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiNavRailFlyout, "ui-nav-rail-flyout", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; }, {}, never, ["[uiNavRailFlyoutSection]", "*"], true, never>;
}

type UiQuicklinkDirection = 'vertical' | 'horizontal';
type UiQuicklinkSize = 'small' | 'medium' | 'large';
/**
 * Quicklink — the DLS 3.1 `quicklink` component (page 5401:31769, set
 * 6567:50541, REGISTER.md §33, audited/built round 30–34,
 * 3 Sep 2026). A round icon-tile shortcut, two directions:
 *
 *   <button ui-quicklink label="Local Transfer">
 *     <svg uiQuicklinkIcon>…24px glyph…</svg>
 *   </button>
 *   <button ui-quicklink size="large" badge="New" label="FX Swap">
 *     <svg uiQuicklinkIcon>…24px glyph…</svg>
 *   </button>
 *   <a ui-quicklink direction="horizontal" href="/transfers">
 *     <svg uiQuicklinkIcon>…16px glyph…</svg>
 *     Transfer
 *   </a>
 *
 * Applied as an attribute on a native `<button>`/`<a>` so click/keyboard/
 * routerLink semantics stay with the caller — same house pattern as
 * `ui-card-button` / `ui-fab` / `ui-nav-rail-item`.
 *
 * **Direction "Vertical"** (7970:59609 etc.) — an 80px-wide column, 4px
 * gap: a pill-circle **tile** (`--color-primary-subtle` bg, a projected
 * 24px icon in `--color-primary`) sized by `size` (`small` 40 |
 * `medium` 48 (default) | `large` 56 — the Figma sticky note's S/M/L maps
 * straight onto this input, no renaming), then a centred, two-line-
 * wrapping `label(sm)` (13px/500, `--color-text-body`).
 *
 * **Direction "Horizontal (new)"** (228273:337) — the DLS pill: host bg
 * `--color-bg-level2`, `--shadow-elevation-2`, pill radius, 4px left /
 * 8px right / 4px vertical padding, 8px gap, a 32px tile holding a 16px
 * icon (same tile tint, scaled down via CSS — see quicklink.scss), then
 * the same `label(sm)`. `size` is ignored here — DLS gives the pill no
 * size axis, only the vertical direction has one. The DLS "Horizontal
 * (old)" pill (a 40px tile, 8 gap) is superseded per the Figma set and is
 * not built — owner ruling, see the gap register entry.
 *
 * **Icon** — `<ng-content select="[uiQuicklinkIcon]">`, expected to paint
 * with `currentColor`. Sized via `::ng-deep` in quicklink.scss (the
 * projected-content trap `ui-button`/`ui-fab`/`ui-card-button` all
 * document: a plain scoped rule can never reach content projected from
 * the CALLER's template, since it carries the caller's own encapsulation
 * attribute, not this host's).
 *
 * **Label** — `label` input, OR plain projected text (the horizontal pill
 * in particular reads naturally as `<a ui-quicklink>…icon…Transfer</a>`).
 * When `label` is set it wins; otherwise the default `<ng-content />`
 * carries whatever text the caller placed after the icon.
 *
 * **Badge** — optional `badge` string (DLS's "New" marker), rendered via
 * `ui-badge` `emphasis="high"` (16px pill, `--color-bg-danger-strong`,
 * white `label(xs)` 12px — exactly the DLS geometry, no new CSS needed;
 * see badge.ts). Vertical only — the DLS set positions it at the tile's
 * top-right corner and gives two different anchor formulas depending on
 * size:
 *
 * - **Large**: "left 32 / bottom 44" of the 80×80 tile FRAME (not the 56px
 *   tile alone) — implemented as an absolutely-positioned child of the
 *   80px column host itself (`position: relative` on `:host`), so
 *   `left: 32px; bottom: 44px` lands exactly where the Figma frame draws
 *   it regardless of how many label lines follow.
 * - **Medium/Small**: "centred at 50% + 18.5px, top −4" — implemented
 *   relative to the tile circle itself (`position: relative` on
 *   `.ql-tile`), so `left: calc(50% + 18.5px); top: -4px`, independent of
 *   the tile's own diameter (DLS gives ONE formula for both sizes).
 *
 * Both read as "overlapping the tile's upper-right edge," which is the
 * qualitative spec; the exact node coordinates in the Figma set could not
 * be independently re-measured this round (no live Figma session), so
 * these are DLS_GAP_REGISTER §33's numbers applied literally.
 *
 * **States** (both directions): hover tile `--color-primary-subtle-hover`
 * + label `--color-text-strong` (pill: host bg `--color-bg-hover`);
 * pressed tile pressed tint (pill: host `--color-bg-pressed`); focus-
 * visible = 2px solid `--color-focus` ring on the tile (vertical) / on
 * the pill (horizontal), inset so there's no layout shift — same recipe
 * `ui-card-button`/`ui-fab` use; disabled = tile `--color-bg-disabled`,
 * icon + label `--color-text-disabled`, no hover. Hover rules are written
 * `:not(:focus-visible)` so a keyboard-focused, mouse-hovered link keeps
 * its focus ring instead of the hover tint fighting it for specificity.
 *
 * Pressed uses `--color-primary-subtle-pressed` (#b3d5f0), added by the
 * lead in the round-38 second pass as the white-label analog of DLS's
 * product-subtle-pressed — the agent had reused the hover tint while the
 * tokens file was another agent's.
 *
 * RESKIN: delegate to the DLS Angular quicklink; keep this selector and
 * the `direction`/`size`/`label`/`badge`/`disabled` inputs.
 */
declare class UiQuicklink {
    /** DLS's Direction axis. */
    direction: _angular_core.InputSignal<UiQuicklinkDirection>;
    /** DLS's Size axis — vertical direction only, ignored by the pill. */
    size: _angular_core.InputSignal<UiQuicklinkSize>;
    /** Visible text. Falls back to plain projected content when omitted. */
    label: _angular_core.InputSignal<string | undefined>;
    /** DLS "New" marker text, or omitted for no badge. Vertical only. */
    badge: _angular_core.InputSignal<string | undefined>;
    disabled: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiQuicklink, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiQuicklink, "button[ui-quicklink], a[ui-quicklink]", never, { "direction": { "alias": "direction"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "badge": { "alias": "badge"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, ["[uiQuicklinkIcon]", "*"], true, never>;
}

/**
 * Dot pagination — the DLS 3.1 `dot-pagination` component (Figma
 * 91374:316329, REGISTER.md §30, audited/built 3 Sep 2026):
 * 3–8 8px dots, 8px gap, Active / Inactive. Carousel indicator — no call
 * site in this app today (archive candidate per the owner's round ruling),
 * demoed in the kitchen sink only.
 *
 *   <ui-dot-pagination [count]="5" [(index)]="slide" />
 *
 * Active dot fills `--color-primary` (DLS uses the product colour, same
 * as every other product-tinted control in this kit). Inactive: DLS
 * specs `--color-bg-neutral` (#dde3e7) — this kit's token ladder has no
 * `--color-bg-neutral` name (grepped tokens.css before writing this); the
 * nearest EXISTING token at the same hex is `--color-bg-pressed`
 * (#dde3e7), used here rather than inventing a new alias — reported in
 * the round notes.
 *
 * Each dot is a real `<button>` with its own `aria-label` ("Go to slide
 * N") — a REAL click selects it (`index.set(i)`), not a decorative div.
 *
 * RESKIN: delegate to the DLS Angular dot-pagination component; keep the
 * selector and both inputs.
 */
declare class UiDotPagination {
    /** 3–8 per the DLS set. */
    count: _angular_core.InputSignal<number>;
    index: _angular_core.ModelSignal<number>;
    protected dots: _angular_core.Signal<unknown[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiDotPagination, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiDotPagination, "ui-dot-pagination", never, { "count": { "alias": "count"; "required": false; "isSignal": true; }; "index": { "alias": "index"; "required": false; "isSignal": true; }; }, { "index": "indexChange"; }, never, never, true, never>;
}

type UiPopoverFooterLayout = 'default' | 'stacked' | 'right';
type UiPopoverPlacement = 'bottom-start' | 'bottom-end' | 'top-start' | 'top-end';
/**
 * `ui-popover` — the DLS 3.1 `popover` component (page 3260:1, set
 * 185246:2611, REGISTER.md §31, audited 3 Sep 2026): a 360px
 * `--color-bg-level3` panel anchored to a trigger, with header / body /
 * footer slots. A DIFFERENT DLS component from `ui-coachmark` (§12, a dark
 * onboarding-tour panel with its own step chrome and NO trigger-anchoring
 * of its own) — do not conflate the two. Owner decision (round §30–§34,
 * 3 Sep 2026): build with a sink demo only, no consumer wired yet.
 *
 *   <ui-popover title="フィルター" [(open)]="filtersOpen">
 *     <button uiPopoverTrigger ui-button variant="secondary" size="small">開く</button>
 *     <p>Body content projects here.</p>
 *     <ui-checkbox uiPopoverFooterStart [(checked)]="ack">同意する</ui-checkbox>
 *     <button uiPopoverActions ui-button variant="secondary" size="small" (click)="filtersOpen.set(false)">キャンセル</button>
 *     <button uiPopoverActions ui-button variant="primary" size="small" (click)="apply()">適用</button>
 *   </ui-popover>
 *
 * **Panel** (185246:2611) — `width()` (default 360), `--color-bg-level3`,
 * `--radius-md` (8), `--shadow-elevation-3`. Positioned `fixed` (not the
 * host-relative `absolute` `ui-date-input`'s popovers use) so it can never
 * be clipped by an `overflow: hidden` ancestor between the trigger and the
 * viewport edge, since this component has no fixed call site yet to prove
 * that ancestor doesn't exist. `ui-dropdown-menu` (§16) has no shared
 * positioning utility to import — every existing consumer (kebab-menu,
 * multi-select, date-input) places its own panel with a hand-placed
 * `position: absolute` and no flip logic — so the flip-aware placement
 * below is a fresh, minimal implementation, not a port.
 *
 * **Header** (89992:316128) — 16px h / 12px v padding, `title` at the kit
 * heading(2xs) 14/600 `--color-text-strong` (DLS prints heading/2xs 16 —
 * the standing compactness ruling keeps this role 14px everywhere else it
 * appears, same as `ui-modal`'s title and `ui-coachmark`'s). Omitted
 * entirely (no empty band) when `title` is unset.
 *
 * **Body** — 16px h-pad, 16px bottom padding, 0 top when a header
 * precedes it (the header's own 12px bottom padding supplies the visual
 * gap) or 16px top with no header, projected `<ng-content>`.
 *
 * **Footer** (166757:32936) — 1px `--color-border-decorative` top rule,
 * 16h/12v padding, 8 gap; `footer` picks the DLS Type: `default` (a
 * `[uiPopoverFooterStart]` checkbox row, 40px min, above a two-column
 * EQUAL-WIDTH grid of `[uiPopoverActions]` buttons), `stacked` (full-width
 * buttons, one per row) or `right` (a right-packed row, no grid). Buttons
 * project in at kit Small per the compact ruling — DLS shows Medium 40,
 * not built here, same call `ui-modal`'s footer already makes. The whole
 * footer collapses when NEITHER slot has projected content — the
 * `:has(> .pf-start:empty):has(> .pf-actions:empty)` rule in popover.scss,
 * the same always-render-let-CSS-collapse trick `ui-modal`'s footer uses.
 *
 * **Trigger** — a projected `<ng-content select="[uiPopoverTrigger]">`;
 * clicking anywhere inside it toggles `open`. `role="dialog"` on the
 * panel, `aria-labelledby` the title when set, else the `ariaLabel` input.
 *
 * **Dismissal** — Escape (document-level listener, same non-focus-owning
 * pattern `ui-modal`/`ui-modal-shell`/`ui-drawer` use) and an outside
 * mousedown both close when `closeOnOutsideClick()` (default true, the
 * mousedown listener itself always attaches — the flag gates only whether
 * it acts). `dismissed` fires on every close path. Opening moves focus
 * into the panel (its own `tabindex="-1"` root — the DLS anatomy has no
 * single obvious default control, same reasoning `ui-modal`'s docblock
 * gives); closing returns focus to whatever had it before, mirroring
 * `ui-modal` exactly.
 *
 * **Placement** — `bottom-start` (default) | `bottom-end` | `top-start` |
 * `top-end`, 8px offset from the trigger. Flips to the opposite vertical
 * edge when the panel would overflow the viewport on its preferred side
 * AND the flipped side has room; the horizontal edge only nudges inward
 * to stay on-screen (DLS's own note reads "positions always in the centre
 * based on view height" — no horizontal-flip axis is specified, so this
 * kit doesn't invent one).
 *
 * RESKIN: delegate to the DLS Angular `popover`, keeping this selector,
 * the `open`/`title`/`width`/`footer`/`placement`/`closeOnOutsideClick`
 * inputs, the `[uiPopoverTrigger]`/`[uiPopoverFooterStart]`/
 * `[uiPopoverActions]` slots and the `dismissed` output.
 */
declare class UiPopover {
    open: _angular_core.ModelSignal<boolean>;
    title: _angular_core.InputSignal<string | undefined>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    width: _angular_core.InputSignal<number>;
    footer: _angular_core.InputSignal<UiPopoverFooterLayout>;
    placement: _angular_core.InputSignal<UiPopoverPlacement>;
    closeOnOutsideClick: _angular_core.InputSignalWithTransform<boolean, unknown>;
    dismissed: _angular_core.OutputEmitterRef<void>;
    protected readonly titleId: string;
    protected readonly coords: _angular_core.WritableSignal<{
        top: number;
        left: number;
    }>;
    private readonly host;
    private readonly panelRef;
    private opener;
    constructor();
    protected onEscape(): void;
    protected onResize(): void;
    protected onDocumentDown(event: Event): void;
    protected toggle(): void;
    private close;
    /** Flip-aware fixed placement — see the class doc's Placement section. */
    private position;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiPopover, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiPopover, "ui-popover", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "footer": { "alias": "footer"; "required": false; "isSignal": true; }; "placement": { "alias": "placement"; "required": false; "isSignal": true; }; "closeOnOutsideClick": { "alias": "closeOnOutsideClick"; "required": false; "isSignal": true; }; }, { "open": "openChange"; "dismissed": "dismissed"; }, never, ["[uiPopoverTrigger]", "*", "[uiPopoverFooterStart]", "[uiPopoverActions]"], true, never>;
}

/**
 * Progress bar — DLS 3.1 `Progress bar` (Figma set 1168:363,
 * REGISTER.md §32, built 3 Sep 2026). A 4px pill-radius
 * track, full width of its container, with a single fill segment:
 *
 *   <ui-progress-bar [value]="70" />                       <!-- warning fill -->
 *   <ui-progress-bar [value]="100" />                       <!-- success fill -->
 *   <ui-progress-bar state="error" />                       <!-- danger, full width -->
 *   <ui-progress-bar state="indeterminate" ariaLabel="Loading" />
 *
 * DLS's 10-column-grid fill reads as two colour rules, not a gradient:
 * **1–99% = warning** (`--color-warning-strong` #eb9600), **100% =
 * success** (`--color-success-strong` #00ab61); 0% paints no fill at all.
 * `state="error"` overrides `value` entirely — a full-width danger
 * (`--color-danger` #ff4724) fill, the DLS "Error" cell. `state=
 * "indeterminate"` ignores `value` too — a 30%-wide warning segment
 * sweeping left→right on a ~1.4s loop (DLS's fill is animated in code, no
 * static node to measure); frozen at a fixed 30–60% position under
 * `prefers-reduced-motion: reduce` rather than hidden, same house rule as
 * `ui-skeleton-bar`'s shimmer.
 *
 * No label anatomy on the DLS node — the caption (title + "x/y sections
 * completed", etc.) is the consumer's own row, same split the NPA
 * migration keeps with `.progress-title`/`.progress-sub`.
 *
 * Track: `--color-bg-neutral` #dde3e7 (added to tokens.css this round —
 * no bg-role token carried this hex before; #dde3e7 previously lived only
 * on `--color-tag-neutral` / `--color-border-decorative` / `--color-bg-
 * pressed` / `--color-chart-grid`, all a different DLS role). Track
 * height: DLS names `--size-base-6xs` for the 4px track — that token does
 * not exist in this kit's size scale (`5xs` 8 is the smallest step), so
 * the height is a 4px literal with this comment in place of the token.
 */
declare class UiProgressBar {
    /** 0–100. Ignored when `state` is `error` or `indeterminate`. */
    value: _angular_core.InputSignal<number>;
    /**
     * `auto` (default) reads `value`; `error` forces a full-width danger
     * fill; `indeterminate` sweeps a 30%-wide warning segment and omits
     * `aria-valuenow`.
     */
    state: _angular_core.InputSignal<"auto" | "error" | "indeterminate">;
    /** Accessible name for the bar — DLS has no built-in label anatomy. */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    protected clampedValue: _angular_core.Signal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiProgressBar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiProgressBar, "ui-progress-bar", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * The size axis added by lead ruling R1 (6 Sep 2026). `lg` is today's
 * component to the pixel, so no existing caller moves.
 */
type UiSectionHeaderSize = 'lg' | 'md' | 'sm';
/**
 * Section header — a title over an optional subtitle (Figma the reference app Phase 2
 * node 1790:58360, lead-harvested 3 Sep 2026 — no live Figma session this
 * round, so this is the authoritative source, not `get_design_context`).
 * Kitchen-sink gap: `ui-page-title` is a bare heading directive with no
 * subtitle slot, and nothing in the kit renders this two-line pattern.
 *
 *   <ui-section-header
 *     title="Trade Review"
 *     subtitle="Trades tagged under various use cases…" />
 *
 * A column, 4px gap: title = `heading(sm)` (20px/600/1.4, -0.005em —
 * resolves to exactly -0.1px at 20px, so no override needed; owner review
 * 3 Sep 2026 moved this from `heading(md)`/24px to the Figma-harvested
 * heading/xs spec, node 1790:58359 — the kit's 20px step is named `sm`) in
 * `--color-text-strong`; subtitle = `label(xs)` (12px/500/1.2) in
 * `--color-text-subtle`. The node has no background, rule or padding of its
 * own, and both lines sit `nowrap` in the design — the title stays a short
 * label there, but the subtitle here is a full sentence, so it is left free
 * to wrap in code rather than forced onto one line and clipped.
 *
 * `level` picks the rendered heading tag (`h2` default, or `h3`) so the
 * title is a real heading for document-outline/screen-reader structure —
 * a `[attr.role]` override would fake the semantics without fixing them.
 *
 * Zero outer margins by design: spacing between this and whatever sits
 * above/below it is the parent's job (the page stack's own gap), same rule
 * `ui-page-title` documents — a component that set its own margin would
 * fight the very first page that used two of them in a stack.
 *
 * ── WHY THIS COMPONENT HAS A VARIANT AXIS (lead ruling R1, 6 Sep 2026) ──
 * Kit-fixes walk item 13 made "no hand-rolled heading pair" a PLATFORM
 * RULE. P3 then met ten sites the fixed 20px title could not serve and
 * stopped on all ten rather than drop the anatomy (owner's standing rule:
 * a customisation becomes a kit variant, it is never dropped). Those ten:
 * `home.html:21,66` and `profile/sub-desk-card.html:59,130,199` and
 * `npa/draft-proposal.html:69,111,131` carry a 14px card/section heading;
 * sub-desk-card puts a leading 16px glyph before it; draft-proposal puts a
 * trailing `ui-icon-button` disclosure ON the title line;
 * `npa/reference-modal.html:4` has a subtitle CONTAINING an inline `<svg>`,
 * which a string input cannot hold; `npa/pre-npa-document.html:8-9` and
 * `npa/review-proposal.html:8-9` put a `ui-status-tag` on the title line.
 * So the component grows exactly four things — a size axis, a leading icon
 * slot, a trailing actions slot and a projected subtitle — and all ten
 * sites become a swap. The variant exists because the platform rule met
 * those ten sites, not because a size axis is nice to have.
 *
 *   <ui-section-header size="sm" title="Product (Murex)">
 *     <svg uiSectionHeaderIcon width="16" height="16" …>…</svg>
 *     <button uiSectionHeaderActions ui-icon-button size="tiny" …>…</button>
 *   </ui-section-header>
 *
 *   <ui-section-header size="md" title="References NPAs">
 *     <span uiSectionHeaderSubtitle><svg …>…</svg> Select past references…</span>
 *   </ui-section-header>
 *
 * `size` moves ONLY the title, down the heading role: `lg` `heading(sm)`
 * 20px (default, today), `md` `heading(xs)` 16px, `sm` `heading(2xs)` 14px.
 * Host class `ui-section-header--{size}`.
 *
 * THE SUBTITLE DOES NOT MOVE WITH IT — it stays `label(xs)` 12px at every
 * size, and that is a deliberate reading of `tokens/_type.scss`, not an
 * oversight. Three facts force it. (1) The harvested pair is heading(sm)/20
 * over label(xs)/12; that is fixed by Figma. (2) The label role has exactly
 * ONE step below 12px — `label(2xs)`/10, which tokens.css:354-356 records as
 * DLS's own step for "control text, table headers, chips" and confirms the
 * ladder is 10 -> 12 -> 13 with nothing between; stepping the subtitle down
 * in parallel with the title would land `md` on that 10px chip step and
 * leave `sm` with no step at all, i.e. the DLS scale does not support a
 * parallel ladder. (3) Stepping the other way — to `label(sm)`/13, which two of the
 * ten sites happen to use today — would make a 16px header's subtitle
 * LARGER than a 20px header's, inverting the hierarchy. So the title
 * carries the whole size axis and the subtitle is the constant support
 * line. Consequence to expect on the swap: `pre-npa-document` and
 * `review-proposal` normalise their subtitle from 13px `body(sm)` to 12px
 * `label(xs)`, and `reference-modal` from 13px `label(sm)` to the same.
 *
 * `[uiSectionHeaderIcon]` sits BEFORE the title, ON the title line, sized
 * 20px at `lg` and 16px at `md`/`sm` and centred on the title's midline.
 * `[uiSectionHeaderActions]` sits AFTER the title, ON the same line,
 * pushed right by `margin-left: auto` — it holds a `ui-icon-button`
 * disclosure (draft-proposal) or a `ui-status-tag` (pre-npa-document,
 * review-proposal). Both collapse to nothing via `:empty` when unprojected,
 * the same always-render-let-`:empty`-collapse pattern `ui-page-header`'s
 * regions and `ui-drawer`'s footer already use, so the DOM shape never
 * changes with the inputs (the kit trap `ui-table-header` documents).
 *
 * `[uiSectionHeaderSubtitle]` is the subtitle CONTENT slot, for a subtitle
 * that is not a plain string — an inline glyph, a link, a value the page
 * formats itself. It is the fallback-content form of `<ng-content>`
 * (Angular 18+): the string `subtitle` input renders as this slot's
 * FALLBACK, so **if both are supplied the projected one wins** and the
 * string is not rendered at all. The kit types the projected node with the
 * same `label(xs)` / `--color-text-subtle` role as the string version, so a
 * caller supplies markup, not styling; a caller who does want different
 * paint can style their own element, because a projected node carries the
 * CALLER's encapsulation attribute and so is reachable from the caller's
 * own stylesheet (see section-header.scss for the `::ng-deep` this same
 * fact forces on the kit's side).
 *
 * The `.sh-title` / `.sh-subtitle` class hooks are unchanged for the string
 * path (f75 reads both); the hook for a PROJECTED subtitle is the
 * `[uiSectionHeaderSubtitle]` attribute itself.
 *
 * RESKIN: delegate to the DLS heading/typography component; keep this
 * selector, the `title`/`subtitle`/`level`/`size` inputs and all three slot
 * names unchanged.
 */
declare class UiSectionHeader {
    /** Required — the section's own title. */
    title: _angular_core.InputSignal<string>;
    /**
     * Optional descriptive line under the title. Omitted entirely when unset,
     * and OVERRIDDEN entirely when a caller projects `[uiSectionHeaderSubtitle]`
     * (see the doc comment — the projected slot wins).
     */
    subtitle: _angular_core.InputSignal<string | undefined>;
    /** Rendered heading tag — `h2` (default) or `h3`, for document structure. */
    level: _angular_core.InputSignal<"h2" | "h3">;
    /**
     * Title size step — `lg` (default, `heading(sm)` 20px, today's look),
     * `md` (`heading(xs)` 16px) or `sm` (`heading(2xs)` 14px). The subtitle
     * stays `label(xs)` 12px at every step; see the doc comment for why the
     * DLS scale does not support stepping it in parallel.
     */
    size: _angular_core.InputSignal<UiSectionHeaderSize>;
    /**
     * Base class + size class in one binding, the same shape
     * `ui-page-header`'s `hostClass` uses (Angular merges a host `[class]`
     * binding with whatever `class` the caller writes on the element, which
     * is how `<ui-page-header class="page-header">` already works on five
     * pages).
     */
    protected hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiSectionHeader, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiSectionHeader, "ui-section-header", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "level": { "alias": "level"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, ["[uiSectionHeaderIcon]", "[uiSectionHeaderActions]", "[uiSectionHeaderSubtitle]"], true, never>;
}

/**
 * Shared data model for `ui-stepper` / `ui-stepper-marker`
 * (REGISTER.md §38). `'null'` (DLS's "not started" marker)
 * is only meaningful when the owning `ui-stepper` has `nonLinear` set —
 * see stepper-marker.ts.
 */
type UiStepperStatus = 'completed' | 'active' | 'inactive' | 'error' | 'null';
interface UiStepperSubStep {
    key: string;
    label: string;
    status: UiStepperStatus;
}
interface UiStepperStep {
    key: string;
    label: string;
    status: UiStepperStatus;
    subSteps?: UiStepperSubStep[];
}

/**
 * `ui-stepper` — DLS 3.1 `Stepper` (Figma page 36356:268586,
 * REGISTER.md §38, owner round §35–§39 decision (38): built
 * for the archive in BOTH layouts — vertical + horizontal, sub-steps,
 * statuses, non-linear, the §32 bar — with a focus-overlay slot demo, no
 * page wiring yet).
 *
 *   <ui-stepper
 *     [steps]="steps"
 *     current="review"
 *     orientation="vertical"
 *   />
 *
 *   <ui-stepper [steps]="steps" current="review" orientation="horizontal" />
 *
 *   <!-- interactive: a real click on a step-item moves `current` -->
 *   <ui-stepper [steps]="steps" [(current)]="current" [interactive]="true"
 *               (stepSelected)="onStepSelected($event)" />
 *
 * **Vertical** (207411:1264): each parent step is a row — a 20px
 * `ui-stepper-marker` column carrying a 2px connector line (green
 * `--color-icon-selected` through a completed step, `--color-icon-
 * decorative` otherwise; the first row has no line above, the last none
 * below) — beside a step-item (`padding: var(--padding-field-v-md)
 * var(--padding-field-h-sm)` — 12 vertical / 8 horizontal, radius 4,
 * `type.label(md)` 14/500 `--color-text-strong`, `--color-text-disabled`
 * when inactive). `nonLinear` drops every connector and is the only mode
 * that may carry the `'null'` ("not started") marker status. Sub-steps
 * render indented under their parent with their own 20px marker column
 * (continuing the parent's connector) but lead the step-item itself with
 * a bare 16px glyph instead of the ring marker — `check_16` completed,
 * `arrow-right_16` active, nothing inactive/error — at `type.label(sm)`
 * 13px.
 *
 * **Horizontal** (207877:3254): a flex row of `step-group`s (`flex: 1`,
 * 4px padding, radius 4; the group holding `current` — parent OR one of
 * its sub-steps — sits on `--color-bg-pressed`), each a parent step-item
 * (`type.label(md)` 14) and, when one of ITS sub-steps is `current`, a
 * second line for that sub-step (`type.label(sm)` 13) underneath. Both
 * lines share one glyph rule: **active + current** gets `arrow-right_16`
 * BEFORE the label, completed gets `check_16` AFTER, error gets
 * `circle-exclamation_16` AFTER, inactive is bare text-disabled — no
 * glyph. Under the row, an 8px gap, then a `ui-progress-bar` whose
 * `value` is `progress()` when set, else completed-parent-steps ÷
 * total-parent-steps × 100 (the §32 bar, reused rather than redrawn).
 *
 * `interactive` gates click/hover/pressed/focus on step-items (default:
 * static rows, no `stepSelected` output, no interactive states) —
 * `stepSelected` only fires from a REAL click on a step-item, never
 * programmatically from `current` changing underneath the component.
 * `current` is an `input` the caller owns (not a two-way `model`) so the
 * consumer decides whether a click actually advances the flow — the sink
 * demo below binds it back with a plain signal `.set()` in its own
 * `(stepSelected)` handler, `[(current)]` banana-in-a-box works too via
 * that same signal since the setter shape matches `model()`'s only if the
 * caller wires it; kept as a one-way input + output pair (mirrors
 * `ui-tabs`' `active`/`activeChange`-free "caller decides" precedent
 * rather than assuming every consumer wants two-way binding on a value
 * this consequential to a multi-step flow).
 */
declare class UiStepper {
    steps: _angular_core.InputSignal<UiStepperStep[]>;
    /** Key of the current step, or of a current SUB-step. */
    current: _angular_core.InputSignal<string | undefined>;
    orientation: _angular_core.InputSignal<"vertical" | "horizontal">;
    /** DLS `stepper-horizontal` Type axis (207877:3254): `default` marks the
     *  current step by its arrow glyph alone; `group` paints the current
     *  step-group on `--color-bg-pressed` under its sub-step line. */
    type: _angular_core.InputSignal<"group" | "default">;
    /** Vertical only: drops connector lines, allows the `'null'` marker. */
    nonLinear: _angular_core.InputSignal<boolean>;
    /** Gates click/hover/pressed/focus on step-items; default rows are static. */
    interactive: _angular_core.InputSignal<boolean>;
    /** Horizontal only: overrides the computed completed-ratio bar value. */
    progress: _angular_core.InputSignal<number | undefined>;
    stepSelected: _angular_core.OutputEmitterRef<string>;
    protected onStepClick(key: string): void;
    /** Vertical connector above a parent row — green when the row it comes
     * FROM (the previous step) landed as completed. */
    protected isConnectorAboveFilled(step: UiStepperStep, first: boolean): boolean;
    protected isGroupCurrent(step: UiStepperStep): boolean;
    protected isActiveCurrent(key: string, status: UiStepperStep['status']): boolean;
    protected currentSubStep(step: UiStepperStep): UiStepperSubStep | undefined;
    protected progressValue: _angular_core.Signal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiStepper, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiStepper, "ui-stepper", never, { "steps": { "alias": "steps"; "required": true; "isSignal": true; }; "current": { "alias": "current"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "nonLinear": { "alias": "nonLinear"; "required": false; "isSignal": true; }; "interactive": { "alias": "interactive"; "required": false; "isSignal": true; }; "progress": { "alias": "progress"; "required": false; "isSignal": true; }; }, { "stepSelected": "stepSelected"; }, never, never, true, never>;
}

/**
 * The 20px marker box a `ui-stepper` parent-step row leads with (DLS
 * `stepper-marker`, Figma 207411:1192, REGISTER.md §38) — a
 * 16px ring centred in the box, radio's exact ring-and-disc recipe
 * (`radio.scss`):
 *
 *   <ui-stepper-marker status="active" />
 *
 * - `active` — 2px `--color-icon-decorative` ring (#9ba4ab) with a
 *   10.67px `--color-icon-selected` disc (#00ab61) centred inside, same
 *   two-layer shape as a checked radio.
 * - `inactive` — the same 2px ring, hollow (no disc).
 * - `completed` — no ring; a filled `circle-checkmark-filled` glyph,
 *   `--color-icon-selected`.
 * - `error` — no ring; a filled `circle-exclamation-filled` glyph.
 *   tokens.css has no dedicated `--color-icon-danger` role (reported to
 *   the lead) — `--color-danger` (#ff4724) is the nearest existing
 *   danger step and is used here, the same substitution `ui-progress-
 *   bar`'s error fill already makes.
 * - `null` — DLS's deprecated "not started" marker: a lighter hollow
 *   ring, `--color-icon-disabled` (#c7cfd5) rather than the inactive
 *   ring's `--color-icon-decorative` — non-linear steppers only (a
 *   `ui-stepper` with `nonLinear` unset never emits this status; it is
 *   the caller's data to omit).
 *
 * Exported standalone because the register calls it out as its own DLS
 * node (207411:1192); `ui-stepper` composes it for every parent-step row
 * in the vertical layout. The horizontal layout and vertical sub-steps do
 * NOT use this marker — they lead with a plain 16px glyph instead (see
 * `stepper.ts`), per the DLS anatomy.
 */
declare class UiStepperMarker {
    status: _angular_core.InputSignal<UiStepperStatus>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiStepperMarker, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiStepperMarker, "ui-stepper-marker", never, { "status": { "alias": "status"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * `td[ui-cell-edit]` — the DLS `data-cell` "Edit mode" variant
 * (REGISTER.md §40, "data-cell … Edit mode: the content
 * becomes a full-width 32px Input/Text carrying the value in text-strong
 * (selects / date pickers for typed cells, per the Editing guideline)").
 * Applied as an attribute on a native `<td>` so table semantics
 * (colspan, scope, keyboard navigation) stay intact, same house pattern as
 * `ui-button` / `ui-link`:
 *
 *   <td ui-cell-edit [editing]="row.editingAddress()" clickToEdit
 *       (editStart)="row.editingAddress.set(true)"
 *       (commit)="commitAddress(row)" (cancel)="row.editingAddress.set(false)">
 *     <span>{{ row.address() }}</span>
 *     <ui-text-input uiCellEditor [(value)]="row.addressDraft" />
 *   </td>
 *
 * Two projected faces, toggled by `editing()`: the DEFAULT slot (display
 * content, shown at rest) and the `[uiCellEditor]` slot (a `ui-text-input` /
 * `ui-select` / `ui-date-input`, shown only while editing). Only one is
 * ever in the DOM's visible flow at a time — both stay projected so the
 * consumer's control keeps its state (draft value, focus) across the
 * toggle rather than being torn down and rebuilt.
 *
 * **Size** — `xs` (default, 24px field height, the compact density every
 * other DLS-replica control in this kit defaults to) | `sm` (32px). Since
 * the projected editor is a full component with its OWN encapsulated
 * styles, this host cannot reach its internals through a plain descendant
 * selector — `:host ::ng-deep` is the documented, narrowly-scoped escape
 * hatch every other cross-encapsulation override in this kit uses (see
 * `styles/ui-tables.css`'s own column-header-filter-height
 * rule, which does the same job one layer up, as plain global CSS instead
 * of `::ng-deep` because it lives outside any component's template at
 * all). cell-edit.scss targets the same three class names that sheet
 * documents: `.ui-text-input` (text-input's own root), `.ui-select-trigger`
 * (select's trigger), `.ui-date-input` (date-input's shared shell).
 *
 * **Error** — `error` input (a message string; empty = no error). When
 * set, a host class flips the projected editor's border to
 * `--color-danger` (mirrors `ui-text-input`'s own `.invalid` look) and a
 * `label(xs)` message renders in `--color-text-danger` directly under the
 * control — the guideline's "inline validation … error message under the
 * cell, red outline".
 *
 * **click-to-edit** — `clickToEdit` (booleanAttribute, default false): a
 * click anywhere in the cell while `!editing()` emits `editStart` (the
 * consumer flips its own `editing` signal — this component holds no state
 * of its own, same as every other kit control that participates in a
 * parent-owned edit flow). Only wired when the input is set, so a
 * row/table-level edit toggle (driven by an external Edit button, not a
 * cell click) can use this component without a stray click handler.
 *
 * **Commit / cancel** — Enter or blur (`focusout`) inside the editor slot
 * emits `commit`; Escape emits `cancel`. `focusout` is guarded against
 * focus moving to ANOTHER element still inside this cell (e.g. a
 * text-input's own clear button) via `relatedTarget` containment, so
 * tabbing within the cell's own controls does not fire a spurious commit.
 * Enter is caught on `keydown.enter` rather than relying on native form
 * submission — a `<td>` is not a form, and the projected editor may be a
 * button-based trigger (`ui-select`, `ui-date-input`) with no submit
 * behaviour at all.
 */
declare class UiCellEdit {
    private readonly host;
    editing: _angular_core.InputSignalWithTransform<boolean, unknown>;
    size: _angular_core.InputSignal<"xs" | "sm">;
    error: _angular_core.InputSignal<string>;
    clickToEdit: _angular_core.InputSignalWithTransform<boolean, unknown>;
    editStart: _angular_core.OutputEmitterRef<void>;
    commit: _angular_core.OutputEmitterRef<void>;
    cancel: _angular_core.OutputEmitterRef<void>;
    onHostClick(): void;
    onEscape(): void;
    onEnter(event: Event): void;
    onFocusOut(event: FocusEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiCellEdit, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiCellEdit, "td[ui-cell-edit]", never, { "editing": { "alias": "editing"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "clickToEdit": { "alias": "clickToEdit"; "required": false; "isSignal": true; }; }, { "editStart": "editStart"; "commit": "commit"; "cancel": "cancel"; }, never, ["*", "[uiCellEditor]"], true, never>;
}

/**
 * `ui-cell-changed` — the DLS Table "new patterns" cell for a value that
 * changed after editing (REGISTER.md §40, "new patterns …
 * an edited cell showing 'Previously: …' in the warning colour"). Two
 * stacked lines, no gap: the current `value` (body/sm, strong-weight, the
 * cell's ordinary text colour) directly over a `Previously: {previous}`
 * line in the DLS warning text colour.
 *
 *   <td>
 *     <ui-cell-changed value="+65 9123 4567" previous="+65 9123 0000" />
 *   </td>
 *
 * A plain child component (not an attribute directive like `ui-cell-edit`)
 * because it is pure display — no host interaction, no projected editor —
 * so it drops into a cell's existing content the same way `ui-badge` or
 * `ui-chip` would rather than taking over the `<td>` itself.
 *
 * **Colour** — no `--color-text-warning` token exists in tokens.css (only
 * `--color-warning` / `--color-warning-strong`, both fill/icon roles, and
 * `--color-warning-strong` is documented for a left-bar accent, not body
 * text — tokens.css line ~497). `--color-warning-strong` (#eb9600) is used
 * here as the closest on-spec amber with enough contrast to read as body
 * text; report to the lead as a gap (a `--color-text-warning` role token
 * would be the correct long-term home for this).
 */
declare class UiCellChanged {
    value: _angular_core.InputSignal<string>;
    previous: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiCellChanged, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiCellChanged, "ui-cell-changed", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "previous": { "alias": "previous"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * `ui-cell-expandable` — the DLS Table "new patterns" cell (REGISTER.md §40, "'View all (5)' / 'View less' expanding
 * content"): a numbered list of `items`, clipped to the first `limit`
 * (default 3) with a `button[ui-link]` "View all (N)" that swaps to the
 * full list + "View less".
 *
 *   <td>
 *     <ui-cell-expandable [items]="row.tags()" [limit]="3" />
 *   </td>
 *
 * `expanded` is a `model()` so a consumer that needs to know / drive the
 * open state from outside (e.g. "collapse all") can bind it; the demo
 * leaves it uncontrolled and lets the component own it.
 */
declare class UiCellExpandable {
    items: _angular_core.InputSignal<string[]>;
    limit: _angular_core.InputSignal<number>;
    expanded: _angular_core.ModelSignal<boolean>;
    visibleItems: _angular_core.Signal<string[]>;
    toggle(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiCellExpandable, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiCellExpandable, "ui-cell-expandable", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "limit": { "alias": "limit"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; }, { "expanded": "expandedChange"; }, never, never, true, never>;
}

/**
 * `tr[ui-table-add-row]` — the DLS Table "new patterns" add row (REGISTER.md §40, "add / delete item … '⊕ Add item' row under the
 * last row"). A full-width row holding a single tertiary/text button;
 * clicking it emits `add` (the consumer appends a row — this component
 * holds no data of its own, same pattern as every other kit control in a
 * parent-owned list). Applied as an attribute on a native `<tr>` so it
 * drops straight into an existing `<tbody>`:
 *
 *   <tr ui-table-add-row [colspan]="6" (add)="addRow()"></tr>
 *   <tr ui-table-add-row label="Add trader" [colspan]="6" (add)="addTrader()"></tr>
 */
declare class UiTableAddRow {
    label: _angular_core.InputSignal<string>;
    colspan: _angular_core.InputSignal<number>;
    add: _angular_core.OutputEmitterRef<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTableAddRow, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTableAddRow, "tr[ui-table-add-row]", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "colspan": { "alias": "colspan"; "required": false; "isSignal": true; }; }, { "add": "add"; }, never, never, true, never>;
}

interface UiTableColumn {
    key: string;
    label: string;
    visible: boolean;
    locked?: boolean;
}
/**
 * `ui-table-columns` — the DLS Table "column customisation" control (REGISTER.md §40, guideline "column customisation (a 'Table
 * Columns' popover of checkbox rows with drag handles … at least one
 * column must stay visible)"). A `button[ui-icon-button]` gear trigger
 * opens a `ui-popover` (title "Table Columns", 280px) listing `columns`.
 *
 *   <ui-table-columns [(columns)]="cols" />
 *
 * where `cols` is a `UiTableColumn[]` — `{ key, label, visible, locked? }`.
 * Reordering the array reorders the columns; toggling `visible` shows/hides
 * one; a `locked` column's checkbox is disabled (DLS: some columns —
 * typically the first, an id/name anchor — cannot be hidden at all).
 *
 * **Trigger** — a plain `[uiPopoverTrigger]` gear icon-button is built in
 * rather than also exposing a `[uiTableColumnsTrigger]` projection slot:
 * the brief allows either, and a second slot only pays for itself once a
 * caller actually needs a non-gear trigger — none does yet in this sink or
 * anywhere in the reference app. Report as a design decision, not a gap: add
 * the slot the day a consumer needs it.
 *
 * **Reorder** — REAL pointer drag on the handle (`pointerdown` on
 * `.tc-handle`, document-level `pointermove`/`pointerup` while dragging):
 * the dragged row swaps with whichever row the pointer's Y crosses past the
 * midpoint of, committing to the `columns` model on every crossing (so the
 * list re-renders live, not just on drop). Keyboard equivalent: focus a row
 * (each `.tc-row` is a `tabindex="0"` div) and press `Alt+ArrowUp` /
 * `Alt+ArrowDown` to move it one slot, refocusing the row at its new
 * position so repeated key presses keep walking the same logical row.
 *
 * **Guard rail** — unchecking a column when it is the ONLY visible one is
 * refused: the model is left untouched (the checkbox's `[checked]` binding
 * simply re-renders to its unchanged true value) and an inline
 * `label(xs)` "At least one column must be selected" message in
 * `--color-text-danger` appears below the list, persisting until any
 * column is (re)checked. A `locked` row's checkbox is `disabled` outright
 * — DLS's "locked" columns don't participate in the min-one-visible
 * bookkeeping at all, they simply can't be touched.
 */
declare class UiTableColumns {
    private readonly host;
    columns: _angular_core.ModelSignal<UiTableColumn[]>;
    open: _angular_core.ModelSignal<boolean>;
    protected readonly error: _angular_core.WritableSignal<string>;
    protected readonly draggingIndex: _angular_core.WritableSignal<number | null>;
    private pointerMoveHandler;
    private pointerUpHandler;
    onToggle(index: number, checked: boolean, checkbox: UiCheckbox): void;
    onPointerDown(event: PointerEvent, index: number): void;
    private onPointerMove;
    private onPointerUp;
    onKeydown(event: KeyboardEvent, index: number): void;
    private moveColumn;
    private focusRow;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTableColumns, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTableColumns, "ui-table-columns", never, { "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "open": { "alias": "open"; "required": false; "isSignal": true; }; }, { "columns": "columnsChange"; "open": "openChange"; }, never, never, true, never>;
}

type UiTableSize = 'xs' | 'sm';
/**
 * DLS Table chassis (REGISTER.md §40, Figma `238634:12422` +
 * guideline `165411:165187`, audited/built 4 Sep 2026). An ATTRIBUTE
 * component on a native `<table>` so the seventeen existing callers migrate
 * by adding one attribute rather than a template rewrite — same shape as
 * `ui-button`/`ui-icon-button`:
 *
 *   <table ui-table>                     xs (default), no card chrome
 *     <thead><tr>
 *       <th><ui-column-header label="Name" first /></th>
 *       <th class="ui-cell-expand"><ui-column-header variant="blank" /></th>
 *     </tr></thead>
 *     <tbody>
 *       <tr ui-table-row interactive (activate)="open(row)">
 *         <td>Tanaka Hiroshi</td>
 *       </tr>
 *     </tbody>
 *   </table>
 *
 *   <table ui-table size="sm" zebra card>  small, zebra, level_2 card chrome
 *
 * OWNER'S RULING (4 Sep 2026): Small and Extra-small ONLY — DLS's Medium is
 * not built. Extra-small is the default density (`size="xs"`), `size="sm"`
 * is the opt-in.
 *
 * **`size`** — `xs` (default, DLS Extra small: 4/8 cell padding, 24 content
 * row → 32 total row height) | `sm` (DLS Small: 8/8 padding, 32 content row
 * → 48 total).
 *
 * **`zebra`** — even body rows paint `--color-bg-alt` (#f7f7f7) instead of
 * the table's own background. Guideline: "shall not be used together with"
 * an expanded child row — `tr[ui-table-row][child]` opts itself out of the
 * zebra rule regardless of row index (table.scss).
 *
 * **`card`** — wraps the table in the DLS level_2 card chrome: white
 * `--color-bg-level2`, `--border-radius-panel-lg` (8px), `--shadow-elevation-1`,
 * a transparent 1px seam, `overflow: clip`. Off by default — plenty of
 * tables in the app sit inside a `ui-card` or a page section that already
 * supplies this chrome, and double-wrapping would double the radius/shadow.
 *
 * This component owns the CHASSIS only — cell height, gutters, the body
 * text role, zebra fill, the bottom rule — via `:host` and
 * `:host ::ng-deep` (the projected `<th>`/`<td>` are the CONSUMER's own
 * elements, so `::ng-deep` is required to reach them, same trap `ui-button`
 * documents for projected icons). The TYPED CELLS (`.ui-cell-number`,
 * `.ui-cell-avatar`, …) are plain classes the consumer puts directly on a
 * `<td>` — see table.scss for the full list — so no per-cell-type directive
 * is needed.
 *
 * This component SUPERSEDES the global `.ui-table` sheet
 * (`styles/ui-tables.css`) for all NEW anatomy — that sheet
 * stays only for the ported chassis (`.table`, `.field-table`) migrating in
 * a later round, and for `ui-column-header`'s own filter-height / cell rules
 * which this component does not duplicate.
 *
 * RESKIN: delegate to the DLS Angular table chassis; keep the selector and
 * `size`/`zebra`/`card` inputs unchanged.
 */
declare class UiTable {
    size: _angular_core.InputSignal<UiTableSize>;
    zebra: _angular_core.InputSignalWithTransform<boolean, unknown>;
    card: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTable, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTable, "table[ui-table]", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "zebra": { "alias": "zebra"; "required": false; "isSignal": true; }; "card": { "alias": "card"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * DLS Table row states (REGISTER.md §40, guideline
 * "interactions" 157043:33643) — an ATTRIBUTE component on a native `<tr>`,
 * sibling to `table[ui-table]`:
 *
 *   <tr ui-table-row interactive (activate)="openRow(r)">…</tr>
 *   <tr ui-table-row [selected]="isChecked(r)">…</tr>
 *   <tr ui-table-row [expanded]="isOpen(r)" (activate)="toggle(r)">…</tr>
 *   <tr ui-table-row child>…</tr>   <!-- an expanded parent's child row -->
 *
 * **`interactive`** — the row is clickable: hover paints `--color-bg-hover`
 * (#eef2f5), cursor pointer, `tabindex="0"`, pressed (`:active`) paints
 * `--color-bg-pressed` (#dde3e7, outline stays on top per the guideline),
 * and keyboard focus draws a 2px `--color-focus` ring INSET (`outline`
 * with a negative `outline-offset`, verified by screenshot in the sink —
 * Chromium paints this correctly on `<tr>` without a box-shadow fallback).
 * Emits `(activate)` on a real click, Enter or Space.
 *
 * **`selected`** — `--color-primary-subtle` background. DLS's own hex here
 * is `#fff2f2` (`background-product-subtle`, a red-tinted wash); this kit's
 * white-label seam token resolves to the platform's own subtle-brand tint
 * instead (`--color-primary-subtle`, #e5f1fa in this build) — see
 * tokens.css for the seam. Not mutually exclusive with `interactive`.
 *
 * **`expanded`** — this row is a PARENT whose children are currently shown;
 * sets `aria-expanded="true"` (vs `"false"` when the input is bound but
 * false) so `.ui-cell-expand-btn`'s 90°-rotated arrow and the row's
 * semantics stay in sync from one input.
 *
 * **`child`** — this row IS one of an expanded parent's children:
 * `--color-bg-app` (#f5f7f9, DLS `background-level_0`) background,
 * unconditionally — the guideline rules a child row "shall not be used
 * together with zebra", so table.scss's zebra selector explicitly excludes
 * `.ui-table-row--child` rather than relying on paint order.
 *
 * **Sticky cells.** Row states are painted on every `td` of the row
 * (`tr.<state> td` in table.scss), not on the `<tr>` — a cell's own opaque
 * background would otherwise hide a row-level tint — so `.ui-td-sticky`
 * (the trailing sticky actions column) takes the state like any other cell.
 *
 * RESKIN: delegate to the DLS Angular table row; keep the selector and the
 * four inputs unchanged.
 */
declare class UiTableRow {
    interactive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    selected: _angular_core.InputSignalWithTransform<boolean, unknown>;
    expanded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** This row IS an expanded parent's child — see the class doc. */
    child: _angular_core.InputSignalWithTransform<boolean, unknown>;
    activate: _angular_core.OutputEmitterRef<void>;
    protected hostClass: _angular_core.Signal<string>;
    protected ariaExpanded: _angular_core.Signal<"true" | "false" | null>;
    protected onClick(): void;
    protected onKey(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTableRow, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTableRow, "tr[ui-table-row]", never, { "interactive": { "alias": "interactive"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "child": { "alias": "child"; "required": false; "isSignal": true; }; }, { "activate": "activate"; }, never, ["*"], true, never>;
}

type UiTableHeaderLayout = 'auto' | 'stacked' | 'inline';
/**
 * `ui-table-header` — DLS `table-header` (REGISTER.md §40,
 * Figma 47754:259751): the panel band that sits above the column-header
 * row of a `table[ui-table]`. bg level_2, 1px `--color-border-decorative`
 * bottom rule, 24px h / 16px v padding (`--padding-panel-h-lg` /
 * `--padding-panel-v-md`), 16px vertical gap between its two rows.
 *
 *   <ui-table-header title="Trades" subtitle="12 pending review">
 *     <ui-search-input [(value)]="query" />
 *     <button uiTableActions ui-button variant="secondary" size="small">Export</button>
 *     <button uiTableSubActions ui-icon-button size="small" aria-label="More"><svg>…</svg></button>
 *   </ui-table-header>
 *
 * TITLE-SIZE RULING (owner, this round): DLS prints the title at
 * heading/xs 20 — this kit keeps every panel title at the SAME compact
 * step `ui-section-header` already stands on (`type.heading(sm)`, the
 * kit's harvested 20px role — see section-header.ts's own note on why the
 * kit's "sm" name carries DLS's "xs" size). Subtitle is `type.body(sm)`.
 *
 * ── Two rows ─────────────────────────────────────────────────────────
 * Row 1 `caption`: an optional 32px back icon-button (chevron-left, -8px
 * optical margin so the glyph — not the hit box — sits flush with the
 * padding) + title/subtitle. OMITTED ENTIRELY (no row, not just hidden)
 * when there is no title and no back button — DLS: "the table title is
 * optional".
 *
 * Row 2 `control` (gap 16): the default slot (left, flex-1) is whatever
 * the consumer projects — a `ui-search-input`, a `ui-filter-tabs`, or a
 * filter group; the right `action` side is `[uiTableActions]` (main, gap
 * 8) + gap 12 + `[uiTableSubActions]` (icon-buttons, gap 8).
 *
 * ── Layout auto-detection ───────────────────────────────────────────
 * DLS's Default/With-filter-group variants put the title and the actions
 * on ONE 64px row (no default-slot content); With-search/With-tabs stack
 * to two rows. This component tells the two apart with CSS alone — no
 * ContentChild polling, no `.observed` check on an output (this kit has no
 * precedent for the latter, and `output()` does not expose one reliably) —
 * a `.control-left:empty` selector on the wrapper that holds the bare
 * `<ng-content>` toggles a `:has()` rule on the host. `layout` overrides
 * the guess when a consumer's projected content is empty at first render
 * but arrives later (e.g. an `@if` inside the projected template).
 *
 * KNOWN KIT TRAP avoided: only ONE `<ng-content>` per selector exists in
 * the template tree, ever — the batch-actions slot and the main-actions
 * slot are two DIFFERENT selectors (`[uiTableBatchActions]` /
 * `[uiTableActions]`), each written exactly once, swapped by `@if`/`@else`,
 * never the same selector duplicated across branches (which would project
 * only into the first match and silently drop the rest).
 *
 * ── Multiselect ──────────────────────────────────────────────────────
 * `selectedCount` > 0 replaces the main-actions slot with a "{n} selected"
 * label (`type.label(sm)`, `--color-text-body`) followed by the
 * `[uiTableBatchActions]` slot; sub-actions are unaffected. The component
 * emits nothing on its own — selection stays the consumer's model.
 *
 * ── Reset filters ────────────────────────────────────────────────────
 * `filtersActive` renders a secondary small "Reset filters" button at the
 * START of the action group (before main actions) and emits
 * `resetFilters` on a real click. Hidden whenever `selectedCount` > 0 —
 * DLS never shows both a batch-action bar and a filter-reset button at
 * once; multiselect wins.
 *
 * RESKIN: delegate to the DLS Angular `table-header`; keep the selector,
 * the four slots and every input/output unchanged.
 */
declare class UiTableHeader {
    /** Panel title. Omitted (with the whole caption row) when empty and no back button. */
    title: _angular_core.InputSignal<string | undefined>;
    /** Optional descriptive line under the title. */
    subtitle: _angular_core.InputSignal<string | undefined>;
    /** Forces the back icon-button on even with no `(back)` listener attached. */
    showBack: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Number of selected rows — >0 swaps main actions for the batch-action slot. */
    selectedCount: _angular_core.InputSignal<number>;
    /** Shows the "Reset filters" button (hidden automatically during multiselect). */
    filtersActive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** `auto` (default) detects via CSS whether the default slot has content;
     *  `stacked`/`inline` force the DLS one-row vs two-row composition. */
    layout: _angular_core.InputSignal<UiTableHeaderLayout>;
    back: _angular_core.OutputEmitterRef<void>;
    resetFilters: _angular_core.OutputEmitterRef<void>;
    protected hasCaption: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTableHeader, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTableHeader, "ui-table-header", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "showBack": { "alias": "showBack"; "required": false; "isSignal": true; }; "selectedCount": { "alias": "selectedCount"; "required": false; "isSignal": true; }; "filtersActive": { "alias": "filtersActive"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; }, { "back": "back"; "resetFilters": "resetFilters"; }, never, ["*", "[uiTableBatchActions]", "[uiTableActions]", "[uiTableSubActions]"], true, never>;
}

/**
 * `ui-table-sub-header` — DLS `table-sub-header` (REGISTER.md
 * §40, Figma 120497:249555): the section-divider row a `table[ui-table]`
 * body drops between groups of rows ("Grouping" guideline — rows between
 * two dividers form one section).
 *
 *   <table ui-table>
 *     <tbody>
 *       <tr ui-table-sub-header label="Singapore" [colspan]="7"></tr>
 *       <tr> … data-cells … </tr>
 *       <tr ui-table-sub-header label="Hong Kong" [colspan]="7"></tr>
 *       <tr> … data-cells … </tr>
 *     </tbody>
 *   </table>
 *
 * Attribute component on a native `tr` (same pattern as `ui-button`/
 * `ui-icon-button`) so it stays valid table markup and free-floats inside
 * whatever `<tbody>` the seventeen `ui-table` callers already render — it
 * renders its own single `<td [attr.colspan]>` spanning the row.
 *
 * 24px h / 8px v padding, `type.label(sm)` 500 UPPERCASE (`text-transform`,
 * not a pre-uppercased string — the consumer passes the label in its
 * natural case) in `--color-text-subtle`, 1px `--color-border-decorative`
 * bottom rule, `--color-bg-level2` background. DLS prints this row at a
 * fixed 33px (8 + 17 + 8); this kit's compact `label(sm)` line-height
 * computes its own row height off the 8/8 padding instead of a hardcoded
 * 33 — see table-header.ts's title-size note for the same compactness
 * ruling applied to the panel title.
 *
 * RESKIN: delegate to the DLS Angular `table-sub-header`; keep the
 * selector and the `label`/`colspan` inputs unchanged.
 */
declare class UiTableSubHeader {
    /** Section label, rendered UPPERCASE via CSS text-transform. */
    label: _angular_core.InputSignal<string>;
    /** How many columns the divider's single cell spans. */
    colspan: _angular_core.InputSignal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTableSubHeader, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTableSubHeader, "tr[ui-table-sub-header]", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "colspan": { "alias": "colspan"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * `ui-table-card` — the DLS Table ROOT (REGISTER.md §40, Figma
 * `238634:12422`): a white level_2 card, `--border-radius-panel-lg` (8px),
 * `--shadow-elevation-2`, `overflow: clip`, that wraps `ui-table-header` +
 * `table[ui-table]` + a footer (typically `ui-pagination`) as ONE seam —
 * the DLS composition draws header, grid and footer inside a single card,
 * not three independently-chromed pieces.
 *
 *   <ui-table-card>
 *     <ui-table-header title="Trades">…</ui-table-header>
 *     <table ui-table>…</table>
 *     <div class="table-card-footer">
 *       <ui-pagination [total]="rows.length" [(page)]="page" />
 *     </div>
 *   </ui-table-card>
 *
 * `table[ui-table]`'s own `card` input remains for a LONE table with no
 * header/footer of its own (table.ts's class doc) — the two are not
 * redundant: `card` chromes just the `<table>` element, `ui-table-card`
 * chromes the whole header+grid+footer composition. A consumer using
 * `ui-table-card` drops `card` from the `table[ui-table]` inside it (the
 * inner table stays chrome-less so the outer card's radius/shadow isn't
 * doubled).
 *
 * A plain block wrapper — no inputs, no host state — `display: block` so
 * it lays out like any other container; the DLS chrome (background,
 * radius, shadow, clip) lives entirely in table-card.scss.
 *
 * RESKIN: delegate to the DLS Angular table root; keep the selector
 * unchanged.
 */
declare class UiTableCard {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTableCard, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTableCard, "ui-table-card", never, {}, {}, never, ["*"], true, never>;
}

/**
 * Shared status vocabulary for the whole `ui-tracker` family (marker,
 * event, sub-event's active/inactive cases, and step) — one union so a
 * caller mapping data onto the tracker never has to reconcile two
 * spellings of "completed" (REGISTER.md §43).
 */
type UiTrackerStatus = 'completed' | 'active' | 'inactive' | 'error' | 'null';
/**
 * `ui-tracker-marker` — the DLS 3.1 `tracker-marker` (Figma 207412:40778,
 * REGISTER.md §43), a 16×20 box:
 *
 *   <ui-tracker-marker status="completed" />
 *
 * Unlike `ui-stepper-marker` (§38, a DIFFERENT DLS node with its own
 * anatomy — completed/error there drop the ring entirely and show only a
 * filled glyph), the Tracker marker keeps a 2px RING in every visible
 * state and layers the status glyph inside it:
 *
 * - `active` — white centre, 2px `--color-border-disabled` ring
 *   (#c7cfd5), a filled ~6px inner dot in that same disabled grey (DLS's
 *   `radio-disc` recipe, not a colour token of its own — radio.scss uses
 *   the identical ring-and-disc shape for the same reason).
 * - `inactive` — the same ring, no dot.
 * - `completed` — the ring recolours to `--color-icon-success`; tokens.css
 *   has no token by that exact name, so this uses `--color-success-strong`
 *   (#00ab61), which its own tokens.css comment already documents as
 *   "icon-success / border-success" — the harvested value matches
 *   exactly. A small filled checkmark glyph sits inside the ring.
 * - `error` — the ring recolours to `--color-icon-danger`; again no token
 *   by that name, so this uses `--color-danger` (#ff4724, "Status/Danger/
 *   Normal, and color/border-danger/default") — the same substitution
 *   `ui-stepper-marker` already reports for the identical gap. A filled
 *   exclamation glyph sits inside the ring.
 * - `null` — DLS's deprecated "not started" marker: renders nothing
 *   visible but keeps the 16×20 box, so a mixed list of statuses never
 *   loses its column alignment.
 *
 * RESKIN: delegate to the DLS Angular tracker-marker; keep selector +
 * the `status` input's five-value union.
 */
declare class UiTrackerMarker {
    status: _angular_core.InputSignal<UiTrackerStatus>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTrackerMarker, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTrackerMarker, "ui-tracker-marker", never, { "status": { "alias": "status"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * `ui-tracker` — the DLS 3.1 `Tracker` component (page 207412:99 +
 * guideline 237778:405, REGISTER.md §43), replacing the
 * hand-rolled `ui-timeline` (`done | current | pending`, three marker
 * states, no sub-events, no inline actions, no OR divider, no horizontal
 * form) that stood in for it across the Special Requests audit-log and
 * workflow drawers and the monitoring signoff-audit drawer.
 *
 * **The guideline's Stepper-vs-Tracker table is the reason this is not
 * `ui-stepper`** (237778:5822, alpha-draft): Stepper is linear AND
 * non-linear, lets a user move BETWEEN steps, forbids inline actions, is
 * chronological only, and exists to collect input across guided steps.
 * Tracker is **linear only**, **navigation not supported** (no roving
 * tabindex, no arrow-key step navigation, no "click a step to jump" —
 * `ui-stepper`'s `interactive`/`current`/`stepSelected` axis has no
 * equivalent here), **allows inline actions for follow-up tasks**, reads
 * **chronological or reverse**, and exists to show workflow progress or
 * status after the fact. The only interactive parts anywhere in this
 * family are `ui-tracker-event`'s expand chevron and a caller's own
 * `[uiTrackerActions]` buttons.
 *
 * `ui-tracker` itself is a thin layout host — content is PROJECTED, not
 * driven by a data array, because an event's title/tag/actions/slots are
 * arbitrary caller markup an array shape can't express:
 *
 *   <ui-tracker orientation="vertical">
 *     <ui-tracker-event status="completed" first title="Submitted">…</ui-tracker-event>
 *     <ui-tracker-event status="active" title="Under review">…</ui-tracker-event>
 *     <ui-tracker-event status="inactive" last title="Closed">…</ui-tracker-event>
 *   </ui-tracker>
 *
 *   <ui-tracker orientation="horizontal">
 *     <ui-tracker-step status="completed" first label="Submitted" />
 *     <ui-tracker-step status="active" label="Under review" />
 *     <ui-tracker-step status="inactive" last label="Closed" />
 *   </ui-tracker>
 *
 * **Anatomy in numbers** — vertical: `ui-tracker-event`'s 16px marker
 * rail (2px `--color-icon-disabled` line, split above/below the marker,
 * the split omitted at `first`/`last` so the rail runs continuous) + 8px
 * gap + content (12px vertical padding, 8px gap; the card itself 4px
 * padding pulled out −4px horizontal/top). Sub-events: 16px rail (line
 * only, no dot) + 8px gap + a 12h/8v-padded tinted card. Divider: a
 * hairline / "OR" / a hairline, 8px vertical padding. Horizontal:
 * `flex: 1` steps, a centred marker with connectors to the row edges,
 * label 4px below.
 *
 * RESKIN: delegate to the DLS Angular tracker; keep this selector and the
 * `orientation` input, and keep every child selector below unchanged —
 * `ui-tracker-event`, `ui-tracker-sub-event`, `ui-tracker-marker`,
 * `ui-tracker-divider`, `ui-tracker-step`.
 */
declare class UiTracker {
    orientation: _angular_core.InputSignal<"vertical" | "horizontal">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTracker, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTracker, "ui-tracker", never, { "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * `ui-tracker-event` — the DLS 3.1 `tracker-vertical`/`parent-event`
 * (Figma 207412:41377 + 207412:40546, REGISTER.md §43), the
 * row `ui-tracker` composes for `orientation="vertical"`:
 *
 *   <ui-tracker-event status="active" title="Under review" expandable [(expanded)]="open">
 *     <span uiTrackerMeta>Assigned to Sato Yuki</span>
 *     <div uiTrackerActions>
 *       <button type="button" ui-button variant="secondary" size="small" (click)="edit()">Edit</button>
 *     </div>
 *     <ui-tracker-sub-event status="success" title="Approved" />
 *   </ui-tracker-event>
 *
 * **Rail** — a 16px marker column + 8px gap + content. The column draws a
 * 2px `--color-icon-disabled` line in two flex segments straddling the
 * `ui-tracker-marker`, exactly `ui-stepper`'s vertical connector technique
 * (stepper.scss's `.marker-col`/`.connector`): the row stretches to the
 * height its own content needs, both segments are `flex: 1`, and the one
 * above is hidden at `first` / below at `last` — because every event in a
 * column shares this same rail width at the same x-offset and touches its
 * neighbour with zero gap (`tracker.scss`), the segments read as one
 * unbroken line down the whole tracker.
 *
 * **Content** — 12px vertical padding, 8px gap between: the card, an
 * optional `[uiTrackerActions]` row, and the projected sub-events. The
 * card itself is 4px padding, radius `--radius-sm` (DLS `action-alt`, 4 —
 * tokens.css has no `-alt` variant so this reuses the plain action radius,
 * same 4px value), pulled −4px horizontal/top so its text still lines up
 * with the rail's neighbours despite the padding. Card header: `title`
 * (`type.body(md, $bold: true)`, `--color-text-strong`, ellipsis, 24px
 * min-height), an optional `statusTag`/`statusVariant` through
 * `ui-status-tag`, and — when `expandable` — a 24px chevron that rotates
 * 180° on `expanded`. Metadata lines project through `[uiTrackerMeta]`,
 * each `type.body(sm)` `--color-text-subtle`.
 *
 * **Interactivity** — the guideline's ruling (tracker.ts's class doc)
 * limits this whole family to the expand chevron and inline actions, no
 * step navigation. Rather than wire the 24px chevron as its own nested
 * `ui-icon-button` (a button inside a card that ALSO wants hover/pressed/
 * focus paint would be a nested-interactive control with nothing to
 * `stopPropagation` against), this follows `ui-card`'s already-proven
 * collapsible-header precedent: the CARD is the toggle
 * (`role="button"`/`tabindex`/`aria-expanded`/Enter+Space) when
 * `expandable`, the chevron is a decorative `aria-hidden` glyph inside it,
 * and Hover/Pressed/Focused paint the card exactly as the DLS anatomy
 * says. A caller's own `[uiTrackerActions]` buttons sit BELOW the card and
 * are independently focusable/clickable — they do not affect the card's
 * own hover paint (the DLS text pairs "expandable or an action exists" as
 * the reason a card gets ANY interactive chrome at all; since actions live
 * outside the card's own box, this reads that as "the card is interactive
 * when `expandable`", not as actions reaching up into the card's hover).
 *
 * Children (`ui-tracker-sub-event`, or a caller's own nested events) are
 * projected through the ONE default `<ng-content />`, below the card, and
 * hidden via a class toggle when `expandable && !expanded` — never a
 * second `<ng-content select>` branch (Angular projects into the first
 * matching branch in source order; this kit's own migration notes call
 * that trap out repeatedly).
 *
 * RESKIN: delegate to the DLS Angular tracker-vertical parent-event; keep
 * this selector and every input/slot name.
 */
declare class UiTrackerEvent {
    status: _angular_core.InputSignal<UiTrackerStatus>;
    first: _angular_core.InputSignalWithTransform<boolean, unknown>;
    last: _angular_core.InputSignalWithTransform<boolean, unknown>;
    expandable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Two-way — the caller can drive it open/closed as well as read it. */
    expanded: _angular_core.ModelSignal<boolean>;
    title: _angular_core.InputSignal<string | undefined>;
    statusTag: _angular_core.InputSignal<string | undefined>;
    statusVariant: _angular_core.InputSignal<UiTagVariant | undefined>;
    protected onCardActivate(): void;
    protected onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTrackerEvent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTrackerEvent, "ui-tracker-event", never, { "status": { "alias": "status"; "required": false; "isSignal": true; }; "first": { "alias": "first"; "required": false; "isSignal": true; }; "last": { "alias": "last"; "required": false; "isSignal": true; }; "expandable": { "alias": "expandable"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "statusTag": { "alias": "statusTag"; "required": false; "isSignal": true; }; "statusVariant": { "alias": "statusVariant"; "required": false; "isSignal": true; }; }, { "expanded": "expandedChange"; }, never, ["[uiTrackerMeta]", "[uiTrackerActions]", "*"], true, never>;
}

type UiTrackerSubEventStatus = 'active' | 'inactive' | 'success' | 'error' | 'custom';
/**
 * `ui-tracker-sub-event` — the DLS 3.1 `tracker-vertical/sub-event`
 * (Figma 207412:40793, REGISTER.md §43), the disclosed child
 * a `ui-tracker-event` reveals when `expandable`+`expanded`:
 *
 *   <ui-tracker-sub-event status="success" title="Approved" meta="Sato Yuki" timestamp="09:14" />
 *
 *   <ui-tracker-sub-event status="custom" title="ignored">
 *     <div uiTrackerSubContent>…arbitrary content…</div>
 *   </ui-tracker-sub-event>
 *
 * Marker column is the rail LINE only (no dot, no ring — a sub-event never
 * carries its own `ui-tracker-marker`), `last` omits the trailing segment.
 * The card: 12px horizontal / 8px vertical padding, radius `--radius-sm`,
 * tinted per status — `success` → `--color-bg-success-subtlest` (DLS
 * background-success_subtlest, #e2f8ef), `error` →
 * `--color-bg-danger-subtlest` (the danger-subtlest equivalent, #fff0f0),
 * `active`/`inactive` → `--color-bg-app` (the neutral subtlest step this
 * kit has), `custom` → NO tint, the whole card body handed to the caller
 * through `[uiTrackerSubContent]` instead of this component's own header/
 * description anatomy. Header: `title` (`type.body(sm, $bold: true)`
 * `--color-text-strong`) + an optional `statusTag`/`statusVariant` pushed
 * right. Description row: `meta` (flex: 1) + `timestamp` (right-aligned),
 * both `type.body(sm)` `--color-text-subtle`.
 *
 * RESKIN: delegate to the DLS Angular tracker sub-event; keep this
 * selector and every input/slot name.
 */
declare class UiTrackerSubEvent {
    status: _angular_core.InputSignal<UiTrackerSubEventStatus>;
    last: _angular_core.InputSignalWithTransform<boolean, unknown>;
    title: _angular_core.InputSignal<string | undefined>;
    statusTag: _angular_core.InputSignal<string | undefined>;
    statusVariant: _angular_core.InputSignal<UiTagVariant | undefined>;
    meta: _angular_core.InputSignal<string | undefined>;
    timestamp: _angular_core.InputSignal<string | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTrackerSubEvent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTrackerSubEvent, "ui-tracker-sub-event", never, { "status": { "alias": "status"; "required": false; "isSignal": true; }; "last": { "alias": "last"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "statusTag": { "alias": "statusTag"; "required": false; "isSignal": true; }; "statusVariant": { "alias": "statusVariant"; "required": false; "isSignal": true; }; "meta": { "alias": "meta"; "required": false; "isSignal": true; }; "timestamp": { "alias": "timestamp"; "required": false; "isSignal": true; }; }, {}, never, ["[uiTrackerSubContent]"], true, never>;
}

/**
 * `ui-tracker-divider` — the DLS 3.1 `tracker-vertical/group-divider`
 * (Figma 207705:18711, REGISTER.md §43): an **"OR"** rule
 * between two alternative branches of a vertical tracker:
 *
 *   <ui-tracker-event status="completed" first title="Request raised" />
 *   <ui-tracker-divider />
 *   <ui-tracker-event status="inactive" last title="Escalated to desk head" />
 *
 * A hairline, the word `OR` (`label`, default `'OR'`, `type.label(sm)`
 * `--color-text-strong`), another hairline, 8px vertical padding — the
 * marker column keeps drawing its 2px rail line so the branches above and
 * below still read as one continuous tracker, except when `last` (a
 * divider is never `first`: it only ever sits BETWEEN two events).
 *
 * RESKIN: delegate to the DLS Angular tracker group-divider; keep this
 * selector and both inputs.
 */
declare class UiTrackerDivider {
    label: _angular_core.InputSignal<string>;
    last: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTrackerDivider, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTrackerDivider, "ui-tracker-divider", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "last": { "alias": "last"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * `ui-tracker-step` — the DLS 3.1 `tracker-horizontal` event (Figma
 * 207973:35789, REGISTER.md §43), the row `ui-tracker`
 * composes for `orientation="horizontal"` (each `flex: 1`, wired by
 * `tracker.scss`):
 *
 *   <ui-tracker orientation="horizontal">
 *     <ui-tracker-step status="completed" first label="Submitted" />
 *     <ui-tracker-step status="active" label="Under review" />
 *     <ui-tracker-step status="inactive" last label="Closed" />
 *   </ui-tracker>
 *
 * A centred `ui-tracker-marker` with 2px connectors running to the row
 * edges. Colouring is decided PER STEP from its own `status` alone (no
 * sibling lookup needed — every step independently produces a boundary
 * colour that always agrees with its neighbour's, because there is always
 * exactly one `active` step preceded by zero or more `completed` ones):
 * the connector BEFORE this step is `--color-icon-success` (mapped to
 * `--color-success-strong`, same substitution `ui-tracker-marker`
 * documents) when this step is `completed` OR `active` — "progress has
 * reached at least here" — and the connector AFTER it is that same green
 * only when this step is `completed` — the active step's trailing
 * connector is where the green fill stops. Both connectors stay in the
 * DOM at `first`/`last` (so the marker stays centred in its `flex: 1`
 * cell) but the one running off the row is `visibility: hidden`.
 *
 * `label` sits 4px below, 8px horizontal padding, centred: `active` =
 * `type.body(sm, $bold: true)` `--color-text-strong`, `completed` =
 * `type.body(sm)` `--color-text-strong`, everything else (`inactive`,
 * `error`, `null` — DLS's horizontal anatomy defines only these three
 * label treatments) = `type.body(sm)` `--color-text-subtle`.
 *
 * RESKIN: delegate to the DLS Angular tracker-horizontal event; keep this
 * selector and every input.
 */
declare class UiTrackerStep {
    status: _angular_core.InputSignal<UiTrackerStatus>;
    first: _angular_core.InputSignalWithTransform<boolean, unknown>;
    last: _angular_core.InputSignalWithTransform<boolean, unknown>;
    label: _angular_core.InputSignal<string | undefined>;
    protected leftGreen: _angular_core.Signal<boolean>;
    protected rightGreen: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTrackerStep, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTrackerStep, "ui-tracker-step", never, { "status": { "alias": "status"; "required": false; "isSignal": true; }; "first": { "alias": "first"; "required": false; "isSignal": true; }; "last": { "alias": "last"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface UiSubTab {
    key: string;
    label: string;
    count?: number | string;
    /** Inert: no pointer, no keyboard stop, no selection. */
    disabled?: boolean;
}
/**
 * Second-level tab strip — DLS `sub-tab` / `sub-tab-group`
 * (REGISTER.md §41, `sub-tab` node 137463:4521, `sub-tab-group`
 * node 137463:4568, audited 4 Sep 2026): a 32px neutral-fill pill strip
 * that sits UNDER a page-level `ui-tabs` bar. No existing kit piece has
 * this anatomy — `ui-filter-tabs` is a bordered/outlined pill,
 * `ui-segmented` is one inset track — so this is a genuinely new
 * component, not a variant of either (see their own doc comments, which
 * make the equivalent argument against being folded into `ui-tabs`).
 *
 *   <ui-sub-tabs [tabs]="subTabs" [(active)]="activeSubTab" />
 *
 * Same `tabs`/`active` API SHAPE as `ui-tabs` (deliberately — one mental
 * model for "a row of switchable views" across the kit) but its own
 * `UiSubTab` interface: `disabled` exists here and not on `UiTab` because
 * DLS's sub-tab anatomy carries a disabled state and the page-level tab bar
 * never has one at any of its eight call sites.
 *
 * **Group** (137463:4568): 24px horizontal / 8px vertical padding, 8px gap
 * (`--gap-unit-h`) between pills.
 * **Tab** (137463:4521): 32 tall, 12px h-padding (`--padding-action-h-md`),
 * 4px internal gap (`--gap-unit-inline-h`), radius `action-alt` 4
 * (`--border-radius-action` — the two share the same 4px value in this
 * scale). Label `label(sm)`.
 * **Active** = bg `--color-bg-neutral` (#dde3e7), label
 * `--color-text-strong`, badge bg `--color-bg-inverse` (#59656d) / text
 * `--color-text-inverse` (white).
 * **Inactive** = transparent, label + badge text `--color-text-subtle`,
 * badge bg stays `--color-bg-neutral` (only the TEXT recolours between
 * active/inactive, not the badge fill).
 * **Badge**: 16 tall, min-width 16, `label(xs)` — same DLS badge geometry
 * as the page-level `ui-tabs` badge, just recoloured per state above.
 * **States**: DLS lists Default | Hover | Focus | pressed. Hover/pressed
 * values were not called out with their own hex in the harvest, so this
 * follows the kit's own established hover/pressed roles
 * (`--color-bg-hover` #eef2f5 / `--color-bg-pressed` #dde3e7 — the same
 * `ui-filter-tabs`/`ui-checkbox` convention), applied to INACTIVE tabs
 * only (an active pill already reads as "selected" via its neutral fill;
 * DLS doesn't define an Active+Hover treatment). Focus-visible = 2px
 * `--color-focus` ring, the kit's standard.
 *
 * ── Keyboard ──────────────────────────────────────────────────────────
 * Same roving-tabindex contract as `ui-tabs`/`ui-segmented`: one tab stop,
 * arrows MOVE and ACTIVATE, disabled entries are stepped over rather than
 * landable.
 */
declare class UiSubTabs {
    tabs: _angular_core.InputSignal<UiSubTab[]>;
    active: _angular_core.ModelSignal<string | undefined>;
    private readonly tabEls;
    protected readonly stopIndex: _angular_core.Signal<number>;
    protected select(tab: UiSubTab): void;
    protected onKeydown(event: KeyboardEvent, index: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiSubTabs, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiSubTabs, "ui-sub-tabs", never, { "tabs": { "alias": "tabs"; "required": true; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; }, { "active": "activeChange"; }, never, never, true, never>;
}

/**
 * Status dot — DLS `tag-status-dot` (§42, Figma 88972:307295), the other
 * face of `tag-status`: a 10px round dot + 4px gap + label/sm `text-strong`,
 * 20 tall, no pill fill of its own. Same five types as `ui-status-tag`
 * (neutral/green/red/amber/purple) and the SAME string → variant resolution
 * — `statusVariant` is imported from status-tag.ts rather than re-listing
 * the 21-call-site map here, so the two components can never drift apart on
 * what a given status string means.
 *
 *   <ui-status-dot status="Approved" />
 *   <ui-status-dot variant="green" label="Active" />
 *
 * The dot's own fill reuses the exact same `--color-tag-<variant>` token
 * the pill uses for its background (e2e f86 asserts this: "each variant's
 * dot colour matches its status-tag family") — DLS harvested no separate
 * "strong" dot palette for this node, so the kit does not invent one.
 *
 * NOT a `ui-status-tag` variant: this is a different DLS component
 * (`tag-status-dot`, a distinct node from `tag-status`) with different
 * anatomy — no pill background, a dot instead — answering the same "what
 * state is this in?" question in the sparser form a dense list needs. The
 * table's `.ui-cell-dot` (Round 40, table.scss) is a THIRD, table-specific
 * rendering with its own tone set; this is the standalone piece the lead's
 * §42 proposal names as the one `.ui-cell-dot` should eventually compose
 * from — that composition is not this round's job.
 *
 * RESKIN: check the Angular DLS Storybook for `tag-status-dot` and wrap it,
 * keeping the `ui-status-dot` selector, `status`/`label`/`variant` inputs,
 * and the shared `statusVariant` resolver.
 */
declare class UiStatusDot {
    status: _angular_core.InputSignal<string | undefined>;
    label: _angular_core.InputSignal<string | undefined>;
    variant: _angular_core.InputSignal<UiTagVariant | undefined>;
    protected resolvedVariant: _angular_core.Signal<UiTagVariant>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiStatusDot, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiStatusDot, "ui-status-dot", never, { "status": { "alias": "status"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Removable filter tag — DLS `tag-filter` (§42, Figma 89025:316489): 20
 * tall, radius `--border-radius-indicator` (4), background
 * `--color-bg-neutral`, 4px LEFT padding, label `type.label(sm)`
 * `--color-text-strong`, then a 20px-square close button carrying a 16×10
 * glyph, emitting `removed`. The button's own `:focus-visible` draws the
 * 2px `--color-focus` ring rounded ONLY on its right corners (`0 4px 4px
 * 0`, matching the host's own radius on that edge) — DLS draws the ring on
 * the button half, not the whole tag; see tag-filter.scss.
 *
 *   <ui-tag-filter label="Owner: Aiko Mori" (removed)="remove(t)" />
 *   <ui-tag-filter label="Region: APAC" [disabled]="true" />
 *
 * NOT `ui-chip`'s `chip-input`: that is a different DLS component (32px
 * tall, pill radius, a 24px CIRCLE icon-button remove control pulled in by
 * an optical margin — §11). This is DLS's own separate `tag-filter` node:
 * 20 tall, squared `indicator` radius, a 20px SQUARE remove control flush
 * against the tag's own trailing edge with no optical overlap, and a
 * focus ring confined to the button half rather than the whole chip. Two
 * DLS components with two different anatomies stay two kit components.
 *
 * This is an ARCHIVE piece (owner's §42 ruling, 4 Sep 2026): no the reference app call
 * site renders removable filter tags today — the platform's "All …"
 * filter selects follow the §21 clear-rule instead (no × until a value is
 * picked). Built for completeness/future use; demoed at
 * `#sink-tag-filter`.
 *
 * RESKIN: check the Angular DLS Storybook for `tag-filter` and wrap it,
 * keeping the `ui-tag-filter` selector, `label`/`disabled` inputs and the
 * `removed` output.
 */
declare class UiTagFilter {
    /** Tag text — the whole label, e.g. `"Region: APAC"`. */
    label: _angular_core.InputSignal<string>;
    /** Disables the remove control; the tag renders but cannot be removed. */
    disabled: _angular_core.InputSignal<boolean>;
    /** Emitted when the close button is activated. */
    removed: _angular_core.OutputEmitterRef<void>;
    protected onRemoveClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiTagFilter, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiTagFilter, "ui-tag-filter", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "removed": "removed"; }, never, never, true, never>;
}

type UiUploadStatus = 'starting' | 'uploading' | 'completed' | 'indeterminate' | 'uploaded' | 'failed' | 'readonly' | 'download' | 'non-cancelable';
/**
 * Upload-status row — DLS 3.1 `upload-file` (Figma 1161:1944, 320 wide,
 * REGISTER.md §45, built 4 Sep 2026). One file, one status,
 * nine statuses:
 *
 *   <ui-upload-file name="Passport.pdf" status="uploading" meta="40%" [progress]="40" (cancel)="abort()" />
 *   <ui-upload-file name="Trade confirmation.pdf" status="failed" (retry)="retry()" (cancel)="abort()" />
 *   <ui-upload-file name="Statement Q2.pdf" status="download" meta="2.1 MB" (download)="save()" (remove)="drop()" />
 *
 * **DLS's "User uploaded" `File` type (§46, Figma 135552:1133) IS this row
 * in `download` status — Figma notes it is "limited to the upload
 * component". `ui-file-row` does NOT reimplement it; a caller who needs
 * that shape reaches for `ui-upload-file` directly with `status="download"`.**
 *
 * **Anatomy**: `:host` carries the row's 12px vertical padding
 * (`--padding-panel-v-sm`, the same token `ui-file-row`'s own row uses).
 * The row is `Left content` (a 40px `ui-file-thumbnail` + 8px gap
 * (`--gap-unit-h`) + a title block at 4px gap (`--gap-unit-v`): `name` in
 * `label(sm)` `--color-text-strong`, a second line in `body(sm)`
 * `--color-text-subtle` — EXCEPT `failed`, where the second line is
 * `errorMessage` in `--color-text-danger` regardless of `meta`) then
 * `Actions` at 4px gap (`--gap-unit-inline-h`) of 32px `ui-icon-button`s.
 * An optional 4px progress bar sits 8px (`--gap-unit-h`) below the row.
 *
 * **Which actions per status** (REGISTER.md §45's table):
 * starting / uploading / indeterminate / completed → Close (`cancel`);
 * uploaded → Trash (`remove`); failed → Retry (`retry`) THEN Close
 * (`cancel`); readonly → none; download → Download (`download`) THEN
 * Trash (`remove`); non-cancelable → a spinner, no buttons. Implemented
 * as one flat sequence of `@if`s (retry, download, close, trash, spinner)
 * gated by small per-status computed booleans rather than a `@switch`
 * with duplicated close-button markup for four statuses — the ordering
 * falls out correctly because at most one of {retry+close} / {download+
 * trash} / {close} / {trash} / {spinner} is ever true for a given status.
 *
 * **Progress bar** — reuses `ui-progress-bar` UNCHANGED rather than
 * hand-rolling a second 4px pill: that component's own value/state
 * contract (1–99% warning fill, 100% success fill, 0% no fill,
 * `state="indeterminate"` sweeps and ignores `value`) is EXACTLY DLS's
 * `upload-file` bar rule, not a coincidence worth re-deriving. Rendered
 * only for the five statuses that show a bar (`BAR_STATUSES` above) — not
 * `failed` (DLS shows the error line instead), not `uploaded` / `readonly`
 * / `download` (the transfer is already resolved), matching the source
 * register's own status table.
 *
 * **Spinner (`non-cancelable`)** — DLS shows a small spinner, no buttons.
 * `ui-loader` (§27) has no dedicated "tiny" size, but its bare `spinner`
 * kind with `[background]="false"` is a 32px mark with no tile — the
 * SAME footprint as this row's other 32px icon-button actions, so it
 * drops into the actions slot without a hand-rolled CSS spinner. Reported
 * as the nearest-fit reuse, not a true "tiny" variant, in the round's
 * report.
 *
 * RESKIN: delegate to the DLS Angular `upload-file`; keep selector, every
 * input/output name and the nine `UiUploadStatus` values unchanged.
 */
declare class UiUploadFile {
    name: _angular_core.InputSignal<string>;
    /** Second line — a percentage, a size, or a status message. Ignored (and
     *  replaced by `errorMessage`) while `status` is `failed`. */
    meta: _angular_core.InputSignal<string>;
    status: _angular_core.InputSignal<UiUploadStatus>;
    /** 0–100, passed straight through to `ui-progress-bar`. */
    progress: _angular_core.InputSignal<number>;
    /** Passed straight through to the leading `ui-file-thumbnail`. */
    fileType: _angular_core.InputSignal<UiFileThumbnailType>;
    errorMessage: _angular_core.InputSignal<string>;
    cancel: _angular_core.OutputEmitterRef<void>;
    retry: _angular_core.OutputEmitterRef<void>;
    remove: _angular_core.OutputEmitterRef<void>;
    download: _angular_core.OutputEmitterRef<void>;
    protected readonly showRetry: _angular_core.Signal<boolean>;
    protected readonly showDownload: _angular_core.Signal<boolean>;
    protected readonly showClose: _angular_core.Signal<boolean>;
    protected readonly showTrash: _angular_core.Signal<boolean>;
    protected readonly showSpinner: _angular_core.Signal<boolean>;
    protected readonly showBar: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiUploadFile, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiUploadFile, "ui-upload-file", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "meta": { "alias": "meta"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "progress": { "alias": "progress"; "required": false; "isSignal": true; }; "fileType": { "alias": "fileType"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; }, { "cancel": "cancel"; "retry": "retry"; "remove": "remove"; "download": "download"; }, never, never, true, never>;
}

/**
 * DLS 3.1 — Enterprise `page-header` Type axis (REGISTER.md
 * §49, Enterprise file `zTm6jM3QO8DCAMr51coADe`, set 78711:140286). All
 * nine Desktop symbols, per the owner's 5 Sep 2026 ruling — Tablet/Mobile
 * skipped per the standing desktop-only pattern of the walk.
 */
type UiPageHeaderType = 'default' | 'homepage' | 'breadcrumb' | 'breadcrumb-tabs' | 'dropdowns' | 'dropdowns-tabs' | 'role-switcher' | 'tabs' | 'stepper';
/**
 * Whether this header supplies the house 24px gap below its bottom rule
 * (lead ruling R2) — see `contentGap` on the component, and the
 * "content gap" block in its doc comment for when `none` is correct.
 */
type UiPageHeaderContentGap = 'default' | 'none';
/**
 * `ui-page-header` — the DLS 3.1 Enterprise page header (§49, page
 * `77398:124984`), the shared chassis every page-level title on the
 * platform should sit inside. `h1[ui-page-title]` is TYPOGRAPHY ONLY by
 * its own doc comment ("layout — truncation, header height, padding —
 * belongs to the host page, never here"); this component is now that
 * host, composing `ui-page-title` + `ui-status-tag` + `ui-avatar` +
 * `ui-icon-button` rather than re-drawing any of their anatomy.
 *
 *   <ui-page-header title="Trade Monitoring">
 *     <button uiPageHeaderActions ui-button variant="secondary" size="tiny">Export</button>
 *     <button uiPageHeaderActions ui-icon-button size="small" outline aria-label="More options">…</button>
 *   </ui-page-header>
 *
 *   <ui-page-header type="tabs" title="Murex V2" avatarName="Tanaka Hiroshi" statusTag="Live">
 *     <ui-tabs uiPageHeaderTabs [tabs]="tabs" [(active)]="activeTab" />
 *   </ui-page-header>
 *
 * ── Chassis (Desktop only) ────────────────────────────────────────────
 * bg `--color-bg-level2`, 1px `--color-border-decorative` bottom rule,
 * 40px horizontal / 16px vertical padding (`--padding-panel-h-xl` /
 * `--padding-panel-v-md` — both already existed, no new tokens), 16px
 * gap between rows. The 40px DELIBERATELY matches the owner's own
 * grey-area content rule (24 top/bottom, 40 left/right) — see
 * `tokens/layout`'s `content-padding` mixin — so a page header sits flush
 * with the content beneath it; that mixin itself is not used here because
 * its own vertical side is 24, not this component's 16.
 *
 * ── `header-text` (shared by every type except Homepage) ─────────────
 * Optional 48px `ui-avatar` (`size="lg"`) + 16px gap + a text column
 * (4px gap, min-height 32, same shape `ui-drawer`'s `.title-group` and
 * `ui-table-header`'s `.caption` already use) = a title row (8px gap)
 * holding `h1[ui-page-title]` + an optional `ui-status-tag`, then an
 * optional subtitle in `type.body(md)` `--color-text-body` — DLS names
 * this role plain, unqualified `color/text`; this token set has no bare
 * `--color-text` (see `ui-tabs`'s badge for the same substitution and the
 * same recorded TOKEN GAP), so `-body` stands in as the nearest
 * "default, unqualified" role.
 *
 * `back` renders a 32px `ui-icon-button` (24px chevron-left) pulled
 * `margin-left: -8px` ahead of the header-text — the exact optical-align
 * value `ui-table-header`'s own `.back` already uses for this identical
 * 32-box/24-glyph pairing (`ui-drawer`'s equivalent trick pulls -4px
 * instead; the two existing DLS harvests disagree by 4px on the same
 * geometry, and this component follows the more recent, more literally
 * specified `ui-table-header` number rather than re-deriving one from
 * inset math). Input `back` is a plain boolean; the output is ALIASED
 * back onto the same name (`(back)`, not `(backActivated)`) per the
 * brief's literal contract — Angular's `output({ alias })` makes this
 * safe despite the shared name, since the class field itself is
 * `backActivated` (no duplicate-identifier collision) while the template
 * binding surface reads `back` / `(back)`, matching `ui-drawer` and
 * `ui-table-header`'s shared vocabulary for the SAME concept.
 *
 * ── Actions cluster (`[uiPageHeaderActions]`, 8px gap, right-aligned) ──
 * OWNER'S RULING (5 Sep 2026): secondary buttons keep the KIT's existing
 * 12px padding (`ui-button`'s own default), NOT DLS's own 24px, "because
 * the reference app uses the tiny button size" — so this component adds NO local
 * padding override; the caller's `button[ui-button]` already lands on
 * the right value with zero extra CSS. Trailing icon-only actions reuse
 * the kit's EXISTING `outline` boolean on `ui-icon-button` (already
 * harvested from DLS's Outline axis) — again nothing new here, the
 * caller just writes `outline`.
 *
 * ── The other five region slots ───────────────────────────────────────
 * `[uiPageHeaderBreadcrumb]` — a projected `ui-breadcrumb`, sharing its
 * row with `[uiPageHeaderActions]` (Types `breadcrumb` / `breadcrumb-tabs`).
 * `[uiPageHeaderDropdowns]` — one or more tiny PLAIN `button[ui-button]`s
 * with a trailing `uiButtonIconRight` chevron-down (DLS has no dedicated
 * dropdown-button component in this kit; `ui-button variant="plain"
 * size="tiny"` is the closest existing shape, per the register's own
 * call — report if a future round wants a real popover behind it). Same
 * row as actions (Types `dropdowns` / `dropdowns-tabs` / `role-switcher`
 * — the DLS "role switcher" is layout-identical to `dropdowns`, just ONE
 * button instead of up to three; that's a caller content difference, not
 * a structural one, so both types share the same CSS).
 * `[uiPageHeaderTabs]` — a projected `ui-tabs` (its default `plain`
 * variant already carries zero horizontal padding, so it lands flush
 * with the chassis's own 40px inset with no extra CSS here — "do NOT
 * build a second tab bar" per the brief). `[uiPageHeaderStepper]` — a
 * projected `ui-tracker[orientation="horizontal"]` wrapping
 * `ui-tracker-step`s. Both sit in the SAME `.ph-strip` row, below
 * header-text, never padded locally.
 *
 * ── The bottom rule is the HOST's, on every type (walk item 2, 6 Sep) ──
 * The 1px `--color-border-decorative` bottom border is drawn by the host
 * element, edge to edge OUTSIDE the 40px padding, for all nine types
 * except Homepage. On the three tab types the strip is the last row with
 * zero padding beneath it, so the host rule sits directly under the
 * 40px tab strip; the projected `ui-tabs`'s own bottom rule (which would
 * be inset 40px, stopping short of the edges) is suppressed via
 * `::ng-deep` in page-header.scss so exactly ONE line shows.
 *
 * ── The 24px content gap is the HEADER's too (lead ruling R2, 6 Sep) ──
 * The house rule is 24px between a page header and the content below it,
 * and it must not scroll away. Every page used to spend its scroller's own
 * `padding-top: 24px` (`layout.content-padding`'s top side) on it, and a
 * scroller's padding travels with its content — so the first row slid up
 * and touched the bottom rule on the first wheel tick. Walk item 15 patched
 * three named pairs; P3 found five more with the identical bug. So this
 * component carries it: a 24px `margin-bottom` (MARGIN, so it sits outside
 * the full-bleed bottom rule of item 2 and reads as grey rather than as
 * more header surface) on all eight non-Homepage types. Homepage — a
 * full-bleed band with no rule — keeps zero.
 *
 * CONSUMING PAGES MUST NOW SET THEIR SCROLLER'S `padding-top: 0`
 * (`layout.content-padding($scroll: true)` still supplies the 40px sides
 * and the bottom); a page that keeps its own 24 will render 48. Two pages
 * already carry a hand-written 24px header override from walk item 15
 * (`orders.scss` `.page-header { margin-bottom: 24px }` and
 * `special-requests.scss`'s equivalent) — those come OUT, they are this
 * rule now. Watch for a parent that is a flex/grid COLUMN WITH ITS OWN
 * `gap`: the margin adds to the gap rather than replacing it.
 *
 * ── `contentGap="none"` — when the next sibling is not content (R5) ────
 * R2's 24px is the header→CONTENT gap. A header whose next sibling is
 * page CHROME rather than a scrolling content region wants zero, and
 * `contentGap="none"` is that seam: it sets `margin-bottom: 0` and adds
 * the host class `ph--gap-none`. The shape it exists for is
 * `npa/pre-npa-document`, whose header is followed by a two-pane flex ROW
 * — a 320px white section navigator with its own `border-right` beside the
 * main scroller. R2's margin there would drop a full-width grey
 * `--color-bg-app` band between the header's rule and the SIDEBAR,
 * detaching a piece of chrome meant to sit flush; the only element that
 * wants the 24 is `.main-scroll`, two levels down, which already has it.
 * Same test for any future page: does the element directly under the
 * header scroll? If not, this input; if yes, leave it `default`.
 *
 * THIS IS THE ONLY WAY TO OPT OUT. A page must NOT go back to overriding
 * the margin from its own stylesheet — a per-page `margin-bottom` on a kit
 * component is exactly what R2 abolished, and the reason the gap moved
 * here was that page-side copies of it kept drifting and kept coming back
 * wrong on new pages. An opt-out written as an input is one grep away and
 * carries its reason with it; an opt-out written in a page's scss is not.
 * `type="homepage"` needs neither: it forces zero on its own, whatever
 * `contentGap` says (`:host(.ph--homepage)`, below the base rule in
 * page-header.scss, is (0,2,0) against the bare `:host`'s (0,1,0)).
 *
 * KNOWN KIT TRAP avoided (documented in `ui-table-header`'s own doc
 * comment and hit repeatedly across this kit): every `<ng-content
 * select="…">` above appears EXACTLY ONCE in the template, unconditionally,
 * in a fixed DOM position — never duplicated across `@if`/`@switch`
 * branches, which would project content into only the FIRST branch in
 * source order and silently drop the rest. The nine `type()` values
 * change ONLY which named CSS grid area each fixed region lands in (see
 * page-header.scss) and whether an empty region collapses via `:empty`
 * (the same always-render-let-:empty-collapse pattern `ui-drawer`'s
 * footer and `ui-alert`'s actions slot use) — never which elements exist.
 *
 * ── Homepage — the one type that differs ──────────────────────────────
 * A full-bleed band, 40/24 padding (not the chassis's 40/16) and no
 * bottom border. CORRECTED round 43 (node 79603:128074, live Figma
 * session): DLS's own band is a licensed Unsplash photograph
 * (milad-fakurian-E8Ufcyxz514-unsplash) with two blurred ellipse SVGs
 * over it, NOT a gradient — a prior pass invented three saturated hexes
 * and mislabelled them DLS stops. A white-label kit can't ship a
 * licensed photo, so this component's default is an honest, soft
 * token-based wash instead (tokens.css, "Page header — Homepage band"),
 * exposed as an OVERRIDABLE seam (`--ui-page-header-homepage-bg`,
 * page-header.scss) so a product can supply its own art without forking
 * this component. An `eyebrow` line (`label(sm)`), a greeting (bound to
 * `title`, `heading(sm)` semibold) and `subtitle` (`body(md)`), all in
 * `--color-text-on-dim` (white) — deliberately NOT `h1[ui-page-title]`,
 * whose color is hard-coded `--color-text-strong` inside its own
 * encapsulated stylesheet and so cannot be repainted white from outside.
 * That is the one place this component does NOT compose `ui-page-title`;
 * everywhere else it does — but it still types the greeting through the
 * kit's `heading()` role mixin, never a raw px size. `avatar`/`statusTag`/
 * `back` are not part of the Homepage anatomy per the register and are
 * simply not rendered in that branch. Homepage's single action still
 * reaches the SAME `[uiPageHeaderActions]` slot as every other type — the
 * caller supplies `button[ui-button] variant="plain" tone="on-dim"` with
 * a leading 16px icon slot — but this component pulls the WHOLE cluster
 * out of flow via `::ng-deep`, absolutely positioning it at the band's
 * bottom-right (16 / 32) and resizing the projected button to 40px /
 * `label(md)`, both per the harvest (page-header.scss has the full
 * specificity reasoning for reaching through a projected `ui-button`).
 *
 * RESKIN: delegate to the DLS Angular `page-header`; keep this selector,
 * every input/output and all five slot names unchanged.
 */
declare class UiPageHeader {
    /** DLS's Type axis — see `UiPageHeaderType` above. */
    type: _angular_core.InputSignal<UiPageHeaderType>;
    /**
     * `default` (the house rule, R2) — a 24px `margin-bottom` below the
     * full-bleed rule, which the content region under the header must NOT
     * duplicate as its own `padding-top`.
     * `none` — zero, for a header followed by page chrome rather than a
     * scrolling content region (a two-pane flex row, a section navigator).
     * `type="homepage"` is zero either way. Full reasoning, and why this
     * input rather than a page-side override, in the doc comment above.
     */
    contentGap: _angular_core.InputSignal<UiPageHeaderContentGap>;
    /** The page title (non-Homepage) or the greeting text (Homepage). */
    title: _angular_core.InputSignal<string | undefined>;
    /** Optional descriptive line under the title/greeting. */
    subtitle: _angular_core.InputSignal<string | undefined>;
    /**
     * Homepage: the small line above the greeting (e.g. "Good morning").
     * Every other type: a small kicker INLINE before the title, label(xs)
     * subtle (e.g. "Desk:" before a desk name on Mandates).
     */
    eyebrow: _angular_core.InputSignal<string | undefined>;
    /** Optional pill beside the title. Passed straight through as `ui-status-tag`'s `label`. */
    statusTag: _angular_core.InputSignal<string | undefined>;
    /** `ui-status-tag`'s colour variant — defaults to its own `neutral` fallback when unset. */
    statusVariant: _angular_core.InputSignal<UiTagVariant | undefined>;
    /** Renders the 48px `ui-avatar` in the header-text block when set — the name it initials-izes. */
    avatarName: _angular_core.InputSignal<string | undefined>;
    /**
     * Shows the leading chevron-left back button. Bare-attribute ergonomics
     * (`transform: booleanAttribute`) match every other boolean input in
     * this kit that sits next to `disabled`/`outline`.
     */
    back: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Fires on a real click of the back button. Aliased onto the SAME name
     * as the `back` input (`(back)` in a template) per this component's
     * brief — the class field is `backActivated` (matching `ui-drawer` /
     * `ui-table-header`'s existing vocabulary for this exact concept) only
     * because TypeScript forbids two class members literally named `back`;
     * the outward template contract is unaffected.
     */
    backActivated: _angular_core.OutputEmitterRef<void>;
    /**
     * `ph--gap-none` is a separate class, not a variant of `ph--<type>`,
     * because the two axes are independent: any of the nine types can opt
     * out of the content gap. Homepage carries both and still reads zero —
     * the two rules agree.
     */
    protected hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiPageHeader, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiPageHeader, "ui-page-header", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "contentGap": { "alias": "contentGap"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "eyebrow": { "alias": "eyebrow"; "required": false; "isSignal": true; }; "statusTag": { "alias": "statusTag"; "required": false; "isSignal": true; }; "statusVariant": { "alias": "statusVariant"; "required": false; "isSignal": true; }; "avatarName": { "alias": "avatarName"; "required": false; "isSignal": true; }; "back": { "alias": "back"; "required": false; "isSignal": true; }; }, { "backActivated": "back"; }, never, ["[uiPageHeaderBreadcrumb]", "[uiPageHeaderDropdowns]", "[uiPageHeaderActions]", "[uiPageHeaderTabs]", "[uiPageHeaderStepper]"], true, never>;
}

/**
 * The catalogue's NAMES — a type, and nothing but a type.
 *
 * THIS FILE EMITS NO JAVASCRIPT AT ALL. It is 569 string literals in a union
 * and not one runtime binding, so importing it — however many barrels the
 * import travels through — cannot put a byte in anyone's bundle. That is the
 * whole reason it is separate from ./catalogue.ts, which holds the same 569
 * names as a real array: the TYPE is needed everywhere (every call site that
 * types a field, every glyph module that annotates itself, `ui-icon` itself),
 * the ARRAY is needed by exactly one page.
 *
 * WHY THE UNION IS WRITTEN OUT rather than derived from the array with
 * `(typeof UI_ICON_NAMES)[number]`, which is what it used to be. Deriving it
 * is tidier to read and it is what put an 8,110-byte string array into
 * `main`: the derivation forces the type's module to also hold the value, and
 * anything that imports `ui-icon` (the nav rail, on the first route) drags
 * that module into the initial bundle whether or not it ever reads the array.
 * Writing the union out is what lets the two live in different chunks.
 *
 * DRIFT IS A COMPILE ERROR, both ways. ./catalogue.ts asserts that this union
 * and that array hold exactly the same names — a name here and not there, or
 * there and not here, fails `tsc` and names the offender. See the assertions
 * at the foot of that file; they are the reason two declarations of one list
 * is safe rather than a bug waiting to happen.
 *
 * The union is EXACT: an unknown name is a compile error at every TypeScript
 * call site, which is the whole reason the registry is typed rather than
 * stringly. `ui-icon` also throws on an unknown name at runtime, which is
 * what catches a template-only typo the type cannot see.
 *
 * GENERATED from the registry. Adding a name means adding it HERE, in
 * ./catalogue.ts, and giving it a glyph in exactly one tier: ./eager.ts (with
 * its geometry in ./glyphs/eager.ts) or ./manifest.ts (with its geometry in
 * ./glyphs/<category>.ts, or ./glyphs/platform.ts if the platform draws it
 * off the first paint). A name with no glyph in either tier fails the
 * exhaustiveness check in ./manifest.ts at BUILD time.
 */
type UiIconName = 'admin-setting' | 'admin-setting-filled' | 'airplane-shield' | 'airplay' | 'alarm-reminder-vibrate' | 'align-center' | 'align-justify' | 'align-left' | 'align-right' | 'ambulance' | 'anchor' | 'aperture' | 'archive' | 'arrow-corner-down-right' | 'arrow-down' | 'arrow-down-circle' | 'arrow-down-filled' | 'arrow-down-left' | 'arrow-down-right' | 'arrow-left' | 'arrow-left-circle' | 'arrow-redo' | 'arrow-right' | 'arrow-right-circle' | 'arrow-right-filled' | 'arrow-trending-down' | 'arrow-trending-up' | 'arrow-undo' | 'arrow-up' | 'arrow-up-circle' | 'arrow-up-filled' | 'arrow-up-left' | 'arrow-up-right' | 'arrows-up-down-filled' | 'at-sign' | 'atm' | 'award' | 'backspace' | 'bag-cash' | 'bag-cash-up' | 'bank-account' | 'bank-delete' | 'bank-limit' | 'bank-mail' | 'bank-plus' | 'bank-repeat' | 'bank-to-bank' | 'bar-chart' | 'bar-chart-ascending' | 'basketball' | 'battery' | 'battery-charging' | 'beauty-lipstick' | 'bell' | 'bell-alert' | 'bell-filled' | 'bell-off' | 'block' | 'bluetooth' | 'bold' | 'book' | 'book-bank-account' | 'book-open' | 'book-search' | 'bookmark' | 'bookmark-filled' | 'box' | 'box-open' | 'branch' | 'branch-location' | 'briefcase-filled' | 'briefcase-stat' | 'bubble-bulb' | 'bubble-burst' | 'business-chart' | 'cable-tv' | 'calculator-leaf' | 'calendar' | 'calendar-bank' | 'calendar-money' | 'call-document' | 'camera' | 'camera-off' | 'car-front' | 'card-bank-building' | 'card-dollar-sign' | 'card-limit' | 'card-lock' | 'card-plus-square' | 'card-stack-coins' | 'card-to-card' | 'card-to-card-triangle' | 'card-to-mobile' | 'card-verify' | 'card-view-hide' | 'caret-down' | 'caret-right' | 'cart-plant' | 'cash-chart' | 'cash-deactivation' | 'cash-deposit' | 'cash-hand-pickup' | 'cash-stacked-coins' | 'cash-withdrawn' | 'cast' | 'chart-bar' | 'chart-circle' | 'chart-search' | 'chart-up' | 'charts-copy' | 'chat' | 'chat-dollar' | 'chat-dollar-filled' | 'chatbot' | 'check' | 'check-circle' | 'check-square' | 'checkbox-dash' | 'checkbox-tick' | 'checklist-pen' | 'checklist-pen-filled' | 'chevron-double-left' | 'chevron-double-right' | 'chevron-down' | 'chevron-left' | 'chevron-left-last' | 'chevron-right' | 'chevron-right-last' | 'chevron-top-last' | 'chevron-up' | 'chevrons-down' | 'chevrons-left' | 'chevrons-right' | 'chevrons-up' | 'chrome' | 'circle' | 'circle-checkmark' | 'circle-checkmark-filled' | 'circle-clipboard-filled' | 'circle-clock-filled' | 'circle-exclamation' | 'circle-exclamation-filled' | 'circle-information' | 'circle-information-filled' | 'circle-phone' | 'circle-question' | 'circle-x' | 'circle-x-filled' | 'clear-filled' | 'clipboard' | 'clipboard-with-checkmark' | 'clock' | 'clock-pending' | 'clockwise-arrows' | 'close' | 'cloud' | 'cloud-download' | 'cloud-drizzle' | 'cloud-lightning' | 'cloud-off' | 'cloud-rain' | 'cloud-snow' | 'cloud-upload' | 'code' | 'codepen' | 'codesandbox' | 'coins-crypto' | 'coins-stack' | 'color-palette' | 'columns' | 'command' | 'comment-pencil' | 'comment-pencil-filled' | 'company-building' | 'compass' | 'contactless-card' | 'contrast' | 'copy' | 'corner-down-left' | 'corner-down-right' | 'corner-left-down' | 'corner-left-up' | 'corner-right-down' | 'corner-right-up' | 'corner-up-left' | 'corner-up-right' | 'counter-clockwise-arrows' | 'coupon-percent' | 'coupon-percent-filled' | 'cpu' | 'credit-card' | 'crop' | 'crosshair' | 'crypto' | 'cup' | 'currency-exchange' | 'currency-exchange-coins' | 'cursor-default' | 'cursor-move' | 'database' | 'dbs-logo' | 'delete' | 'delete-card' | 'deposit' | 'diagonal-inward-arrows' | 'diagonal-outward-arrows' | 'digistore' | 'disc' | 'divide' | 'document' | 'document-chart' | 'document-checkmark' | 'document-compass' | 'document-compass-filled' | 'document-lines' | 'document-pdf' | 'document-pen' | 'document-pen-filled' | 'document-percent' | 'document-user' | 'dollar-sign' | 'dollar-sign-single' | 'dollar-square-filled' | 'dollar-stats' | 'double-lines-horizontal' | 'download' | 'dribbble' | 'droplet' | 'dual-currency' | 'edit' | 'edit-box' | 'edit-line' | 'electricity' | 'electricity-off' | 'estatement' | 'exchange' | 'exclamation' | 'external-link' | 'eye' | 'eye-money' | 'eye-off' | 'facebook' | 'fashion-shirt' | 'fast-forward' | 'feather' | 'figma' | 'file' | 'file-clock' | 'file-csv' | 'file-doc' | 'file-image' | 'file-link' | 'file-minus' | 'file-pdf' | 'file-plus' | 'file-ppt' | 'file-text' | 'file-xls' | 'film' | 'filter' | 'filter-funnel' | 'filter-off' | 'filter-simple' | 'filter-simple-off' | 'finger-print' | 'flag' | 'flag-filled' | 'flashlight' | 'flashlight-filled' | 'floppy-disk' | 'folder' | 'folder-minus' | 'folder-open' | 'folder-plus' | 'framer' | 'funnel-filter-document' | 'gauge' | 'gauge-meter' | 'gear' | 'gear-shield' | 'genai' | 'giftbox' | 'git-commit' | 'github' | 'gitlab' | 'give-hand-cash' | 'give-hand-coins' | 'give-hand-heart' | 'glass-cheers' | 'globe' | 'globe-arrows-clockwise' | 'globe-arrows-counter-clockwise' | 'globe-bank' | 'globe-checked' | 'globe-dollar-sign' | 'globe-live' | 'globe-visa' | 'gold-bar' | 'grid' | 'grid-filled' | 'grid-layout' | 'group-circle' | 'hammer-gavel-legal' | 'hand-cash' | 'hand-credit-card' | 'hand-document' | 'hand-stacked-coins' | 'handshake' | 'hard-drive' | 'hard-token' | 'hash' | 'headphones' | 'headphones-mic' | 'headphones-mic-smile' | 'headphones-mic-smile-filled' | 'health-hand' | 'health-shield' | 'heart' | 'heart-checkmark' | 'heart-filled' | 'heart-hand' | 'help' | 'hexagon' | 'history' | 'home' | 'home-tab' | 'home-tab-filled' | 'hospital' | 'hospital-building' | 'house' | 'house-chimney' | 'idcard' | 'idcard-filled' | 'image' | 'in-out-arrow' | 'inbox' | 'info' | 'info-faqs' | 'instagram' | 'invest-tab' | 'invest-tab-filled' | 'italic' | 'key' | 'keyboard' | 'landline-phone' | 'language-translate' | 'layers' | 'layout' | 'left-right-arrows' | 'left-right-half-arrows' | 'letter-big' | 'letter-small' | 'life-buoy' | 'light-bulb' | 'lightbulb-filled' | 'link' | 'link-horizontal' | 'linkedin' | 'list' | 'list-academic' | 'list-bullet' | 'list-search' | 'list-search-filled' | 'list-stacked-coins' | 'loader' | 'loading-circle' | 'lock' | 'lock-round' | 'log-in' | 'log-out' | 'logo-social-line' | 'logo-social-telegram' | 'logo-social-tiktok' | 'logo-social-whatsapp' | 'logo-social-x' | 'magnifying-glass' | 'mail' | 'mail-open' | 'manage-account' | 'map' | 'map-pin' | 'map-pin-cn' | 'map-pin-filled' | 'marker' | 'maximize' | 'maximize-circle' | 'meals-fnb' | 'medical-card' | 'megaphone' | 'menu' | 'mic' | 'mic-off' | 'minimize' | 'minus' | 'minus-circle' | 'minus-circle-filled' | 'minus-square' | 'minus-symbol' | 'misty' | 'mobile-message' | 'mobile-pay' | 'money-bank-calculator' | 'money-plant' | 'monitor' | 'moon' | 'more-horizontal' | 'more-vertical' | 'mortar-hat' | 'mortgage' | 'multi-select-toggle' | 'music' | 'navigation' | 'navigation-circle' | 'note' | 'octagon' | 'octagon-information' | 'octagon-x' | 'paint-roller' | 'paperclip' | 'papyrus-scroll' | 'password' | 'pause' | 'pause-circle' | 'pay-and-transfer-tab' | 'pay-and-transfer-tab-filled' | 'pen-note' | 'pen-tool' | 'pencil' | 'pencil-line' | 'people-conversation' | 'percent' | 'phone' | 'phone-book' | 'phone-call' | 'phone-end' | 'phone-forwarded' | 'phone-incoming' | 'phone-missed' | 'phone-off' | 'phone-outgoing' | 'pie-chart' | 'pie-chart-segments' | 'pin' | 'pin-checked' | 'pin-filled' | 'pin-key' | 'plan-tab' | 'plan-tab-filled' | 'plant-sustainability' | 'play' | 'play-circle' | 'plus' | 'plus-circle' | 'plus-circle-filled' | 'plus-square' | 'plus-symbol' | 'pocket' | 'posb-logo' | 'power' | 'presentation' | 'print' | 'printer' | 'pulse' | 'pyramid' | 'qr-code' | 'question-mark' | 'radar' | 'radio' | 'radio-disc' | 'rain-thunder' | 'raining' | 'receipt-bank-account' | 'receipt-bill' | 'red-envelope' | 'refresh' | 'repeat' | 'replace-card' | 'report' | 'report-issue' | 'resize-handle' | 'rewards-crown' | 'rewind' | 'rotate-clockwise' | 'rotate-counter-clockwise' | 'rotate-device' | 'rotate-leaf' | 'rss' | 'safe-deposit-box' | 'scanner' | 'scanner-barcode' | 'scanner-face-id' | 'scissors' | 'search' | 'send' | 'server' | 'settings' | 'share' | 'share-connect' | 'shield' | 'shield-alert-filled' | 'shield-lock' | 'shield-off' | 'shop-basket' | 'shop-front' | 'shop-star' | 'shopping-bag' | 'shopping-basket' | 'shopping-cart' | 'shuffle' | 'sidebar' | 'siren' | 'skip-backward' | 'skip-forward' | 'slack' | 'slash' | 'sliders' | 'smartphone' | 'smiley-emotionless' | 'smiley-happy' | 'smiley-sad' | 'smiley-very-happy' | 'snow' | 'sort' | 'sort-ascending' | 'sort-descending' | 'spanner' | 'spark-stars' | 'sparkle' | 'speaker' | 'speech-bubble-round' | 'speech-bubble-smile' | 'speech-bubble-square' | 'speedometer' | 'speedometer-filled' | 'square' | 'square-chart' | 'square-check' | 'square-dot' | 'square-pencil' | 'square-to-square' | 'square-x' | 'star' | 'star-filled' | 'star-half' | 'stop-circle' | 'stop-circle-filled' | 'structure-organization' | 'sun' | 'sun-cloud' | 'sunny' | 'sunrise' | 'sunset' | 'swap' | 'table' | 'table-column-artboard' | 'table-column-delete' | 'table-sort' | 'tablet' | 'tag' | 'target' | 'text-color' | 'text-style' | 'text-wrap' | 'upload' | 'user' | 'user-filled' | 'users' | 'warning-circle' | 'warning-filled';

/**
 * The icon kit's shapes and sizes — types only, plus the two-element size
 * list. Nothing here reaches any geometry, which is the point: a call site
 * that types a field, or a glyph module that annotates itself, must be able
 * to do so without pulling a single path into its bundle.
 *
 * `UiIconShape` is one flat optional-field interface rather than a
 * discriminated union on purpose: the renderer walks it inside `@for`/
 * `@switch`, where a union would need narrowing that Angular's template
 * checker does not do inside embedded views. The glyph modules are
 * generated, so the looser shape costs nothing and the template stays
 * readable.
 */
/** The two boxes the kit draws icons in. */
type UiIconSize = 16 | 24;
/** One drawn primitive. `paint` is the only colour-adjacent field — and it
    names a ROLE, never a value. */
interface UiIconShape {
    readonly kind: 'path' | 'circle' | 'rect' | 'line';
    readonly paint: 'fill' | 'stroke';
    /** path */
    readonly d?: string;
    /** circle */
    readonly cx?: number;
    readonly cy?: number;
    readonly r?: number;
    /** rect */
    readonly x?: number;
    readonly y?: number;
    readonly w?: number;
    readonly h?: number;
    readonly rx?: number;
    /** line */
    readonly x1?: number;
    readonly y1?: number;
    readonly x2?: number;
    readonly y2?: number;
    /** stroke-width / linecap / linejoin, and fill-rule="evenodd". */
    readonly sw?: number;
    readonly cap?: string;
    readonly join?: string;
    readonly evenodd?: boolean;
}
/** One glyph at one size. */
interface UiIconGlyph {
    /** The geometry's own box — scaled into the rendered 16/24 square. */
    readonly viewBox: string;
    /** file:line this geometry was lifted from (delete on the DLS export). */
    readonly source: string;
    /** Why this slot is a stand-in, when it is one. */
    readonly note?: string;
    readonly shapes: readonly UiIconShape[];
}
/** A registry row: the same name at both sizes. */
interface UiIconEntry {
    readonly 16: UiIconGlyph;
    readonly 24: UiIconGlyph;
}
/** The sizes `ui-icon` accepts, in one place so the sink can iterate them. */
declare const UI_ICON_SIZES: readonly UiIconSize[];

/**
 * THE EAGER SET — the icons that must be drawn before anything can be fetched.
 *
 * THREE NAMES. It was 84 until 7 Sep 2026, and the shrink is the whole of this
 * file's history, so the reasoning is written down rather than left to be
 * re-derived:
 *
 * WHAT "EAGER" MEANS, AND WHAT IT USED TO MEAN. The 84 were
 * the kit's internal notes's list of every icon the
 * platform draws ANYWHERE — the work list for the B1 sweep that is migrating
 * 348 inline `<svg>`s onto `<ui-icon>`. That is a real set, and it is not this
 * one. Eager can only ever mean "on the FIRST PAINT", because that is the one
 * moment at which no chunk can have arrived yet. Every other icon in the app
 * is already downloading something — its own route chunk — by the time it is
 * asked for. Conflating the two put 81,390 bytes of geometry into `main`: the
 * largest single non-vendor input in the initial bundle, larger than the nav
 * rail and the AI drawer combined, and on its own more than the entire
 * 19.27 kB budget overage it caused.
 *
 * HOW THESE THREE WERE CHOSEN — measured twice, and the two agree:
 *
 *  1. In the browser, `/home` (the landing route: `app.routes.ts` redirects
 *     `''` there) contains **zero** `<ui-icon>` elements at first paint, and
 *     22 raw `<svg>`s. The nav rail, the home cards and the AI launcher all
 *     still draw their marks inline; the AI drawer's whole template is behind
 *     `@if (open())`. So the literal first-paint set is EMPTY.
 *  2. In the build's own metafile, the only modules under `the kit` that
 *     land in `main` are the nav rail parts, avatar, badge, fab, icon-button,
 *     textarea, `text-input` and `chip` — and of those only two draw an icon
 *     by name: `text-input.ts` renders `<ui-icon name="check" />` in its
 *     success state and `chip.ts` renders `<ui-icon name="close" />` on a
 *     removable chip. Those are the only two names ANY component in the
 *     initial bundle can produce, at any moment, without a route chunk having
 *     been fetched first. They are eager because they are the honest edge of
 *     "could be needed before anything else has loaded" — not because they are
 *     on screen at t=0. Nothing is.
 *
 * `chevron-down` is the third, and it is the one judgement call in the list:
 * it is not reachable from `main` (its drawers are `ui-select`, `ui-card`,
 * `ui-accordion`, `ui-multi-select`, all of which arrive with a route), and
 * the honest reason it is here is that the kitchen sink's "Eager and lazy,
 * side by side" demo names it, and an e2e spec `(e)` uses that
 * demo to prove the eager tier still resolves synchronously. It costs 590
 * bytes of `main`. Dropping it is a two-line change here plus a row moved back
 * into `./glyphs/platform.ts`, and it needs the sink's demo to name `check`
 * instead — the sink is not the kit's to edit.
 *
 * WHAT THE OTHER 81 DO NOW. They are one `import()` behind
 * `./glyphs/platform.ts` (see `./manifest.ts`), which is a single request
 * covering every icon a real screen draws, rather than the four or five DLS
 * category chunks they would cost if they were scattered back by category.
 * They paint a frame or two later, into a box `ui-icon` had already reserved
 * at exactly the right size, so nothing reflows.
 *
 * TO ADD A NAME HERE — and the nav rail moving off raw `<svg>` is the case
 * that will need it: move its glyph `const` out of `./glyphs/platform.ts`
 * into `./glyphs/eager.ts`, delete the name's row from that module's
 * `ENTRIES` and from `./manifest.ts`, and add its row below. Half a move does
 * not compile — `./manifest.ts` asserts that eager and lazy together cover the
 * catalogue exactly once.
 *
 * TO DROP A NAME: the reverse. Nothing outside this file knows which tier a
 * name is in; `<ui-icon name="…" />` is identical either way.
 */
declare const UI_ICON_EAGER: {
    readonly check: {
        readonly 16: {
            readonly viewBox: "0 0 16 16";
            readonly source: "DLS 12592:10549";
            readonly shapes: readonly [{
                readonly kind: "path";
                readonly paint: "fill";
                readonly d: "M12.9199 3.91995L5.58653 11.2533H6.40653L3.0732 7.91995C2.83987 7.68661 2.4732 7.68661 2.24653 7.91995C2.0132 8.14661 2.0132 8.51328 2.24653 8.73995L5.57987 12.0733C5.80653 12.2999 6.1732 12.2999 6.39987 12.0733L13.7332 4.73995C13.9599 4.50661 13.9599 4.13995 13.7332 3.91328C13.4999 3.67995 13.1332 3.67995 12.9065 3.91328L12.9199 3.91995Z";
            }];
        };
        readonly 24: {
            readonly viewBox: "0 0 16 16";
            readonly source: "DLS 12592:10549";
            readonly shapes: readonly [{
                readonly kind: "path";
                readonly paint: "fill";
                readonly d: "M12.9199 3.91995L5.58653 11.2533H6.40653L3.0732 7.91995C2.83987 7.68661 2.4732 7.68661 2.24653 7.91995C2.0132 8.14661 2.0132 8.51328 2.24653 8.73995L5.57987 12.0733C5.80653 12.2999 6.1732 12.2999 6.39987 12.0733L13.7332 4.73995C13.9599 4.50661 13.9599 4.13995 13.7332 3.91328C13.4999 3.67995 13.1332 3.67995 12.9065 3.91328L12.9199 3.91995Z";
            }];
        };
    };
    readonly 'chevron-down': {
        readonly 16: {
            readonly viewBox: "0 0 16 16";
            readonly source: "DLS 12592:10781";
            readonly shapes: readonly [{
                readonly kind: "path";
                readonly paint: "fill";
                readonly d: "M3.64645 5.64645C3.84171 5.45118 4.15829 5.45118 4.35355 5.64645L8 9.29289L11.6464 5.64645C11.8417 5.45118 12.1583 5.45118 12.3536 5.64645C12.5488 5.84171 12.5488 6.15829 12.3536 6.35355L8.35355 10.3536C8.15829 10.5488 7.84171 10.5488 7.64645 10.3536L3.64645 6.35355C3.45118 6.15829 3.45118 5.84171 3.64645 5.64645Z";
                readonly evenodd: true;
            }];
        };
        readonly 24: {
            readonly viewBox: "0 0 16 16";
            readonly source: "DLS 12592:10781";
            readonly shapes: readonly [{
                readonly kind: "path";
                readonly paint: "fill";
                readonly d: "M3.64645 5.64645C3.84171 5.45118 4.15829 5.45118 4.35355 5.64645L8 9.29289L11.6464 5.64645C11.8417 5.45118 12.1583 5.45118 12.3536 5.64645C12.5488 5.84171 12.5488 6.15829 12.3536 6.35355L8.35355 10.3536C8.15829 10.5488 7.84171 10.5488 7.64645 10.3536L3.64645 6.35355C3.45118 6.15829 3.45118 5.84171 3.64645 5.64645Z";
                readonly evenodd: true;
            }];
        };
    };
    readonly close: {
        readonly 16: {
            readonly viewBox: "0 0 16 16";
            readonly source: "DLS 12592:10381";
            readonly shapes: readonly [{
                readonly kind: "path";
                readonly paint: "fill";
                readonly d: "M3.64645 3.64645C3.84171 3.45118 4.15829 3.45118 4.35355 3.64645L8 7.29289L11.6464 3.64645C11.8417 3.45118 12.1583 3.45118 12.3536 3.64645C12.5488 3.84171 12.5488 4.15829 12.3536 4.35355L8.70711 8L12.3536 11.6464C12.5488 11.8417 12.5488 12.1583 12.3536 12.3536C12.1583 12.5488 11.8417 12.5488 11.6464 12.3536L8 8.70711L4.35355 12.3536C4.15829 12.5488 3.84171 12.5488 3.64645 12.3536C3.45118 12.1583 3.45118 11.8417 3.64645 11.6464L7.29289 8L3.64645 4.35355C3.45118 4.15829 3.45118 3.84171 3.64645 3.64645Z";
                readonly evenodd: true;
            }];
        };
        readonly 24: {
            readonly viewBox: "0 0 16 16";
            readonly source: "DLS 12592:10381";
            readonly shapes: readonly [{
                readonly kind: "path";
                readonly paint: "fill";
                readonly d: "M3.64645 3.64645C3.84171 3.45118 4.15829 3.45118 4.35355 3.64645L8 7.29289L11.6464 3.64645C11.8417 3.45118 12.1583 3.45118 12.3536 3.64645C12.5488 3.84171 12.5488 4.15829 12.3536 4.35355L8.70711 8L12.3536 11.6464C12.5488 11.8417 12.5488 12.1583 12.3536 12.3536C12.1583 12.5488 11.8417 12.5488 11.6464 12.3536L8 8.70711L4.35355 12.3536C4.15829 12.5488 3.84171 12.5488 3.64645 12.3536C3.45118 12.1583 3.45118 11.8417 3.64645 11.6464L7.29289 8L3.64645 4.35355C3.45118 4.15829 3.45118 3.84171 3.64645 3.64645Z";
                readonly evenodd: true;
            }];
        };
    };
};
/** The eagerly-bundled names, for the kitchen sink's tier labelling. */
type UiIconEagerName = keyof typeof UI_ICON_EAGER;
/** Alphabetical, so the sink can show which tier a name is in. */
declare const UI_ICON_EAGER_NAMES: readonly UiIconEagerName[];

/**
 * The catalogue's 569 names as a runtime array, fetched on demand.
 *
 * WHY THIS IS A FUNCTION AND NOT AN EXPORT. `UI_ICON_NAMES` used to be a plain
 * re-export from this file, and that put all 8,110 bytes of it into `main` for
 * every user of every page. The array's only reader is the kitchen sink, which
 * is a lazy route — but the bundler never got the chance to notice, because
 * placement is per MODULE, not per symbol: `main` draws icons on the first
 * route, so it imports `./icon`, so it imports this barrel, so every module
 * this barrel re-exports as a value is in `main`'s graph and lands there. Being
 * unused by `main` does not save it; the sink's use of the symbol is what keeps
 * it alive, and the shared placement is what puts the live symbol in `main`.
 * Measured, 7 Sep 2026: moving the array to its own file and re-exporting it
 * from here with `export *` changed `main` by exactly zero bytes.
 *
 * An `import()` is the one edge a chunk cannot be hoisted across, so it is the
 * only thing that actually moves the array — the same mechanism the lazy glyph
 * tier already uses, applied to the name list itself. `./catalogue.ts` is
 * therefore reachable from nowhere else: this function is its only importer.
 *
 * The TYPE is unaffected and still free — `UiIconName` is a written-out union
 * in `./names.ts` with no runtime binding at all, so typing a field costs
 * nothing and needs no await. This is only for code that must ENUMERATE the
 * catalogue, which in this repo is the sink's icon grid and nothing else.
 */
declare function loadUiIconNames(): Promise<readonly UiIconName[]>;

/**
 * DLS icon — the kit's ONE way to draw a glyph (KIT-FIXES B1, 6 Sep 2026).
 *
 *   <ui-icon name="chevron-down" />
 *   <ui-icon name="download" [size]="24" />
 *   <ui-icon name="delete" ariaLabel="Delete request" />
 *
 * Takes a NAME, never a path. `name` is typed `UiIconName` (= the registry's
 * `keyof`), so a glyph the kit does not have is a compile error at every
 * TypeScript call site, and an unknown name reaching the component at runtime
 * — the template-only typo the type cannot see — THROWS rather than painting
 * a blank 16px box. A missing icon should be loud.
 *
 * ── Colour: the glyph never carries one ─────────────────────────────────
 * Each registry shape declares `paint: 'fill' | 'stroke'` — a ROLE, not a
 * value — and this component supplies `currentColor` for whichever it is.
 * So an icon is always the colour of its context (`color` on any ancestor,
 * a button's own `--color-icon`, the nav rail's inverse text) and no call
 * site can hard-code a colour into a glyph. That is also why the two-tone
 * status badges (a filled disc with a knockout mark) are NOT in the
 * registry: they need two colours by definition, which makes them DLS's
 * separate `status-icon` / `circular-icon` components, not icons. See
 * the kit's internal notes §2.
 *
 * ── Size is the BOX, the viewBox is the drawing ─────────────────────────
 * `size` is 16 (default) or 24 — the two boxes DLS ships — and it is set as
 * the `<svg>`'s own width/height, so the rendered square is exactly 16 or 24
 * whatever the glyph's `viewBox` happens to be. The registry keeps a
 * separate entry per size because DLS redraws a glyph for its box (a 24
 * chevron is not a scaled 16 chevron); where only one drawing exists today,
 * both slots hold it and the stand-in slot says so in its `note`.
 *
 * ── Accessibility ───────────────────────────────────────────────────────
 * Default is `aria-hidden="true"` — the overwhelmingly common case is a
 * glyph beside a label, or inside a `ui-icon-button` that already carries
 * its own `aria-label`, and announcing it twice is worse than not at all.
 * Passing `ariaLabel` flips the SVG to `role="img"` with that name and drops
 * the `aria-hidden`, for the rare icon that IS the content.
 *
 * ── Two tiers, and why a consumer never sees them ─────────────────
 * The catalogue is 569 names and heading for 598; a name lookup cannot be
 * tree-shaken, so binding them all in one object literal put every glyph in
 * every build (349 KB gzipped at 598, for the ~84 this platform draws). So
 * the catalogue is split, and the split line is the FIRST PAINT: 3 names are
 * STATICALLY bundled (`./eager.ts`) and every other name sits behind an
 * `import()` (`./manifest.ts`) — to its DLS category chunk, or to the one
 * `platform` chunk holding the 81 this app draws away from the landing route.
 * Until 7 Sep 2026 all 84 of those were eager, which cost `main` 81,390 bytes
 * of geometry for icons no first paint renders; `./eager.ts` has the numbers.
 *
 * The difference is invisible at the call site — `name`, `size` and
 * `ariaLabel` behave identically — and nearly invisible on screen:
 *  - an EAGER name renders in the first frame, synchronously, as before;
 *  - a LAZY name renders its `<svg>` immediately at exactly `size` px, empty,
 *    and fills in when its chunk lands. The box is reserved from the first
 *    frame, so nothing reflows around it and the aria contract is already
 *    correct before the geometry exists.
 * A chunk that fails to load logs loudly and rethrows out of band rather
 * than leaving a silent empty square (see ./loader.ts).
 *
 * SEEDED GEOMETRY. 57 of the 84 glyphs the platform draws were lifted
 * verbatim from inline SVGs already shipping in this repo; the real source of
 * truth is the owner's Figma file "DLS 3.1 — Icons"
 * (`fIR6ucxPfotL8VkIk6RoZg`, page `0:1`). When
 * that export lands it is a mechanical swap inside `./glyphs/` — this
 * component and every call site are unaffected, because they name an icon
 * rather than describe one.
 *
 * RESKIN: if the Angular DLS ships an icon component, delegate to it and keep
 * the `ui-icon` selector plus the `name` / `size` / `ariaLabel` inputs; the
 * registry then becomes a name → DLS-name map instead of geometry.
 */
declare class UiIcon {
    /** Registry name. A name the kit does not have is a compile error. */
    name: _angular_core.InputSignal<UiIconName>;
    /** The drawn box, in px. DLS ships 16 and 24; 16 is the platform default. */
    size: _angular_core.InputSignal<UiIconSize>;
    /** Set only when the icon IS the content. Flips the SVG to `role="img"`
        with this name; leaving it unset keeps `aria-hidden="true"`. */
    ariaLabel: _angular_core.InputSignal<string | null>;
    /**
     * The drawing, or `null` while a lazy glyph's chunk is in the air. Null is
     * NOT an error state: the `<svg>` is already the right size (see
     * `viewBox`), so the arrival paints into space that was reserved from the
     * first frame and nothing on the page moves.
     *
     * A name in NEITHER tier throws, exactly as it did when the registry was
     * one object — that is the template-only typo `UiIconName` cannot see, and
     * a blank box is a worse answer than a stack trace.
     */
    protected readonly glyph: _angular_core.Signal<UiIconGlyph | null>;
    /**
     * The box is reserved even with no glyph. `width`/`height` are the rendered
     * square either way; the placeholder `viewBox` just keeps the element a
     * well-formed SVG of the right aspect while it is empty, so a lazy icon
     * never reflows its neighbours when it arrives.
     */
    protected readonly viewBox: _angular_core.Signal<string>;
    /**
     * Start the chunk for a lazy name. Deliberately an `effect` and not a line
     * inside `glyph`: a `computed` must stay pure, and this one is read during
     * template evaluation. The loader de-duplicates, so a page full of icons
     * from one category makes exactly one request.
     */
    private readonly fetchGlyph;
    protected fillOf(shape: UiIconShape): string;
    protected strokeOf(shape: UiIconShape): string | null;
    /**
     * SVG's own default stroke-width is 1, and that is what Figma relies on:
     * the DLS icons export with NO `stroke-width` attribute at all. The first
     * draft defaulted to 1.5 (the value the repo's hand-inlined glyphs mostly
     * used), which would have drawn every stroked DLS glyph 50% too thick —
     * silently, since a thicker stroke still renders and no test compares it
     * to the source. Caught by the export agent, 6 Sep 2026.
     * Defaulting to the SVG default means an entry that omits `sw` renders
     * exactly as Figma drew it; a glyph that genuinely needs another weight
     * says so explicitly.
     */
    protected strokeWidthOf(shape: UiIconShape): number | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiIcon, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiIcon, "ui-icon", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { AVATAR_COLOURS, CHART_SERIES_SLOTS, UI_ICON_EAGER_NAMES, UI_ICON_SIZES, UiAccordion, UiAccordionActions, UiAccordionBody, UiAccordionHeader, UiActionsRow, UiAlert, UiAmountInput, UiAvatar, UiBadge, UiBarList, UiBreadcrumb, UiButton, UiCard, UiCardButton, UiCellChanged, UiCellEdit, UiCellExpandable, UiCheckbox, UiCheckboxGroup, UiChip, UiCoachmark, UiCodeSegment, UiColumnHeader, UiContentSeparator, UiCurrencyPair, UiDateInput, UiDatePicker, UiDonutChart, UiDotPagination, UiDrawer, UiDropdownAccountItem, UiDropdownGroup, UiDropdownHeading, UiDropdownItem, UiDropdownMenu, UiEmptyState, UiFab, UiFileDrop, UiFileRow, UiFileThumbnail, UiFilterTabs, UiFormField, UiIcon, UiIconButton, UiInfoBanner, UiKebabMenu, UiLineChart, UiLink, UiLoader, UiModal, UiModalShell, UiMultiSelect, UiNavFooterItem, UiNavGroup, UiNavPanel, UiNavPanelHeader, UiNavRail, UiNavRailFlyout, UiNavRailFlyoutSection, UiNavRailFooter, UiNavRailHeader, UiNavRailItem, UiNavRailRule, UiNavRailSection, UiNavRailSubItem, UiNavSubItem, UiNumberInput, UiPageHeader, UiPageTitle, UiPagination, UiPhoneInput, UiPill, UiPopover, UiProgressBar, UiQuicklink, UiRadio, UiRadioChiclet, UiRadioChicletGroup, UiRankedList, UiRichText, UiSearchInput, UiSectionHeader, UiSegmented, UiSelect, UiSelectGroup, UiSkeleton, UiSkeletonBar, UiSnackbar, UiSparkline, UiStackedBarChart, UiStackedBarList, UiStatusDot, UiStatusTag, UiStepper, UiStepperMarker, UiSubTabs, UiSummaryCard, UiSwitch, UiTable, UiTableAddRow, UiTableCard, UiTableColumns, UiTableHeader, UiTableRow, UiTableSubHeader, UiTabs, UiTagFilter, UiTagInfo, UiTextInput, UiTextarea, UiTooltipDirective, UiTracker, UiTrackerDivider, UiTrackerEvent, UiTrackerMarker, UiTrackerStep, UiTrackerSubEvent, UiUploadFile, initialsOf, loadUiIconNames, statusVariant, uiChartHatchAngle, uiChartHatchCss, uiChartSlot };
export type { UiAccordionBarColor, UiAlertAnchor, UiAvatarColour, UiAvatarSize, UiAvatarType, UiBarListItem, UiBreadcrumbItem, UiButtonSize, UiButtonTone, UiButtonVariant, UiCardFooterAction, UiChartSlot, UiChartTick, UiChipKind, UiCoachmarkPlacement, UiCurrencyPairSign, UiCurrencyPairSize, UiDatePickerType, UiDateRange, UiDonutSegment, UiDrawerFooterLayout, UiDropdownMenuRole, UiEmptyStateIllustration, UiFabTone, UiFileDropAlignment, UiFileKind, UiFileThumbnailType, UiFilterTab, UiFilterTabSize, UiFormFieldCounter, UiIconButtonShape, UiIconButtonSize, UiIconButtonTone, UiIconEagerName, UiIconEntry, UiIconGlyph, UiIconName, UiIconShape, UiIconSize, UiInfoBannerTone, UiLineAnnotation, UiLineSeries, UiLinkVariant, UiLoaderKind, UiMenuItem, UiModalFooterLayout, UiMultiSelectDisplay, UiMultiSelectItem, UiNavRailItemKind, UiNavStatus, UiPageHeaderContentGap, UiPageHeaderType, UiPaginationType, UiPillColor, UiPillVariant, UiPopoverFooterLayout, UiPopoverPlacement, UiQuicklinkDirection, UiQuicklinkSize, UiRadioLayout, UiRadioOption, UiRankedListItem, UiSearchInputSize, UiSectionHeaderSize, UiSegment, UiSelectOption, UiSkeletonType, UiSnackbarTone, UiStackedBarCategory, UiStackedBarColumn, UiStackedBarListColumns, UiStackedBarListRow, UiStackedBarListSeries, UiStepperStatus, UiStepperStep, UiStepperSubStep, UiSubTab, UiSummaryItem, UiSwitchSize, UiTab, UiTableColumn, UiTableHeaderLayout, UiTableSize, UiTagInfoColour, UiTagInfoType, UiTagVariant, UiTooltipContent, UiTrackerStatus, UiTrackerSubEventStatus, UiUploadStatus };
