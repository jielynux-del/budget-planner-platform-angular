/** `checkbox-dash` — DLS node 12592:10405. */
const gCheckboxDash = {
    viewBox: '0 0 16 16',
    source: 'DLS 12592:10405',
    shapes: [
        { kind: 'path', paint: 'fill', d: 'M4 8C4 7.63181 4.29848 7.33333 4.66667 7.33333H11.3333C11.7015 7.33333 12 7.63181 12 8C12 8.36819 11.7015 8.66667 11.3333 8.66667H4.66667C4.29848 8.66667 4 8.36819 4 8Z', evenodd: true },
    ],
};
/** `checkbox-tick` — DLS node 12592:10775. */
const gCheckboxTick = {
    viewBox: '0 0 16 16',
    source: 'DLS 12592:10775',
    shapes: [
        { kind: 'path', paint: 'fill', d: 'M12.2757 6.03248L6.31746 11.5935L3.72396 8.99999L4.66677 8.05718L6.34941 9.73982L11.3659 5.05774L12.2757 6.03248Z', evenodd: true },
    ],
};
/** `multi-select-toggle` — DLS node 12592:10550. */
const gMultiSelectToggle = {
    viewBox: '0 0 16 16',
    source: 'DLS 12592:10550',
    shapes: [
        { kind: 'path', paint: 'fill', d: 'M3.33333 2.5C2.87281 2.5 2.5 2.87281 2.5 3.33333V9.33333C2.5 9.79386 2.87281 10.1667 3.33333 10.1667C3.60948 10.1667 3.83333 10.3905 3.83333 10.6667C3.83333 10.9428 3.60948 11.1667 3.33333 11.1667C2.32052 11.1667 1.5 10.3461 1.5 9.33333V3.33333C1.5 2.32052 2.32052 1.5 3.33333 1.5H9.33333C10.3461 1.5 11.1667 2.32052 11.1667 3.33333C11.1667 3.60948 10.9428 3.83333 10.6667 3.83333C10.3905 3.83333 10.1667 3.60948 10.1667 3.33333C10.1667 2.87281 9.79386 2.5 9.33333 2.5H3.33333ZM6.66667 5.83333C6.20614 5.83333 5.83333 6.20614 5.83333 6.66667V12.6667C5.83333 13.1272 6.20614 13.5 6.66667 13.5H12.6667C13.1272 13.5 13.5 13.1272 13.5 12.6667V6.66667C13.5 6.20614 13.1272 5.83333 12.6667 5.83333H6.66667ZM4.83333 6.66667C4.83333 5.65386 5.65386 4.83333 6.66667 4.83333H12.6667C13.6795 4.83333 14.5 5.65386 14.5 6.66667V12.6667C14.5 13.6795 13.6795 14.5 12.6667 14.5H6.66667C5.65386 14.5 4.83333 13.6795 4.83333 12.6667V6.66667ZM11.9462 8.35045C12.1415 8.54571 12.1415 8.86229 11.9462 9.05755L9.53889 11.4649C9.34362 11.6601 9.02704 11.6601 8.83178 11.4649L7.38711 10.0202C7.19185 9.82496 7.19185 9.50838 7.38711 9.31311C7.58238 9.11785 7.89896 9.11785 8.09422 9.31311L9.18533 10.4042L11.2391 8.35045C11.4344 8.15518 11.751 8.15518 11.9462 8.35045Z', evenodd: true },
    ],
};
/**
 * The chunk's payload: every name in this category that `ui-icon` can draw,
 * bound to its glyph. `../manifest.ts` reaches this through a dynamic
 * `import()`, so the geometry above is downloaded only when one of these
 * names is actually rendered — one request for the whole category, never one
 * per icon.
 *
 * Names the platform draws today are NOT here: they are grouped in
 * `./platform.ts`, one chunk of their own, so a screen that draws several
 * of them makes one request rather than one per category. Only the three
 * names in `./eager.ts` are statically bundled.
 */
const ENTRIES = {
    'checkbox-dash': { 16: gCheckboxDash, 24: gCheckboxDash },
    'checkbox-tick': { 16: gCheckboxTick, 24: gCheckboxTick },
    'multi-select-toggle': { 16: gMultiSelectToggle, 24: gMultiSelectToggle },
};

export { ENTRIES, gCheckboxDash, gCheckboxTick, gMultiSelectToggle };
//# sourceMappingURL=ai-dls-kit-component-qO3Cm82q.mjs.map
